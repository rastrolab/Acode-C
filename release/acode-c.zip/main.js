(()=>{var Hs=Object.create;var zn=Object.defineProperty;var js=Object.getOwnPropertyDescriptor;var Vs=Object.getOwnPropertyNames;var qs=Object.getPrototypeOf,Zs=Object.prototype.hasOwnProperty;var jt=(e=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(e,{get:(t,n)=>(typeof require<"u"?require:t)[n]}):e)(function(e){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')});var Gs=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Xs=(e,t,n,r)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of Vs(t))!Zs.call(e,a)&&a!==n&&zn(e,a,{get:()=>t[a],enumerable:!(r=js(t,a))||r.enumerable});return e};var Ks=(e,t,n)=>(n=e!=null?Hs(qs(e)):{},Xs(t||!e||!e.__esModule?zn(n,"default",{value:e,enumerable:!0}):n,e));var Qn=Gs((exports,module)=>{var Module=Module!==void 0?Module:{},TreeSitter=(function(){var initPromise,document=typeof window=="object"?{currentScript:window.document.currentScript}:null;class Parser{constructor(){this.initialize()}initialize(){throw new Error("cannot construct a Parser before calling `init()`")}static init(moduleOptions){return initPromise||(Module=Object.assign({},Module,moduleOptions),initPromise=new Promise((resolveInitPromise=>{var moduleOverrides=Object.assign({},Module),arguments_=[],thisProgram="./this.program",quit_=(e,t)=>{throw t},ENVIRONMENT_IS_WEB=typeof window=="object",ENVIRONMENT_IS_WORKER=typeof importScripts=="function",ENVIRONMENT_IS_NODE=typeof process=="object"&&typeof process.versions=="object"&&typeof process.versions.node=="string",scriptDirectory="",read_,readAsync,readBinary,setWindowTitle;function locateFile(e){return Module.locateFile?Module.locateFile(e,scriptDirectory):scriptDirectory+e}function logExceptionOnExit(e){e instanceof ExitStatus||err("exiting due to exception: "+e)}if(ENVIRONMENT_IS_NODE){var fs=jt("fs"),nodePath=jt("path");scriptDirectory=ENVIRONMENT_IS_WORKER?nodePath.dirname(scriptDirectory)+"/":__dirname+"/",read_=(e,t)=>(e=isFileURI(e)?new URL(e):nodePath.normalize(e),fs.readFileSync(e,t?void 0:"utf8")),readBinary=e=>{var t=read_(e,!0);return t.buffer||(t=new Uint8Array(t)),t},readAsync=(e,t,n)=>{e=isFileURI(e)?new URL(e):nodePath.normalize(e),fs.readFile(e,(function(r,a){r?n(r):t(a.buffer)}))},process.argv.length>1&&(thisProgram=process.argv[1].replace(/\\/g,"/")),arguments_=process.argv.slice(2),typeof module<"u"&&(module.exports=Module),quit_=(e,t)=>{if(keepRuntimeAlive())throw process.exitCode=e,t;logExceptionOnExit(t),process.exit(e)},Module.inspect=function(){return"[Emscripten Module object]"}}else(ENVIRONMENT_IS_WEB||ENVIRONMENT_IS_WORKER)&&(ENVIRONMENT_IS_WORKER?scriptDirectory=self.location.href:document!==void 0&&document.currentScript&&(scriptDirectory=document.currentScript.src),scriptDirectory=scriptDirectory.indexOf("blob:")!==0?scriptDirectory.substr(0,scriptDirectory.replace(/[?#].*/,"").lastIndexOf("/")+1):"",read_=e=>{var t=new XMLHttpRequest;return t.open("GET",e,!1),t.send(null),t.responseText},ENVIRONMENT_IS_WORKER&&(readBinary=e=>{var t=new XMLHttpRequest;return t.open("GET",e,!1),t.responseType="arraybuffer",t.send(null),new Uint8Array(t.response)}),readAsync=(e,t,n)=>{var r=new XMLHttpRequest;r.open("GET",e,!0),r.responseType="arraybuffer",r.onload=()=>{r.status==200||r.status==0&&r.response?t(r.response):n()},r.onerror=n,r.send(null)},setWindowTitle=e=>document.title=e);var out=Module.print||console.log.bind(console),err=Module.printErr||console.warn.bind(console);Object.assign(Module,moduleOverrides),moduleOverrides=null,Module.arguments&&(arguments_=Module.arguments),Module.thisProgram&&(thisProgram=Module.thisProgram),Module.quit&&(quit_=Module.quit);var STACK_ALIGN=16,dynamicLibraries=Module.dynamicLibraries||[],wasmBinary;Module.wasmBinary&&(wasmBinary=Module.wasmBinary);var noExitRuntime=Module.noExitRuntime||!0,wasmMemory;typeof WebAssembly!="object"&&abort("no native wasm support detected");var ABORT=!1,EXITSTATUS,UTF8Decoder=typeof TextDecoder<"u"?new TextDecoder("utf8"):void 0,buffer,HEAP8,HEAPU8,HEAP16,HEAPU16,HEAP32,HEAPU32,HEAPF32,HEAPF64;function UTF8ArrayToString(e,t,n){for(var r=t+n,a=t;e[a]&&!(a>=r);)++a;if(a-t>16&&e.buffer&&UTF8Decoder)return UTF8Decoder.decode(e.subarray(t,a));for(var o="";t<a;){var c=e[t++];if(128&c){var d=63&e[t++];if((224&c)!=192){var p=63&e[t++];if((c=(240&c)==224?(15&c)<<12|d<<6|p:(7&c)<<18|d<<12|p<<6|63&e[t++])<65536)o+=String.fromCharCode(c);else{var w=c-65536;o+=String.fromCharCode(55296|w>>10,56320|1023&w)}}else o+=String.fromCharCode((31&c)<<6|d)}else o+=String.fromCharCode(c)}return o}function UTF8ToString(e,t){return e?UTF8ArrayToString(HEAPU8,e,t):""}function stringToUTF8Array(e,t,n,r){if(!(r>0))return 0;for(var a=n,o=n+r-1,c=0;c<e.length;++c){var d=e.charCodeAt(c);if(d>=55296&&d<=57343&&(d=65536+((1023&d)<<10)|1023&e.charCodeAt(++c)),d<=127){if(n>=o)break;t[n++]=d}else if(d<=2047){if(n+1>=o)break;t[n++]=192|d>>6,t[n++]=128|63&d}else if(d<=65535){if(n+2>=o)break;t[n++]=224|d>>12,t[n++]=128|d>>6&63,t[n++]=128|63&d}else{if(n+3>=o)break;t[n++]=240|d>>18,t[n++]=128|d>>12&63,t[n++]=128|d>>6&63,t[n++]=128|63&d}}return t[n]=0,n-a}function stringToUTF8(e,t,n){return stringToUTF8Array(e,HEAPU8,t,n)}function lengthBytesUTF8(e){for(var t=0,n=0;n<e.length;++n){var r=e.charCodeAt(n);r<=127?t++:r<=2047?t+=2:r>=55296&&r<=57343?(t+=4,++n):t+=3}return t}function updateGlobalBufferAndViews(e){buffer=e,Module.HEAP8=HEAP8=new Int8Array(e),Module.HEAP16=HEAP16=new Int16Array(e),Module.HEAP32=HEAP32=new Int32Array(e),Module.HEAPU8=HEAPU8=new Uint8Array(e),Module.HEAPU16=HEAPU16=new Uint16Array(e),Module.HEAPU32=HEAPU32=new Uint32Array(e),Module.HEAPF32=HEAPF32=new Float32Array(e),Module.HEAPF64=HEAPF64=new Float64Array(e)}var INITIAL_MEMORY=Module.INITIAL_MEMORY||33554432;wasmMemory=Module.wasmMemory?Module.wasmMemory:new WebAssembly.Memory({initial:INITIAL_MEMORY/65536,maximum:32768}),wasmMemory&&(buffer=wasmMemory.buffer),INITIAL_MEMORY=buffer.byteLength,updateGlobalBufferAndViews(buffer);var wasmTable=new WebAssembly.Table({initial:20,element:"anyfunc"}),__ATPRERUN__=[],__ATINIT__=[],__ATMAIN__=[],__ATPOSTRUN__=[],__RELOC_FUNCS__=[],runtimeInitialized=!1;function keepRuntimeAlive(){return noExitRuntime}function preRun(){if(Module.preRun)for(typeof Module.preRun=="function"&&(Module.preRun=[Module.preRun]);Module.preRun.length;)addOnPreRun(Module.preRun.shift());callRuntimeCallbacks(__ATPRERUN__)}function initRuntime(){runtimeInitialized=!0,callRuntimeCallbacks(__RELOC_FUNCS__),callRuntimeCallbacks(__ATINIT__)}function preMain(){callRuntimeCallbacks(__ATMAIN__)}function postRun(){if(Module.postRun)for(typeof Module.postRun=="function"&&(Module.postRun=[Module.postRun]);Module.postRun.length;)addOnPostRun(Module.postRun.shift());callRuntimeCallbacks(__ATPOSTRUN__)}function addOnPreRun(e){__ATPRERUN__.unshift(e)}function addOnInit(e){__ATINIT__.unshift(e)}function addOnPostRun(e){__ATPOSTRUN__.unshift(e)}var runDependencies=0,runDependencyWatcher=null,dependenciesFulfilled=null;function addRunDependency(e){runDependencies++,Module.monitorRunDependencies&&Module.monitorRunDependencies(runDependencies)}function removeRunDependency(e){if(runDependencies--,Module.monitorRunDependencies&&Module.monitorRunDependencies(runDependencies),runDependencies==0&&(runDependencyWatcher!==null&&(clearInterval(runDependencyWatcher),runDependencyWatcher=null),dependenciesFulfilled)){var t=dependenciesFulfilled;dependenciesFulfilled=null,t()}}function abort(e){throw Module.onAbort&&Module.onAbort(e),err(e="Aborted("+e+")"),ABORT=!0,EXITSTATUS=1,e+=". Build with -sASSERTIONS for more info.",new WebAssembly.RuntimeError(e)}var dataURIPrefix="data:application/octet-stream;base64,",wasmBinaryFile,tempDouble,tempI64;function isDataURI(e){return e.startsWith(dataURIPrefix)}function isFileURI(e){return e.startsWith("file://")}function getBinary(e){try{if(e==wasmBinaryFile&&wasmBinary)return new Uint8Array(wasmBinary);if(readBinary)return readBinary(e);throw"both async and sync fetching of the wasm failed"}catch(t){abort(t)}}function getBinaryPromise(){if(!wasmBinary&&(ENVIRONMENT_IS_WEB||ENVIRONMENT_IS_WORKER)){if(typeof fetch=="function"&&!isFileURI(wasmBinaryFile))return fetch(wasmBinaryFile,{credentials:"same-origin"}).then((function(e){if(!e.ok)throw"failed to load wasm binary file at '"+wasmBinaryFile+"'";return e.arrayBuffer()})).catch((function(){return getBinary(wasmBinaryFile)}));if(readAsync)return new Promise((function(e,t){readAsync(wasmBinaryFile,(function(n){e(new Uint8Array(n))}),t)}))}return Promise.resolve().then((function(){return getBinary(wasmBinaryFile)}))}function createWasm(){var e={env:asmLibraryArg,wasi_snapshot_preview1:asmLibraryArg,"GOT.mem":new Proxy(asmLibraryArg,GOTHandler),"GOT.func":new Proxy(asmLibraryArg,GOTHandler)};function t(a,o){var c=a.exports;c=relocateExports(c,1024);var d=getDylinkMetadata(o);d.neededDynlibs&&(dynamicLibraries=d.neededDynlibs.concat(dynamicLibraries)),mergeLibSymbols(c,"main"),Module.asm=c,addOnInit(Module.asm.__wasm_call_ctors),__RELOC_FUNCS__.push(Module.asm.__wasm_apply_data_relocs),removeRunDependency("wasm-instantiate")}function n(a){t(a.instance,a.module)}function r(a){return getBinaryPromise().then((function(o){return WebAssembly.instantiate(o,e)})).then((function(o){return o})).then(a,(function(o){err("failed to asynchronously prepare wasm: "+o),abort(o)}))}if(addRunDependency("wasm-instantiate"),Module.instantiateWasm)try{return Module.instantiateWasm(e,t)}catch(a){return err("Module.instantiateWasm callback failed with error: "+a),!1}return wasmBinary||typeof WebAssembly.instantiateStreaming!="function"||isDataURI(wasmBinaryFile)||isFileURI(wasmBinaryFile)||ENVIRONMENT_IS_NODE||typeof fetch!="function"?r(n):fetch(wasmBinaryFile,{credentials:"same-origin"}).then((function(a){return WebAssembly.instantiateStreaming(a,e).then(n,(function(o){return err("wasm streaming compile failed: "+o),err("falling back to ArrayBuffer instantiation"),r(n)}))})),{}}wasmBinaryFile="tree-sitter.wasm",isDataURI(wasmBinaryFile)||(wasmBinaryFile=locateFile(wasmBinaryFile));var ASM_CONSTS={};function ExitStatus(e){this.name="ExitStatus",this.message="Program terminated with exit("+e+")",this.status=e}var GOT={},CurrentModuleWeakSymbols=new Set([]),GOTHandler={get:function(e,t){var n=GOT[t];return n||(n=GOT[t]=new WebAssembly.Global({value:"i32",mutable:!0})),CurrentModuleWeakSymbols.has(t)||(n.required=!0),n}};function callRuntimeCallbacks(e){for(;e.length>0;)e.shift()(Module)}function getDylinkMetadata(e){var t=0,n=0;function r(){for(var A=0,M=1;;){var L=e[t++];if(A+=(127&L)*M,M*=128,!(128&L))break}return A}function a(){var A=r();return UTF8ArrayToString(e,(t+=A)-A,A)}function o(A,M){if(A)throw new Error(M)}var c="dylink.0";if(e instanceof WebAssembly.Module){var d=WebAssembly.Module.customSections(e,c);d.length===0&&(c="dylink",d=WebAssembly.Module.customSections(e,c)),o(d.length===0,"need dylink section"),n=(e=new Uint8Array(d[0])).length}else{o(new Uint32Array(new Uint8Array(e.subarray(0,24)).buffer)[0]!=1836278016,"need to see wasm magic number"),o(e[8]!==0,"need the dylink section to be first"),t=9;var p=r();n=t+p,c=a()}var w={neededDynlibs:[],tlsExports:new Set,weakImports:new Set};if(c=="dylink"){w.memorySize=r(),w.memoryAlign=r(),w.tableSize=r(),w.tableAlign=r();for(var b=r(),T=0;T<b;++T){var x=a();w.neededDynlibs.push(x)}}else for(o(c!=="dylink.0");t<n;){var z=e[t++],B=r();if(z===1)w.memorySize=r(),w.memoryAlign=r(),w.tableSize=r(),w.tableAlign=r();else if(z===2)for(b=r(),T=0;T<b;++T)x=a(),w.neededDynlibs.push(x);else if(z===3)for(var N=r();N--;){var k=a();256&r()&&w.tlsExports.add(k)}else if(z===4)for(N=r();N--;)a(),k=a(),(3&r())==1&&w.weakImports.add(k);else t+=B}return w}function getValue(e,t="i8"){switch(t.endsWith("*")&&(t="*"),t){case"i1":case"i8":return HEAP8[e>>0];case"i16":return HEAP16[e>>1];case"i32":case"i64":return HEAP32[e>>2];case"float":return HEAPF32[e>>2];case"double":return HEAPF64[e>>3];case"*":return HEAPU32[e>>2];default:abort("invalid type for getValue: "+t)}return null}function asmjsMangle(e){return e.indexOf("dynCall_")==0||["stackAlloc","stackSave","stackRestore","getTempRet0","setTempRet0"].includes(e)?e:"_"+e}function mergeLibSymbols(e,t){for(var n in e)if(e.hasOwnProperty(n)){asmLibraryArg.hasOwnProperty(n)||(asmLibraryArg[n]=e[n]);var r=asmjsMangle(n);Module.hasOwnProperty(r)||(Module[r]=e[n]),n=="__main_argc_argv"&&(Module._main=e[n])}}var LDSO={loadedLibsByName:{},loadedLibsByHandle:{}};function dynCallLegacy(e,t,n){var r=Module["dynCall_"+e];return n&&n.length?r.apply(null,[t].concat(n)):r.call(null,t)}var wasmTableMirror=[];function getWasmTableEntry(e){var t=wasmTableMirror[e];return t||(e>=wasmTableMirror.length&&(wasmTableMirror.length=e+1),wasmTableMirror[e]=t=wasmTable.get(e)),t}function dynCall(e,t,n){return e.includes("j")?dynCallLegacy(e,t,n):getWasmTableEntry(t).apply(null,n)}function createInvokeFunction(e){return function(){var t=stackSave();try{return dynCall(e,arguments[0],Array.prototype.slice.call(arguments,1))}catch(n){if(stackRestore(t),n!==n+0)throw n;_setThrew(1,0)}}}var ___heap_base=78144;function zeroMemory(e,t){return HEAPU8.fill(0,e,e+t),e}function getMemory(e){if(runtimeInitialized)return zeroMemory(_malloc(e),e);var t=___heap_base,n=t+e+15&-16;return ___heap_base=n,GOT.__heap_base.value=n,t}function isInternalSym(e){return["__cpp_exception","__c_longjmp","__wasm_apply_data_relocs","__dso_handle","__tls_size","__tls_align","__set_stack_limits","_emscripten_tls_init","__wasm_init_tls","__wasm_call_ctors","__start_em_asm","__stop_em_asm"].includes(e)}function uleb128Encode(e,t){e<128?t.push(e):t.push(e%128|128,e>>7)}function sigToWasmTypes(e){for(var t={i:"i32",j:"i32",f:"f32",d:"f64",p:"i32"},n={parameters:[],results:e[0]=="v"?[]:[t[e[0]]]},r=1;r<e.length;++r)n.parameters.push(t[e[r]]),e[r]==="j"&&n.parameters.push("i32");return n}function generateFuncType(e,t){var n=e.slice(0,1),r=e.slice(1),a={i:127,p:127,j:126,f:125,d:124};t.push(96),uleb128Encode(r.length,t);for(var o=0;o<r.length;++o)t.push(a[r[o]]);n=="v"?t.push(0):t.push(1,a[n])}function convertJsFunctionToWasm(e,t){if(typeof WebAssembly.Function=="function")return new WebAssembly.Function(sigToWasmTypes(t),e);var n=[1];generateFuncType(t,n);var r=[0,97,115,109,1,0,0,0,1];uleb128Encode(n.length,r),r.push.apply(r,n),r.push(2,7,1,1,101,1,102,0,0,7,5,1,1,102,0,0);var a=new WebAssembly.Module(new Uint8Array(r));return new WebAssembly.Instance(a,{e:{f:e}}).exports.f}function updateTableMap(e,t){if(functionsInTableMap)for(var n=e;n<e+t;n++){var r=getWasmTableEntry(n);r&&functionsInTableMap.set(r,n)}}var functionsInTableMap=void 0,freeTableIndexes=[];function getEmptyTableSlot(){if(freeTableIndexes.length)return freeTableIndexes.pop();try{wasmTable.grow(1)}catch(e){throw e instanceof RangeError?"Unable to grow wasm table. Set ALLOW_TABLE_GROWTH.":e}return wasmTable.length-1}function setWasmTableEntry(e,t){wasmTable.set(e,t),wasmTableMirror[e]=wasmTable.get(e)}function addFunction(e,t){if(functionsInTableMap||(functionsInTableMap=new WeakMap,updateTableMap(0,wasmTable.length)),functionsInTableMap.has(e))return functionsInTableMap.get(e);var n=getEmptyTableSlot();try{setWasmTableEntry(n,e)}catch(r){if(!(r instanceof TypeError))throw r;setWasmTableEntry(n,convertJsFunctionToWasm(e,t))}return functionsInTableMap.set(e,n),n}function updateGOT(e,t){for(var n in e)if(!isInternalSym(n)){var r=e[n];n.startsWith("orig$")&&(n=n.split("$")[1],t=!0),GOT[n]||(GOT[n]=new WebAssembly.Global({value:"i32",mutable:!0})),(t||GOT[n].value==0)&&(typeof r=="function"?GOT[n].value=addFunction(r):typeof r=="number"?GOT[n].value=r:err("unhandled export type for `"+n+"`: "+typeof r))}}function relocateExports(e,t,n){var r={};for(var a in e){var o=e[a];typeof o=="object"&&(o=o.value),typeof o=="number"&&(o+=t),r[a]=o}return updateGOT(r,n),r}function resolveGlobalSymbol(e,t){var n;return t&&(n=asmLibraryArg["orig$"+e]),n||(n=asmLibraryArg[e])&&n.stub&&(n=void 0),n||(n=Module[asmjsMangle(e)]),!n&&e.startsWith("invoke_")&&(n=createInvokeFunction(e.split("_")[1])),n}function alignMemory(e,t){return Math.ceil(e/t)*t}function loadWebAssemblyModule(binary,flags,handle){var metadata=getDylinkMetadata(binary);function loadModule(){var firstLoad=!handle||!HEAP8[handle+12>>0];if(firstLoad){var memAlign=Math.pow(2,metadata.memoryAlign);memAlign=Math.max(memAlign,STACK_ALIGN);var memoryBase=metadata.memorySize?alignMemory(getMemory(metadata.memorySize+memAlign),memAlign):0,tableBase=metadata.tableSize?wasmTable.length:0;handle&&(HEAP8[handle+12>>0]=1,HEAPU32[handle+16>>2]=memoryBase,HEAP32[handle+20>>2]=metadata.memorySize,HEAPU32[handle+24>>2]=tableBase,HEAP32[handle+28>>2]=metadata.tableSize)}else memoryBase=HEAPU32[handle+16>>2],tableBase=HEAPU32[handle+24>>2];var tableGrowthNeeded=tableBase+metadata.tableSize-wasmTable.length,moduleExports;function resolveSymbol(e){var t=resolveGlobalSymbol(e,!1);return t||(t=moduleExports[e]),t}tableGrowthNeeded>0&&wasmTable.grow(tableGrowthNeeded);var proxyHandler={get:function(e,t){switch(t){case"__memory_base":return memoryBase;case"__table_base":return tableBase}if(t in asmLibraryArg)return asmLibraryArg[t];var n;return t in e||(e[t]=function(){return n||(n=resolveSymbol(t)),n.apply(null,arguments)}),e[t]}},proxy=new Proxy({},proxyHandler),info={"GOT.mem":new Proxy({},GOTHandler),"GOT.func":new Proxy({},GOTHandler),env:proxy,wasi_snapshot_preview1:proxy};function postInstantiation(instance){function addEmAsm(addr,body){for(var args=[],arity=0;arity<16&&body.indexOf("$"+arity)!=-1;arity++)args.push("$"+arity);args=args.join(",");var func="("+args+" ) => { "+body+"};";ASM_CONSTS[start]=eval(func)}if(updateTableMap(tableBase,metadata.tableSize),moduleExports=relocateExports(instance.exports,memoryBase),flags.allowUndefined||reportUndefinedSymbols(),"__start_em_asm"in moduleExports)for(var start=moduleExports.__start_em_asm,stop=moduleExports.__stop_em_asm;start<stop;){var jsString=UTF8ToString(start);addEmAsm(start,jsString),start=HEAPU8.indexOf(0,start)+1}var applyRelocs=moduleExports.__wasm_apply_data_relocs;applyRelocs&&(runtimeInitialized?applyRelocs():__RELOC_FUNCS__.push(applyRelocs));var init=moduleExports.__wasm_call_ctors;return init&&(runtimeInitialized?init():__ATINIT__.push(init)),moduleExports}if(flags.loadAsync){if(binary instanceof WebAssembly.Module){var instance=new WebAssembly.Instance(binary,info);return Promise.resolve(postInstantiation(instance))}return WebAssembly.instantiate(binary,info).then((function(e){return postInstantiation(e.instance)}))}var module=binary instanceof WebAssembly.Module?binary:new WebAssembly.Module(binary),instance=new WebAssembly.Instance(module,info);return postInstantiation(instance)}return CurrentModuleWeakSymbols=metadata.weakImports,flags.loadAsync?metadata.neededDynlibs.reduce((function(e,t){return e.then((function(){return loadDynamicLibrary(t,flags)}))}),Promise.resolve()).then((function(){return loadModule()})):(metadata.neededDynlibs.forEach((function(e){loadDynamicLibrary(e,flags)})),loadModule())}function loadDynamicLibrary(e,t,n){t=t||{global:!0,nodelete:!0};var r=LDSO.loadedLibsByName[e];if(r)return t.global&&!r.global&&(r.global=!0,r.module!=="loading"&&mergeLibSymbols(r.module,e)),t.nodelete&&r.refcount!==1/0&&(r.refcount=1/0),r.refcount++,n&&(LDSO.loadedLibsByHandle[n]=r),!t.loadAsync||Promise.resolve(!0);function a(d){if(t.fs&&t.fs.findObject(d)){var p=t.fs.readFile(d,{encoding:"binary"});return p instanceof Uint8Array||(p=new Uint8Array(p)),t.loadAsync?Promise.resolve(p):p}if(d=locateFile(d),t.loadAsync)return new Promise((function(w,b){readAsync(d,(T=>w(new Uint8Array(T))),b)}));if(!readBinary)throw new Error(d+": file not found, and synchronous loading of external files is not available");return readBinary(d)}function o(){if(typeof preloadedWasm<"u"&&preloadedWasm[e]){var d=preloadedWasm[e];return t.loadAsync?Promise.resolve(d):d}return t.loadAsync?a(e).then((function(p){return loadWebAssemblyModule(p,t,n)})):loadWebAssemblyModule(a(e),t,n)}function c(d){r.global&&mergeLibSymbols(d,e),r.module=d}return r={refcount:t.nodelete?1/0:1,name:e,module:"loading",global:t.global},LDSO.loadedLibsByName[e]=r,n&&(LDSO.loadedLibsByHandle[n]=r),t.loadAsync?o().then((function(d){return c(d),!0})):(c(o()),!0)}function reportUndefinedSymbols(){for(var e in GOT)if(GOT[e].value==0){var t=resolveGlobalSymbol(e,!0);if(!t&&!GOT[e].required)continue;if(typeof t=="function")GOT[e].value=addFunction(t,t.sig);else{if(typeof t!="number")throw new Error("bad export type for `"+e+"`: "+typeof t);GOT[e].value=t}}}function preloadDylibs(){dynamicLibraries.length?(addRunDependency("preloadDylibs"),dynamicLibraries.reduce((function(e,t){return e.then((function(){return loadDynamicLibrary(t,{loadAsync:!0,global:!0,nodelete:!0,allowUndefined:!0})}))}),Promise.resolve()).then((function(){reportUndefinedSymbols(),removeRunDependency("preloadDylibs")}))):reportUndefinedSymbols()}function setValue(e,t,n="i8"){switch(n.endsWith("*")&&(n="*"),n){case"i1":case"i8":HEAP8[e>>0]=t;break;case"i16":HEAP16[e>>1]=t;break;case"i32":HEAP32[e>>2]=t;break;case"i64":tempI64=[t>>>0,(tempDouble=t,+Math.abs(tempDouble)>=1?tempDouble>0?(0|Math.min(+Math.floor(tempDouble/4294967296),4294967295))>>>0:~~+Math.ceil((tempDouble-+(~~tempDouble>>>0))/4294967296)>>>0:0)],HEAP32[e>>2]=tempI64[0],HEAP32[e+4>>2]=tempI64[1];break;case"float":HEAPF32[e>>2]=t;break;case"double":HEAPF64[e>>3]=t;break;case"*":HEAPU32[e>>2]=t;break;default:abort("invalid type for setValue: "+n)}}var ___memory_base=new WebAssembly.Global({value:"i32",mutable:!1},1024),___stack_pointer=new WebAssembly.Global({value:"i32",mutable:!0},78144),___table_base=new WebAssembly.Global({value:"i32",mutable:!1},1),nowIsMonotonic=!0,_emscripten_get_now;function __emscripten_get_now_is_monotonic(){return nowIsMonotonic}function _abort(){abort("")}function _emscripten_date_now(){return Date.now()}function _emscripten_memcpy_big(e,t,n){HEAPU8.copyWithin(e,t,t+n)}function getHeapMax(){return 2147483648}function emscripten_realloc_buffer(e){try{return wasmMemory.grow(e-buffer.byteLength+65535>>>16),updateGlobalBufferAndViews(wasmMemory.buffer),1}catch{}}function _emscripten_resize_heap(e){var t=HEAPU8.length;e>>>=0;var n=getHeapMax();if(e>n)return!1;for(var r=1;r<=4;r*=2){var a=t*(1+.2/r);if(a=Math.min(a,e+100663296),emscripten_realloc_buffer(Math.min(n,(o=Math.max(e,a))+((c=65536)-o%c)%c)))return!0}var o,c;return!1}__emscripten_get_now_is_monotonic.sig="i",Module._abort=_abort,_abort.sig="v",_emscripten_date_now.sig="d",_emscripten_get_now=ENVIRONMENT_IS_NODE?()=>{var e=process.hrtime();return 1e3*e[0]+e[1]/1e6}:()=>performance.now(),_emscripten_get_now.sig="d",_emscripten_memcpy_big.sig="vppp",_emscripten_resize_heap.sig="ip";var SYSCALLS={DEFAULT_POLLMASK:5,calculateAt:function(e,t,n){if(PATH.isAbs(t))return t;var r;if(e===-100?r=FS.cwd():r=SYSCALLS.getStreamFromFD(e).path,t.length==0){if(!n)throw new FS.ErrnoError(44);return r}return PATH.join2(r,t)},doStat:function(e,t,n){try{var r=e(t)}catch(d){if(d&&d.node&&PATH.normalize(t)!==PATH.normalize(FS.getPath(d.node)))return-54;throw d}HEAP32[n>>2]=r.dev,HEAP32[n+8>>2]=r.ino,HEAP32[n+12>>2]=r.mode,HEAPU32[n+16>>2]=r.nlink,HEAP32[n+20>>2]=r.uid,HEAP32[n+24>>2]=r.gid,HEAP32[n+28>>2]=r.rdev,tempI64=[r.size>>>0,(tempDouble=r.size,+Math.abs(tempDouble)>=1?tempDouble>0?(0|Math.min(+Math.floor(tempDouble/4294967296),4294967295))>>>0:~~+Math.ceil((tempDouble-+(~~tempDouble>>>0))/4294967296)>>>0:0)],HEAP32[n+40>>2]=tempI64[0],HEAP32[n+44>>2]=tempI64[1],HEAP32[n+48>>2]=4096,HEAP32[n+52>>2]=r.blocks;var a=r.atime.getTime(),o=r.mtime.getTime(),c=r.ctime.getTime();return tempI64=[Math.floor(a/1e3)>>>0,(tempDouble=Math.floor(a/1e3),+Math.abs(tempDouble)>=1?tempDouble>0?(0|Math.min(+Math.floor(tempDouble/4294967296),4294967295))>>>0:~~+Math.ceil((tempDouble-+(~~tempDouble>>>0))/4294967296)>>>0:0)],HEAP32[n+56>>2]=tempI64[0],HEAP32[n+60>>2]=tempI64[1],HEAPU32[n+64>>2]=a%1e3*1e3,tempI64=[Math.floor(o/1e3)>>>0,(tempDouble=Math.floor(o/1e3),+Math.abs(tempDouble)>=1?tempDouble>0?(0|Math.min(+Math.floor(tempDouble/4294967296),4294967295))>>>0:~~+Math.ceil((tempDouble-+(~~tempDouble>>>0))/4294967296)>>>0:0)],HEAP32[n+72>>2]=tempI64[0],HEAP32[n+76>>2]=tempI64[1],HEAPU32[n+80>>2]=o%1e3*1e3,tempI64=[Math.floor(c/1e3)>>>0,(tempDouble=Math.floor(c/1e3),+Math.abs(tempDouble)>=1?tempDouble>0?(0|Math.min(+Math.floor(tempDouble/4294967296),4294967295))>>>0:~~+Math.ceil((tempDouble-+(~~tempDouble>>>0))/4294967296)>>>0:0)],HEAP32[n+88>>2]=tempI64[0],HEAP32[n+92>>2]=tempI64[1],HEAPU32[n+96>>2]=c%1e3*1e3,tempI64=[r.ino>>>0,(tempDouble=r.ino,+Math.abs(tempDouble)>=1?tempDouble>0?(0|Math.min(+Math.floor(tempDouble/4294967296),4294967295))>>>0:~~+Math.ceil((tempDouble-+(~~tempDouble>>>0))/4294967296)>>>0:0)],HEAP32[n+104>>2]=tempI64[0],HEAP32[n+108>>2]=tempI64[1],0},doMsync:function(e,t,n,r,a){if(!FS.isFile(t.node.mode))throw new FS.ErrnoError(43);if(2&r)return 0;var o=HEAPU8.slice(e,e+n);FS.msync(t,o,a,n,r)},varargs:void 0,get:function(){return SYSCALLS.varargs+=4,HEAP32[SYSCALLS.varargs-4>>2]},getStr:function(e){return UTF8ToString(e)},getStreamFromFD:function(e){var t=FS.getStream(e);if(!t)throw new FS.ErrnoError(8);return t}};function _proc_exit(e){EXITSTATUS=e,keepRuntimeAlive()||(Module.onExit&&Module.onExit(e),ABORT=!0),quit_(e,new ExitStatus(e))}function exitJS(e,t){EXITSTATUS=e,_proc_exit(e)}_proc_exit.sig="vi";var _exit=exitJS;function _fd_close(e){try{var t=SYSCALLS.getStreamFromFD(e);return FS.close(t),0}catch(n){if(typeof FS>"u"||!(n instanceof FS.ErrnoError))throw n;return n.errno}}function convertI32PairToI53Checked(e,t){return t+2097152>>>0<4194305-!!e?(e>>>0)+4294967296*t:NaN}function _fd_seek(e,t,n,r,a){try{var o=convertI32PairToI53Checked(t,n);if(isNaN(o))return 61;var c=SYSCALLS.getStreamFromFD(e);return FS.llseek(c,o,r),tempI64=[c.position>>>0,(tempDouble=c.position,+Math.abs(tempDouble)>=1?tempDouble>0?(0|Math.min(+Math.floor(tempDouble/4294967296),4294967295))>>>0:~~+Math.ceil((tempDouble-+(~~tempDouble>>>0))/4294967296)>>>0:0)],HEAP32[a>>2]=tempI64[0],HEAP32[a+4>>2]=tempI64[1],c.getdents&&o===0&&r===0&&(c.getdents=null),0}catch(d){if(typeof FS>"u"||!(d instanceof FS.ErrnoError))throw d;return d.errno}}function doWritev(e,t,n,r){for(var a=0,o=0;o<n;o++){var c=HEAPU32[t>>2],d=HEAPU32[t+4>>2];t+=8;var p=FS.write(e,HEAP8,c,d,r);if(p<0)return-1;a+=p,r!==void 0&&(r+=p)}return a}function _fd_write(e,t,n,r){try{var a=doWritev(SYSCALLS.getStreamFromFD(e),t,n);return HEAPU32[r>>2]=a,0}catch(o){if(typeof FS>"u"||!(o instanceof FS.ErrnoError))throw o;return o.errno}}function _tree_sitter_log_callback(e,t){if(currentLogCallback){let n=UTF8ToString(t);currentLogCallback(n,e!==0)}}function _tree_sitter_parse_callback(e,t,n,r,a){var o=currentParseCallback(t,{row:n,column:r});typeof o=="string"?(setValue(a,o.length,"i32"),stringToUTF16(o,e,10240)):setValue(a,0,"i32")}function handleException(e){if(e instanceof ExitStatus||e=="unwind")return EXITSTATUS;quit_(1,e)}function allocateUTF8OnStack(e){var t=lengthBytesUTF8(e)+1,n=stackAlloc(t);return stringToUTF8Array(e,HEAP8,n,t),n}function stringToUTF16(e,t,n){if(n===void 0&&(n=2147483647),n<2)return 0;for(var r=t,a=(n-=2)<2*e.length?n/2:e.length,o=0;o<a;++o){var c=e.charCodeAt(o);HEAP16[t>>1]=c,t+=2}return HEAP16[t>>1]=0,t-r}function AsciiToString(e){for(var t="";;){var n=HEAPU8[e++>>0];if(!n)return t;t+=String.fromCharCode(n)}}_exit.sig="vi",_fd_close.sig="ii",_fd_seek.sig="iijip",_fd_write.sig="iippp";var asmLibraryArg={__heap_base:___heap_base,__indirect_function_table:wasmTable,__memory_base:___memory_base,__stack_pointer:___stack_pointer,__table_base:___table_base,_emscripten_get_now_is_monotonic:__emscripten_get_now_is_monotonic,abort:_abort,emscripten_get_now:_emscripten_get_now,emscripten_memcpy_big:_emscripten_memcpy_big,emscripten_resize_heap:_emscripten_resize_heap,exit:_exit,fd_close:_fd_close,fd_seek:_fd_seek,fd_write:_fd_write,memory:wasmMemory,tree_sitter_log_callback:_tree_sitter_log_callback,tree_sitter_parse_callback:_tree_sitter_parse_callback},asm=createWasm(),___wasm_call_ctors=Module.___wasm_call_ctors=function(){return(___wasm_call_ctors=Module.___wasm_call_ctors=Module.asm.__wasm_call_ctors).apply(null,arguments)},___wasm_apply_data_relocs=Module.___wasm_apply_data_relocs=function(){return(___wasm_apply_data_relocs=Module.___wasm_apply_data_relocs=Module.asm.__wasm_apply_data_relocs).apply(null,arguments)},_malloc=Module._malloc=function(){return(_malloc=Module._malloc=Module.asm.malloc).apply(null,arguments)},_calloc=Module._calloc=function(){return(_calloc=Module._calloc=Module.asm.calloc).apply(null,arguments)},_realloc=Module._realloc=function(){return(_realloc=Module._realloc=Module.asm.realloc).apply(null,arguments)},_free=Module._free=function(){return(_free=Module._free=Module.asm.free).apply(null,arguments)},_ts_language_symbol_count=Module._ts_language_symbol_count=function(){return(_ts_language_symbol_count=Module._ts_language_symbol_count=Module.asm.ts_language_symbol_count).apply(null,arguments)},_ts_language_version=Module._ts_language_version=function(){return(_ts_language_version=Module._ts_language_version=Module.asm.ts_language_version).apply(null,arguments)},_ts_language_field_count=Module._ts_language_field_count=function(){return(_ts_language_field_count=Module._ts_language_field_count=Module.asm.ts_language_field_count).apply(null,arguments)},_ts_language_symbol_name=Module._ts_language_symbol_name=function(){return(_ts_language_symbol_name=Module._ts_language_symbol_name=Module.asm.ts_language_symbol_name).apply(null,arguments)},_ts_language_symbol_for_name=Module._ts_language_symbol_for_name=function(){return(_ts_language_symbol_for_name=Module._ts_language_symbol_for_name=Module.asm.ts_language_symbol_for_name).apply(null,arguments)},_ts_language_symbol_type=Module._ts_language_symbol_type=function(){return(_ts_language_symbol_type=Module._ts_language_symbol_type=Module.asm.ts_language_symbol_type).apply(null,arguments)},_ts_language_field_name_for_id=Module._ts_language_field_name_for_id=function(){return(_ts_language_field_name_for_id=Module._ts_language_field_name_for_id=Module.asm.ts_language_field_name_for_id).apply(null,arguments)},_memset=Module._memset=function(){return(_memset=Module._memset=Module.asm.memset).apply(null,arguments)},_memcpy=Module._memcpy=function(){return(_memcpy=Module._memcpy=Module.asm.memcpy).apply(null,arguments)},_ts_parser_delete=Module._ts_parser_delete=function(){return(_ts_parser_delete=Module._ts_parser_delete=Module.asm.ts_parser_delete).apply(null,arguments)},_ts_parser_reset=Module._ts_parser_reset=function(){return(_ts_parser_reset=Module._ts_parser_reset=Module.asm.ts_parser_reset).apply(null,arguments)},_ts_parser_set_language=Module._ts_parser_set_language=function(){return(_ts_parser_set_language=Module._ts_parser_set_language=Module.asm.ts_parser_set_language).apply(null,arguments)},_ts_parser_timeout_micros=Module._ts_parser_timeout_micros=function(){return(_ts_parser_timeout_micros=Module._ts_parser_timeout_micros=Module.asm.ts_parser_timeout_micros).apply(null,arguments)},_ts_parser_set_timeout_micros=Module._ts_parser_set_timeout_micros=function(){return(_ts_parser_set_timeout_micros=Module._ts_parser_set_timeout_micros=Module.asm.ts_parser_set_timeout_micros).apply(null,arguments)},_memmove=Module._memmove=function(){return(_memmove=Module._memmove=Module.asm.memmove).apply(null,arguments)},_memcmp=Module._memcmp=function(){return(_memcmp=Module._memcmp=Module.asm.memcmp).apply(null,arguments)},_ts_query_new=Module._ts_query_new=function(){return(_ts_query_new=Module._ts_query_new=Module.asm.ts_query_new).apply(null,arguments)},_ts_query_delete=Module._ts_query_delete=function(){return(_ts_query_delete=Module._ts_query_delete=Module.asm.ts_query_delete).apply(null,arguments)},_iswspace=Module._iswspace=function(){return(_iswspace=Module._iswspace=Module.asm.iswspace).apply(null,arguments)},_iswalnum=Module._iswalnum=function(){return(_iswalnum=Module._iswalnum=Module.asm.iswalnum).apply(null,arguments)},_ts_query_pattern_count=Module._ts_query_pattern_count=function(){return(_ts_query_pattern_count=Module._ts_query_pattern_count=Module.asm.ts_query_pattern_count).apply(null,arguments)},_ts_query_capture_count=Module._ts_query_capture_count=function(){return(_ts_query_capture_count=Module._ts_query_capture_count=Module.asm.ts_query_capture_count).apply(null,arguments)},_ts_query_string_count=Module._ts_query_string_count=function(){return(_ts_query_string_count=Module._ts_query_string_count=Module.asm.ts_query_string_count).apply(null,arguments)},_ts_query_capture_name_for_id=Module._ts_query_capture_name_for_id=function(){return(_ts_query_capture_name_for_id=Module._ts_query_capture_name_for_id=Module.asm.ts_query_capture_name_for_id).apply(null,arguments)},_ts_query_string_value_for_id=Module._ts_query_string_value_for_id=function(){return(_ts_query_string_value_for_id=Module._ts_query_string_value_for_id=Module.asm.ts_query_string_value_for_id).apply(null,arguments)},_ts_query_predicates_for_pattern=Module._ts_query_predicates_for_pattern=function(){return(_ts_query_predicates_for_pattern=Module._ts_query_predicates_for_pattern=Module.asm.ts_query_predicates_for_pattern).apply(null,arguments)},_ts_tree_copy=Module._ts_tree_copy=function(){return(_ts_tree_copy=Module._ts_tree_copy=Module.asm.ts_tree_copy).apply(null,arguments)},_ts_tree_delete=Module._ts_tree_delete=function(){return(_ts_tree_delete=Module._ts_tree_delete=Module.asm.ts_tree_delete).apply(null,arguments)},_ts_init=Module._ts_init=function(){return(_ts_init=Module._ts_init=Module.asm.ts_init).apply(null,arguments)},_ts_parser_new_wasm=Module._ts_parser_new_wasm=function(){return(_ts_parser_new_wasm=Module._ts_parser_new_wasm=Module.asm.ts_parser_new_wasm).apply(null,arguments)},_ts_parser_enable_logger_wasm=Module._ts_parser_enable_logger_wasm=function(){return(_ts_parser_enable_logger_wasm=Module._ts_parser_enable_logger_wasm=Module.asm.ts_parser_enable_logger_wasm).apply(null,arguments)},_ts_parser_parse_wasm=Module._ts_parser_parse_wasm=function(){return(_ts_parser_parse_wasm=Module._ts_parser_parse_wasm=Module.asm.ts_parser_parse_wasm).apply(null,arguments)},_ts_language_type_is_named_wasm=Module._ts_language_type_is_named_wasm=function(){return(_ts_language_type_is_named_wasm=Module._ts_language_type_is_named_wasm=Module.asm.ts_language_type_is_named_wasm).apply(null,arguments)},_ts_language_type_is_visible_wasm=Module._ts_language_type_is_visible_wasm=function(){return(_ts_language_type_is_visible_wasm=Module._ts_language_type_is_visible_wasm=Module.asm.ts_language_type_is_visible_wasm).apply(null,arguments)},_ts_tree_root_node_wasm=Module._ts_tree_root_node_wasm=function(){return(_ts_tree_root_node_wasm=Module._ts_tree_root_node_wasm=Module.asm.ts_tree_root_node_wasm).apply(null,arguments)},_ts_tree_edit_wasm=Module._ts_tree_edit_wasm=function(){return(_ts_tree_edit_wasm=Module._ts_tree_edit_wasm=Module.asm.ts_tree_edit_wasm).apply(null,arguments)},_ts_tree_get_changed_ranges_wasm=Module._ts_tree_get_changed_ranges_wasm=function(){return(_ts_tree_get_changed_ranges_wasm=Module._ts_tree_get_changed_ranges_wasm=Module.asm.ts_tree_get_changed_ranges_wasm).apply(null,arguments)},_ts_tree_cursor_new_wasm=Module._ts_tree_cursor_new_wasm=function(){return(_ts_tree_cursor_new_wasm=Module._ts_tree_cursor_new_wasm=Module.asm.ts_tree_cursor_new_wasm).apply(null,arguments)},_ts_tree_cursor_delete_wasm=Module._ts_tree_cursor_delete_wasm=function(){return(_ts_tree_cursor_delete_wasm=Module._ts_tree_cursor_delete_wasm=Module.asm.ts_tree_cursor_delete_wasm).apply(null,arguments)},_ts_tree_cursor_reset_wasm=Module._ts_tree_cursor_reset_wasm=function(){return(_ts_tree_cursor_reset_wasm=Module._ts_tree_cursor_reset_wasm=Module.asm.ts_tree_cursor_reset_wasm).apply(null,arguments)},_ts_tree_cursor_goto_first_child_wasm=Module._ts_tree_cursor_goto_first_child_wasm=function(){return(_ts_tree_cursor_goto_first_child_wasm=Module._ts_tree_cursor_goto_first_child_wasm=Module.asm.ts_tree_cursor_goto_first_child_wasm).apply(null,arguments)},_ts_tree_cursor_goto_next_sibling_wasm=Module._ts_tree_cursor_goto_next_sibling_wasm=function(){return(_ts_tree_cursor_goto_next_sibling_wasm=Module._ts_tree_cursor_goto_next_sibling_wasm=Module.asm.ts_tree_cursor_goto_next_sibling_wasm).apply(null,arguments)},_ts_tree_cursor_goto_parent_wasm=Module._ts_tree_cursor_goto_parent_wasm=function(){return(_ts_tree_cursor_goto_parent_wasm=Module._ts_tree_cursor_goto_parent_wasm=Module.asm.ts_tree_cursor_goto_parent_wasm).apply(null,arguments)},_ts_tree_cursor_current_node_type_id_wasm=Module._ts_tree_cursor_current_node_type_id_wasm=function(){return(_ts_tree_cursor_current_node_type_id_wasm=Module._ts_tree_cursor_current_node_type_id_wasm=Module.asm.ts_tree_cursor_current_node_type_id_wasm).apply(null,arguments)},_ts_tree_cursor_current_node_is_named_wasm=Module._ts_tree_cursor_current_node_is_named_wasm=function(){return(_ts_tree_cursor_current_node_is_named_wasm=Module._ts_tree_cursor_current_node_is_named_wasm=Module.asm.ts_tree_cursor_current_node_is_named_wasm).apply(null,arguments)},_ts_tree_cursor_current_node_is_missing_wasm=Module._ts_tree_cursor_current_node_is_missing_wasm=function(){return(_ts_tree_cursor_current_node_is_missing_wasm=Module._ts_tree_cursor_current_node_is_missing_wasm=Module.asm.ts_tree_cursor_current_node_is_missing_wasm).apply(null,arguments)},_ts_tree_cursor_current_node_id_wasm=Module._ts_tree_cursor_current_node_id_wasm=function(){return(_ts_tree_cursor_current_node_id_wasm=Module._ts_tree_cursor_current_node_id_wasm=Module.asm.ts_tree_cursor_current_node_id_wasm).apply(null,arguments)},_ts_tree_cursor_start_position_wasm=Module._ts_tree_cursor_start_position_wasm=function(){return(_ts_tree_cursor_start_position_wasm=Module._ts_tree_cursor_start_position_wasm=Module.asm.ts_tree_cursor_start_position_wasm).apply(null,arguments)},_ts_tree_cursor_end_position_wasm=Module._ts_tree_cursor_end_position_wasm=function(){return(_ts_tree_cursor_end_position_wasm=Module._ts_tree_cursor_end_position_wasm=Module.asm.ts_tree_cursor_end_position_wasm).apply(null,arguments)},_ts_tree_cursor_start_index_wasm=Module._ts_tree_cursor_start_index_wasm=function(){return(_ts_tree_cursor_start_index_wasm=Module._ts_tree_cursor_start_index_wasm=Module.asm.ts_tree_cursor_start_index_wasm).apply(null,arguments)},_ts_tree_cursor_end_index_wasm=Module._ts_tree_cursor_end_index_wasm=function(){return(_ts_tree_cursor_end_index_wasm=Module._ts_tree_cursor_end_index_wasm=Module.asm.ts_tree_cursor_end_index_wasm).apply(null,arguments)},_ts_tree_cursor_current_field_id_wasm=Module._ts_tree_cursor_current_field_id_wasm=function(){return(_ts_tree_cursor_current_field_id_wasm=Module._ts_tree_cursor_current_field_id_wasm=Module.asm.ts_tree_cursor_current_field_id_wasm).apply(null,arguments)},_ts_tree_cursor_current_node_wasm=Module._ts_tree_cursor_current_node_wasm=function(){return(_ts_tree_cursor_current_node_wasm=Module._ts_tree_cursor_current_node_wasm=Module.asm.ts_tree_cursor_current_node_wasm).apply(null,arguments)},_ts_node_symbol_wasm=Module._ts_node_symbol_wasm=function(){return(_ts_node_symbol_wasm=Module._ts_node_symbol_wasm=Module.asm.ts_node_symbol_wasm).apply(null,arguments)},_ts_node_child_count_wasm=Module._ts_node_child_count_wasm=function(){return(_ts_node_child_count_wasm=Module._ts_node_child_count_wasm=Module.asm.ts_node_child_count_wasm).apply(null,arguments)},_ts_node_named_child_count_wasm=Module._ts_node_named_child_count_wasm=function(){return(_ts_node_named_child_count_wasm=Module._ts_node_named_child_count_wasm=Module.asm.ts_node_named_child_count_wasm).apply(null,arguments)},_ts_node_child_wasm=Module._ts_node_child_wasm=function(){return(_ts_node_child_wasm=Module._ts_node_child_wasm=Module.asm.ts_node_child_wasm).apply(null,arguments)},_ts_node_named_child_wasm=Module._ts_node_named_child_wasm=function(){return(_ts_node_named_child_wasm=Module._ts_node_named_child_wasm=Module.asm.ts_node_named_child_wasm).apply(null,arguments)},_ts_node_child_by_field_id_wasm=Module._ts_node_child_by_field_id_wasm=function(){return(_ts_node_child_by_field_id_wasm=Module._ts_node_child_by_field_id_wasm=Module.asm.ts_node_child_by_field_id_wasm).apply(null,arguments)},_ts_node_next_sibling_wasm=Module._ts_node_next_sibling_wasm=function(){return(_ts_node_next_sibling_wasm=Module._ts_node_next_sibling_wasm=Module.asm.ts_node_next_sibling_wasm).apply(null,arguments)},_ts_node_prev_sibling_wasm=Module._ts_node_prev_sibling_wasm=function(){return(_ts_node_prev_sibling_wasm=Module._ts_node_prev_sibling_wasm=Module.asm.ts_node_prev_sibling_wasm).apply(null,arguments)},_ts_node_next_named_sibling_wasm=Module._ts_node_next_named_sibling_wasm=function(){return(_ts_node_next_named_sibling_wasm=Module._ts_node_next_named_sibling_wasm=Module.asm.ts_node_next_named_sibling_wasm).apply(null,arguments)},_ts_node_prev_named_sibling_wasm=Module._ts_node_prev_named_sibling_wasm=function(){return(_ts_node_prev_named_sibling_wasm=Module._ts_node_prev_named_sibling_wasm=Module.asm.ts_node_prev_named_sibling_wasm).apply(null,arguments)},_ts_node_parent_wasm=Module._ts_node_parent_wasm=function(){return(_ts_node_parent_wasm=Module._ts_node_parent_wasm=Module.asm.ts_node_parent_wasm).apply(null,arguments)},_ts_node_descendant_for_index_wasm=Module._ts_node_descendant_for_index_wasm=function(){return(_ts_node_descendant_for_index_wasm=Module._ts_node_descendant_for_index_wasm=Module.asm.ts_node_descendant_for_index_wasm).apply(null,arguments)},_ts_node_named_descendant_for_index_wasm=Module._ts_node_named_descendant_for_index_wasm=function(){return(_ts_node_named_descendant_for_index_wasm=Module._ts_node_named_descendant_for_index_wasm=Module.asm.ts_node_named_descendant_for_index_wasm).apply(null,arguments)},_ts_node_descendant_for_position_wasm=Module._ts_node_descendant_for_position_wasm=function(){return(_ts_node_descendant_for_position_wasm=Module._ts_node_descendant_for_position_wasm=Module.asm.ts_node_descendant_for_position_wasm).apply(null,arguments)},_ts_node_named_descendant_for_position_wasm=Module._ts_node_named_descendant_for_position_wasm=function(){return(_ts_node_named_descendant_for_position_wasm=Module._ts_node_named_descendant_for_position_wasm=Module.asm.ts_node_named_descendant_for_position_wasm).apply(null,arguments)},_ts_node_start_point_wasm=Module._ts_node_start_point_wasm=function(){return(_ts_node_start_point_wasm=Module._ts_node_start_point_wasm=Module.asm.ts_node_start_point_wasm).apply(null,arguments)},_ts_node_end_point_wasm=Module._ts_node_end_point_wasm=function(){return(_ts_node_end_point_wasm=Module._ts_node_end_point_wasm=Module.asm.ts_node_end_point_wasm).apply(null,arguments)},_ts_node_start_index_wasm=Module._ts_node_start_index_wasm=function(){return(_ts_node_start_index_wasm=Module._ts_node_start_index_wasm=Module.asm.ts_node_start_index_wasm).apply(null,arguments)},_ts_node_end_index_wasm=Module._ts_node_end_index_wasm=function(){return(_ts_node_end_index_wasm=Module._ts_node_end_index_wasm=Module.asm.ts_node_end_index_wasm).apply(null,arguments)},_ts_node_to_string_wasm=Module._ts_node_to_string_wasm=function(){return(_ts_node_to_string_wasm=Module._ts_node_to_string_wasm=Module.asm.ts_node_to_string_wasm).apply(null,arguments)},_ts_node_children_wasm=Module._ts_node_children_wasm=function(){return(_ts_node_children_wasm=Module._ts_node_children_wasm=Module.asm.ts_node_children_wasm).apply(null,arguments)},_ts_node_named_children_wasm=Module._ts_node_named_children_wasm=function(){return(_ts_node_named_children_wasm=Module._ts_node_named_children_wasm=Module.asm.ts_node_named_children_wasm).apply(null,arguments)},_ts_node_descendants_of_type_wasm=Module._ts_node_descendants_of_type_wasm=function(){return(_ts_node_descendants_of_type_wasm=Module._ts_node_descendants_of_type_wasm=Module.asm.ts_node_descendants_of_type_wasm).apply(null,arguments)},_ts_node_is_named_wasm=Module._ts_node_is_named_wasm=function(){return(_ts_node_is_named_wasm=Module._ts_node_is_named_wasm=Module.asm.ts_node_is_named_wasm).apply(null,arguments)},_ts_node_has_changes_wasm=Module._ts_node_has_changes_wasm=function(){return(_ts_node_has_changes_wasm=Module._ts_node_has_changes_wasm=Module.asm.ts_node_has_changes_wasm).apply(null,arguments)},_ts_node_has_error_wasm=Module._ts_node_has_error_wasm=function(){return(_ts_node_has_error_wasm=Module._ts_node_has_error_wasm=Module.asm.ts_node_has_error_wasm).apply(null,arguments)},_ts_node_is_missing_wasm=Module._ts_node_is_missing_wasm=function(){return(_ts_node_is_missing_wasm=Module._ts_node_is_missing_wasm=Module.asm.ts_node_is_missing_wasm).apply(null,arguments)},_ts_query_matches_wasm=Module._ts_query_matches_wasm=function(){return(_ts_query_matches_wasm=Module._ts_query_matches_wasm=Module.asm.ts_query_matches_wasm).apply(null,arguments)},_ts_query_captures_wasm=Module._ts_query_captures_wasm=function(){return(_ts_query_captures_wasm=Module._ts_query_captures_wasm=Module.asm.ts_query_captures_wasm).apply(null,arguments)},___cxa_atexit=Module.___cxa_atexit=function(){return(___cxa_atexit=Module.___cxa_atexit=Module.asm.__cxa_atexit).apply(null,arguments)},_iswdigit=Module._iswdigit=function(){return(_iswdigit=Module._iswdigit=Module.asm.iswdigit).apply(null,arguments)},_iswalpha=Module._iswalpha=function(){return(_iswalpha=Module._iswalpha=Module.asm.iswalpha).apply(null,arguments)},_iswlower=Module._iswlower=function(){return(_iswlower=Module._iswlower=Module.asm.iswlower).apply(null,arguments)},_memchr=Module._memchr=function(){return(_memchr=Module._memchr=Module.asm.memchr).apply(null,arguments)},_strlen=Module._strlen=function(){return(_strlen=Module._strlen=Module.asm.strlen).apply(null,arguments)},_towupper=Module._towupper=function(){return(_towupper=Module._towupper=Module.asm.towupper).apply(null,arguments)},_setThrew=Module._setThrew=function(){return(_setThrew=Module._setThrew=Module.asm.setThrew).apply(null,arguments)},stackSave=Module.stackSave=function(){return(stackSave=Module.stackSave=Module.asm.stackSave).apply(null,arguments)},stackRestore=Module.stackRestore=function(){return(stackRestore=Module.stackRestore=Module.asm.stackRestore).apply(null,arguments)},stackAlloc=Module.stackAlloc=function(){return(stackAlloc=Module.stackAlloc=Module.asm.stackAlloc).apply(null,arguments)},__Znwm=Module.__Znwm=function(){return(__Znwm=Module.__Znwm=Module.asm._Znwm).apply(null,arguments)},__ZdlPv=Module.__ZdlPv=function(){return(__ZdlPv=Module.__ZdlPv=Module.asm._ZdlPv).apply(null,arguments)},__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev=Module.__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev=function(){return(__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev=Module.__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev=Module.asm._ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEED2Ev).apply(null,arguments)},__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9__grow_byEmmmmmm=Module.__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9__grow_byEmmmmmm=function(){return(__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9__grow_byEmmmmmm=Module.__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9__grow_byEmmmmmm=Module.asm._ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9__grow_byEmmmmmm).apply(null,arguments)},__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6__initEPKcm=Module.__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6__initEPKcm=function(){return(__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6__initEPKcm=Module.__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6__initEPKcm=Module.asm._ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE6__initEPKcm).apply(null,arguments)},__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE7reserveEm=Module.__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE7reserveEm=function(){return(__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE7reserveEm=Module.__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE7reserveEm=Module.asm._ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE7reserveEm).apply(null,arguments)},__ZNKSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4copyEPcmm=Module.__ZNKSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4copyEPcmm=function(){return(__ZNKSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4copyEPcmm=Module.__ZNKSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4copyEPcmm=Module.asm._ZNKSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE4copyEPcmm).apply(null,arguments)},__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc=Module.__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc=function(){return(__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc=Module.__ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc=Module.asm._ZNSt3__212basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE9push_backEc).apply(null,arguments)},__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEED2Ev=Module.__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEED2Ev=function(){return(__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEED2Ev=Module.__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEED2Ev=Module.asm._ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEED2Ev).apply(null,arguments)},__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEE9push_backEw=Module.__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEE9push_backEw=function(){return(__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEE9push_backEw=Module.__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEE9push_backEw=Module.asm._ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEE9push_backEw).apply(null,arguments)},__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEE6resizeEmw=Module.__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEE6resizeEmw=function(){return(__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEE6resizeEmw=Module.__ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEE6resizeEmw=Module.asm._ZNSt3__212basic_stringIwNS_11char_traitsIwEENS_9allocatorIwEEE6resizeEmw).apply(null,arguments)},dynCall_jiji=Module.dynCall_jiji=function(){return(dynCall_jiji=Module.dynCall_jiji=Module.asm.dynCall_jiji).apply(null,arguments)},_orig$ts_parser_timeout_micros=Module._orig$ts_parser_timeout_micros=function(){return(_orig$ts_parser_timeout_micros=Module._orig$ts_parser_timeout_micros=Module.asm.orig$ts_parser_timeout_micros).apply(null,arguments)},_orig$ts_parser_set_timeout_micros=Module._orig$ts_parser_set_timeout_micros=function(){return(_orig$ts_parser_set_timeout_micros=Module._orig$ts_parser_set_timeout_micros=Module.asm.orig$ts_parser_set_timeout_micros).apply(null,arguments)},calledRun;function callMain(e){var t=Module._main;if(t){(e=e||[]).unshift(thisProgram);var n=e.length,r=stackAlloc(4*(n+1)),a=r>>2;e.forEach((c=>{HEAP32[a++]=allocateUTF8OnStack(c)})),HEAP32[a]=0;try{var o=t(n,r);return exitJS(o,!0),o}catch(c){return handleException(c)}}}Module.AsciiToString=AsciiToString,Module.stringToUTF16=stringToUTF16,dependenciesFulfilled=function e(){calledRun||run(),calledRun||(dependenciesFulfilled=e)};var dylibsLoaded=!1;function run(e){function t(){calledRun||(calledRun=!0,Module.calledRun=!0,ABORT||(initRuntime(),preMain(),Module.onRuntimeInitialized&&Module.onRuntimeInitialized(),shouldRunNow&&callMain(e),postRun()))}e=e||arguments_,runDependencies>0||!dylibsLoaded&&(preloadDylibs(),dylibsLoaded=!0,runDependencies>0)||(preRun(),runDependencies>0||(Module.setStatus?(Module.setStatus("Running..."),setTimeout((function(){setTimeout((function(){Module.setStatus("")}),1),t()}),1)):t()))}if(Module.preInit)for(typeof Module.preInit=="function"&&(Module.preInit=[Module.preInit]);Module.preInit.length>0;)Module.preInit.pop()();var shouldRunNow=!0;Module.noInitialRun&&(shouldRunNow=!1),run();let C=Module,INTERNAL={},SIZE_OF_INT=4,SIZE_OF_NODE=5*SIZE_OF_INT,SIZE_OF_POINT=2*SIZE_OF_INT,SIZE_OF_RANGE=2*SIZE_OF_INT+2*SIZE_OF_POINT,ZERO_POINT={row:0,column:0},QUERY_WORD_REGEX=/[\w-.]*/g,PREDICATE_STEP_TYPE_CAPTURE=1,PREDICATE_STEP_TYPE_STRING=2,LANGUAGE_FUNCTION_REGEX=/^_?tree_sitter_\w+/;var VERSION,MIN_COMPATIBLE_VERSION,TRANSFER_BUFFER,currentParseCallback,currentLogCallback;class ParserImpl{static init(){TRANSFER_BUFFER=C._ts_init(),VERSION=getValue(TRANSFER_BUFFER,"i32"),MIN_COMPATIBLE_VERSION=getValue(TRANSFER_BUFFER+SIZE_OF_INT,"i32")}initialize(){C._ts_parser_new_wasm(),this[0]=getValue(TRANSFER_BUFFER,"i32"),this[1]=getValue(TRANSFER_BUFFER+SIZE_OF_INT,"i32")}delete(){C._ts_parser_delete(this[0]),C._free(this[1]),this[0]=0,this[1]=0}setLanguage(t){let n;if(t){if(t.constructor!==Language)throw new Error("Argument must be a Language");{n=t[0];let r=C._ts_language_version(n);if(r<MIN_COMPATIBLE_VERSION||VERSION<r)throw new Error(`Incompatible language version ${r}. Compatibility range ${MIN_COMPATIBLE_VERSION} through ${VERSION}.`)}}else n=0,t=null;return this.language=t,C._ts_parser_set_language(this[0],n),this}getLanguage(){return this.language}parse(t,n,r){if(typeof t=="string")currentParseCallback=(p,w,b)=>t.slice(p,b);else{if(typeof t!="function")throw new Error("Argument must be a string or a function");currentParseCallback=t}this.logCallback?(currentLogCallback=this.logCallback,C._ts_parser_enable_logger_wasm(this[0],1)):(currentLogCallback=null,C._ts_parser_enable_logger_wasm(this[0],0));let a=0,o=0;if(r&&r.includedRanges){a=r.includedRanges.length,o=C._calloc(a,SIZE_OF_RANGE);let p=o;for(let w=0;w<a;w++)marshalRange(p,r.includedRanges[w]),p+=SIZE_OF_RANGE}let c=C._ts_parser_parse_wasm(this[0],this[1],n?n[0]:0,o,a);if(!c)throw currentParseCallback=null,currentLogCallback=null,new Error("Parsing failed");let d=new Tree(INTERNAL,c,this.language,currentParseCallback);return currentParseCallback=null,currentLogCallback=null,d}reset(){C._ts_parser_reset(this[0])}setTimeoutMicros(t){C._ts_parser_set_timeout_micros(this[0],t)}getTimeoutMicros(){return C._ts_parser_timeout_micros(this[0])}setLogger(t){if(t){if(typeof t!="function")throw new Error("Logger callback must be a function")}else t=null;return this.logCallback=t,this}getLogger(){return this.logCallback}}class Tree{constructor(t,n,r,a){assertInternal(t),this[0]=n,this.language=r,this.textCallback=a}copy(){let t=C._ts_tree_copy(this[0]);return new Tree(INTERNAL,t,this.language,this.textCallback)}delete(){C._ts_tree_delete(this[0]),this[0]=0}edit(t){marshalEdit(t),C._ts_tree_edit_wasm(this[0])}get rootNode(){return C._ts_tree_root_node_wasm(this[0]),unmarshalNode(this)}getLanguage(){return this.language}walk(){return this.rootNode.walk()}getChangedRanges(t){if(t.constructor!==Tree)throw new TypeError("Argument must be a Tree");C._ts_tree_get_changed_ranges_wasm(this[0],t[0]);let n=getValue(TRANSFER_BUFFER,"i32"),r=getValue(TRANSFER_BUFFER+SIZE_OF_INT,"i32"),a=new Array(n);if(n>0){let o=r;for(let c=0;c<n;c++)a[c]=unmarshalRange(o),o+=SIZE_OF_RANGE;C._free(r)}return a}}class Node{constructor(t,n){assertInternal(t),this.tree=n}get typeId(){return marshalNode(this),C._ts_node_symbol_wasm(this.tree[0])}get type(){return this.tree.language.types[this.typeId]||"ERROR"}get endPosition(){return marshalNode(this),C._ts_node_end_point_wasm(this.tree[0]),unmarshalPoint(TRANSFER_BUFFER)}get endIndex(){return marshalNode(this),C._ts_node_end_index_wasm(this.tree[0])}get text(){return getText(this.tree,this.startIndex,this.endIndex)}isNamed(){return marshalNode(this),C._ts_node_is_named_wasm(this.tree[0])===1}hasError(){return marshalNode(this),C._ts_node_has_error_wasm(this.tree[0])===1}hasChanges(){return marshalNode(this),C._ts_node_has_changes_wasm(this.tree[0])===1}isMissing(){return marshalNode(this),C._ts_node_is_missing_wasm(this.tree[0])===1}equals(t){return this.id===t.id}child(t){return marshalNode(this),C._ts_node_child_wasm(this.tree[0],t),unmarshalNode(this.tree)}namedChild(t){return marshalNode(this),C._ts_node_named_child_wasm(this.tree[0],t),unmarshalNode(this.tree)}childForFieldId(t){return marshalNode(this),C._ts_node_child_by_field_id_wasm(this.tree[0],t),unmarshalNode(this.tree)}childForFieldName(t){let n=this.tree.language.fields.indexOf(t);if(n!==-1)return this.childForFieldId(n)}get childCount(){return marshalNode(this),C._ts_node_child_count_wasm(this.tree[0])}get namedChildCount(){return marshalNode(this),C._ts_node_named_child_count_wasm(this.tree[0])}get firstChild(){return this.child(0)}get firstNamedChild(){return this.namedChild(0)}get lastChild(){return this.child(this.childCount-1)}get lastNamedChild(){return this.namedChild(this.namedChildCount-1)}get children(){if(!this._children){marshalNode(this),C._ts_node_children_wasm(this.tree[0]);let t=getValue(TRANSFER_BUFFER,"i32"),n=getValue(TRANSFER_BUFFER+SIZE_OF_INT,"i32");if(this._children=new Array(t),t>0){let r=n;for(let a=0;a<t;a++)this._children[a]=unmarshalNode(this.tree,r),r+=SIZE_OF_NODE;C._free(n)}}return this._children}get namedChildren(){if(!this._namedChildren){marshalNode(this),C._ts_node_named_children_wasm(this.tree[0]);let t=getValue(TRANSFER_BUFFER,"i32"),n=getValue(TRANSFER_BUFFER+SIZE_OF_INT,"i32");if(this._namedChildren=new Array(t),t>0){let r=n;for(let a=0;a<t;a++)this._namedChildren[a]=unmarshalNode(this.tree,r),r+=SIZE_OF_NODE;C._free(n)}}return this._namedChildren}descendantsOfType(t,n,r){Array.isArray(t)||(t=[t]),n||(n=ZERO_POINT),r||(r=ZERO_POINT);let a=[],o=this.tree.language.types;for(let b=0,T=o.length;b<T;b++)t.includes(o[b])&&a.push(b);let c=C._malloc(SIZE_OF_INT*a.length);for(let b=0,T=a.length;b<T;b++)setValue(c+b*SIZE_OF_INT,a[b],"i32");marshalNode(this),C._ts_node_descendants_of_type_wasm(this.tree[0],c,a.length,n.row,n.column,r.row,r.column);let d=getValue(TRANSFER_BUFFER,"i32"),p=getValue(TRANSFER_BUFFER+SIZE_OF_INT,"i32"),w=new Array(d);if(d>0){let b=p;for(let T=0;T<d;T++)w[T]=unmarshalNode(this.tree,b),b+=SIZE_OF_NODE}return C._free(p),C._free(c),w}get nextSibling(){return marshalNode(this),C._ts_node_next_sibling_wasm(this.tree[0]),unmarshalNode(this.tree)}get previousSibling(){return marshalNode(this),C._ts_node_prev_sibling_wasm(this.tree[0]),unmarshalNode(this.tree)}get nextNamedSibling(){return marshalNode(this),C._ts_node_next_named_sibling_wasm(this.tree[0]),unmarshalNode(this.tree)}get previousNamedSibling(){return marshalNode(this),C._ts_node_prev_named_sibling_wasm(this.tree[0]),unmarshalNode(this.tree)}get parent(){return marshalNode(this),C._ts_node_parent_wasm(this.tree[0]),unmarshalNode(this.tree)}descendantForIndex(t,n=t){if(typeof t!="number"||typeof n!="number")throw new Error("Arguments must be numbers");marshalNode(this);let r=TRANSFER_BUFFER+SIZE_OF_NODE;return setValue(r,t,"i32"),setValue(r+SIZE_OF_INT,n,"i32"),C._ts_node_descendant_for_index_wasm(this.tree[0]),unmarshalNode(this.tree)}namedDescendantForIndex(t,n=t){if(typeof t!="number"||typeof n!="number")throw new Error("Arguments must be numbers");marshalNode(this);let r=TRANSFER_BUFFER+SIZE_OF_NODE;return setValue(r,t,"i32"),setValue(r+SIZE_OF_INT,n,"i32"),C._ts_node_named_descendant_for_index_wasm(this.tree[0]),unmarshalNode(this.tree)}descendantForPosition(t,n=t){if(!isPoint(t)||!isPoint(n))throw new Error("Arguments must be {row, column} objects");marshalNode(this);let r=TRANSFER_BUFFER+SIZE_OF_NODE;return marshalPoint(r,t),marshalPoint(r+SIZE_OF_POINT,n),C._ts_node_descendant_for_position_wasm(this.tree[0]),unmarshalNode(this.tree)}namedDescendantForPosition(t,n=t){if(!isPoint(t)||!isPoint(n))throw new Error("Arguments must be {row, column} objects");marshalNode(this);let r=TRANSFER_BUFFER+SIZE_OF_NODE;return marshalPoint(r,t),marshalPoint(r+SIZE_OF_POINT,n),C._ts_node_named_descendant_for_position_wasm(this.tree[0]),unmarshalNode(this.tree)}walk(){return marshalNode(this),C._ts_tree_cursor_new_wasm(this.tree[0]),new TreeCursor(INTERNAL,this.tree)}toString(){marshalNode(this);let t=C._ts_node_to_string_wasm(this.tree[0]),n=AsciiToString(t);return C._free(t),n}}class TreeCursor{constructor(t,n){assertInternal(t),this.tree=n,unmarshalTreeCursor(this)}delete(){marshalTreeCursor(this),C._ts_tree_cursor_delete_wasm(this.tree[0]),this[0]=this[1]=this[2]=0}reset(t){marshalNode(t),marshalTreeCursor(this,TRANSFER_BUFFER+SIZE_OF_NODE),C._ts_tree_cursor_reset_wasm(this.tree[0]),unmarshalTreeCursor(this)}get nodeType(){return this.tree.language.types[this.nodeTypeId]||"ERROR"}get nodeTypeId(){return marshalTreeCursor(this),C._ts_tree_cursor_current_node_type_id_wasm(this.tree[0])}get nodeId(){return marshalTreeCursor(this),C._ts_tree_cursor_current_node_id_wasm(this.tree[0])}get nodeIsNamed(){return marshalTreeCursor(this),C._ts_tree_cursor_current_node_is_named_wasm(this.tree[0])===1}get nodeIsMissing(){return marshalTreeCursor(this),C._ts_tree_cursor_current_node_is_missing_wasm(this.tree[0])===1}get nodeText(){marshalTreeCursor(this);let t=C._ts_tree_cursor_start_index_wasm(this.tree[0]),n=C._ts_tree_cursor_end_index_wasm(this.tree[0]);return getText(this.tree,t,n)}get startPosition(){return marshalTreeCursor(this),C._ts_tree_cursor_start_position_wasm(this.tree[0]),unmarshalPoint(TRANSFER_BUFFER)}get endPosition(){return marshalTreeCursor(this),C._ts_tree_cursor_end_position_wasm(this.tree[0]),unmarshalPoint(TRANSFER_BUFFER)}get startIndex(){return marshalTreeCursor(this),C._ts_tree_cursor_start_index_wasm(this.tree[0])}get endIndex(){return marshalTreeCursor(this),C._ts_tree_cursor_end_index_wasm(this.tree[0])}currentNode(){return marshalTreeCursor(this),C._ts_tree_cursor_current_node_wasm(this.tree[0]),unmarshalNode(this.tree)}currentFieldId(){return marshalTreeCursor(this),C._ts_tree_cursor_current_field_id_wasm(this.tree[0])}currentFieldName(){return this.tree.language.fields[this.currentFieldId()]}gotoFirstChild(){marshalTreeCursor(this);let t=C._ts_tree_cursor_goto_first_child_wasm(this.tree[0]);return unmarshalTreeCursor(this),t===1}gotoNextSibling(){marshalTreeCursor(this);let t=C._ts_tree_cursor_goto_next_sibling_wasm(this.tree[0]);return unmarshalTreeCursor(this),t===1}gotoParent(){marshalTreeCursor(this);let t=C._ts_tree_cursor_goto_parent_wasm(this.tree[0]);return unmarshalTreeCursor(this),t===1}}class Language{constructor(t,n){assertInternal(t),this[0]=n,this.types=new Array(C._ts_language_symbol_count(this[0]));for(let r=0,a=this.types.length;r<a;r++)C._ts_language_symbol_type(this[0],r)<2&&(this.types[r]=UTF8ToString(C._ts_language_symbol_name(this[0],r)));this.fields=new Array(C._ts_language_field_count(this[0])+1);for(let r=0,a=this.fields.length;r<a;r++){let o=C._ts_language_field_name_for_id(this[0],r);this.fields[r]=o!==0?UTF8ToString(o):null}}get version(){return C._ts_language_version(this[0])}get fieldCount(){return this.fields.length-1}fieldIdForName(t){let n=this.fields.indexOf(t);return n!==-1?n:null}fieldNameForId(t){return this.fields[t]||null}idForNodeType(t,n){let r=lengthBytesUTF8(t),a=C._malloc(r+1);stringToUTF8(t,a,r+1);let o=C._ts_language_symbol_for_name(this[0],a,r,n);return C._free(a),o||null}get nodeTypeCount(){return C._ts_language_symbol_count(this[0])}nodeTypeForId(t){let n=C._ts_language_symbol_name(this[0],t);return n?UTF8ToString(n):null}nodeTypeIsNamed(t){return!!C._ts_language_type_is_named_wasm(this[0],t)}nodeTypeIsVisible(t){return!!C._ts_language_type_is_visible_wasm(this[0],t)}query(t){let n=lengthBytesUTF8(t),r=C._malloc(n+1);stringToUTF8(t,r,n+1);let a=C._ts_query_new(this[0],r,n,TRANSFER_BUFFER,TRANSFER_BUFFER+SIZE_OF_INT);if(!a){let N=getValue(TRANSFER_BUFFER+SIZE_OF_INT,"i32"),k=UTF8ToString(r,getValue(TRANSFER_BUFFER,"i32")).length,A=t.substr(k,100).split(`
`)[0],M,L=A.match(QUERY_WORD_REGEX)[0];switch(N){case 2:M=new RangeError(`Bad node name '${L}'`);break;case 3:M=new RangeError(`Bad field name '${L}'`);break;case 4:M=new RangeError(`Bad capture name @${L}`);break;case 5:M=new TypeError(`Bad pattern structure at offset ${k}: '${A}'...`),L="";break;default:M=new SyntaxError(`Bad syntax at offset ${k}: '${A}'...`),L=""}throw M.index=k,M.length=L.length,C._free(r),M}let o=C._ts_query_string_count(a),c=C._ts_query_capture_count(a),d=C._ts_query_pattern_count(a),p=new Array(c),w=new Array(o);for(let N=0;N<c;N++){let k=C._ts_query_capture_name_for_id(a,N,TRANSFER_BUFFER),A=getValue(TRANSFER_BUFFER,"i32");p[N]=UTF8ToString(k,A)}for(let N=0;N<o;N++){let k=C._ts_query_string_value_for_id(a,N,TRANSFER_BUFFER),A=getValue(TRANSFER_BUFFER,"i32");w[N]=UTF8ToString(k,A)}let b=new Array(d),T=new Array(d),x=new Array(d),z=new Array(d),B=new Array(d);for(let N=0;N<d;N++){let k=C._ts_query_predicates_for_pattern(a,N,TRANSFER_BUFFER),A=getValue(TRANSFER_BUFFER,"i32");z[N]=[],B[N]=[];let M=[],L=k;for(let O=0;O<A;O++){let se=getValue(L,"i32");L+=SIZE_OF_INT;let X=getValue(L,"i32");if(L+=SIZE_OF_INT,se===PREDICATE_STEP_TYPE_CAPTURE)M.push({type:"capture",name:p[X]});else if(se===PREDICATE_STEP_TYPE_STRING)M.push({type:"string",value:w[X]});else if(M.length>0){if(M[0].type!=="string")throw new Error("Predicates must begin with a literal value");let K=M[0].value,le=!0;switch(K){case"not-eq?":le=!1;case"eq?":if(M.length!==3)throw new Error("Wrong number of arguments to `#eq?` predicate. Expected 2, got "+(M.length-1));if(M[1].type!=="capture")throw new Error(`First argument of \`#eq?\` predicate must be a capture. Got "${M[1].value}"`);if(M[2].type==="capture"){let u=M[1].name,f=M[2].name;B[N].push((function(m){let y,I;for(let P of m)P.name===u&&(y=P.node),P.name===f&&(I=P.node);return y===void 0||I===void 0||y.text===I.text===le}))}else{let u=M[1].name,f=M[2].value;B[N].push((function(m){for(let y of m)if(y.name===u)return y.node.text===f===le;return!0}))}break;case"not-match?":le=!1;case"match?":if(M.length!==3)throw new Error(`Wrong number of arguments to \`#match?\` predicate. Expected 2, got ${M.length-1}.`);if(M[1].type!=="capture")throw new Error(`First argument of \`#match?\` predicate must be a capture. Got "${M[1].value}".`);if(M[2].type!=="string")throw new Error(`Second argument of \`#match?\` predicate must be a string. Got @${M[2].value}.`);let fe=M[1].name,R=new RegExp(M[2].value);B[N].push((function(u){for(let f of u)if(f.name===fe)return R.test(f.node.text)===le;return!0}));break;case"set!":if(M.length<2||M.length>3)throw new Error(`Wrong number of arguments to \`#set!\` predicate. Expected 1 or 2. Got ${M.length-1}.`);if(M.some((u=>u.type!=="string")))throw new Error('Arguments to `#set!` predicate must be a strings.".');b[N]||(b[N]={}),b[N][M[1].value]=M[2]?M[2].value:null;break;case"is?":case"is-not?":if(M.length<2||M.length>3)throw new Error(`Wrong number of arguments to \`#${K}\` predicate. Expected 1 or 2. Got ${M.length-1}.`);if(M.some((u=>u.type!=="string")))throw new Error(`Arguments to \`#${K}\` predicate must be a strings.".`);let h=K==="is?"?T:x;h[N]||(h[N]={}),h[N][M[1].value]=M[2]?M[2].value:null;break;default:z[N].push({operator:K,operands:M.slice(1)})}M.length=0}}Object.freeze(b[N]),Object.freeze(T[N]),Object.freeze(x[N])}return C._free(r),new Query(INTERNAL,a,p,B,z,Object.freeze(b),Object.freeze(T),Object.freeze(x))}static load(t){let n;if(t instanceof Uint8Array)n=Promise.resolve(t);else{let a=t;if(typeof process<"u"&&process.versions&&process.versions.node){let o=jt("fs");n=Promise.resolve(o.readFileSync(a))}else n=fetch(a).then((o=>o.arrayBuffer().then((c=>{if(o.ok)return new Uint8Array(c);{let d=new TextDecoder("utf-8").decode(c);throw new Error(`Language.load failed with status ${o.status}.

${d}`)}}))))}let r=typeof loadSideModule=="function"?loadSideModule:loadWebAssemblyModule;return n.then((a=>r(a,{loadAsync:!0}))).then((a=>{let o=Object.keys(a),c=o.find((p=>LANGUAGE_FUNCTION_REGEX.test(p)&&!p.includes("external_scanner_")));c||console.log(`Couldn't find language function in WASM file. Symbols:
${JSON.stringify(o,null,2)}`);let d=a[c]();return new Language(INTERNAL,d)}))}}class Query{constructor(t,n,r,a,o,c,d,p){assertInternal(t),this[0]=n,this.captureNames=r,this.textPredicates=a,this.predicates=o,this.setProperties=c,this.assertedProperties=d,this.refutedProperties=p,this.exceededMatchLimit=!1}delete(){C._ts_query_delete(this[0]),this[0]=0}matches(t,n,r,a){n||(n=ZERO_POINT),r||(r=ZERO_POINT),a||(a={});let o=a.matchLimit;if(o===void 0)o=0;else if(typeof o!="number")throw new Error("Arguments must be numbers");marshalNode(t),C._ts_query_matches_wasm(this[0],t.tree[0],n.row,n.column,r.row,r.column,o);let c=getValue(TRANSFER_BUFFER,"i32"),d=getValue(TRANSFER_BUFFER+SIZE_OF_INT,"i32"),p=getValue(TRANSFER_BUFFER+2*SIZE_OF_INT,"i32"),w=new Array(c);this.exceededMatchLimit=!!p;let b=0,T=d;for(let x=0;x<c;x++){let z=getValue(T,"i32");T+=SIZE_OF_INT;let B=getValue(T,"i32");T+=SIZE_OF_INT;let N=new Array(B);if(T=unmarshalCaptures(this,t.tree,T,N),this.textPredicates[z].every((k=>k(N)))){w[b++]={pattern:z,captures:N};let k=this.setProperties[z];k&&(w[x].setProperties=k);let A=this.assertedProperties[z];A&&(w[x].assertedProperties=A);let M=this.refutedProperties[z];M&&(w[x].refutedProperties=M)}}return w.length=b,C._free(d),w}captures(t,n,r,a){n||(n=ZERO_POINT),r||(r=ZERO_POINT),a||(a={});let o=a.matchLimit;if(o===void 0)o=0;else if(typeof o!="number")throw new Error("Arguments must be numbers");marshalNode(t),C._ts_query_captures_wasm(this[0],t.tree[0],n.row,n.column,r.row,r.column,o);let c=getValue(TRANSFER_BUFFER,"i32"),d=getValue(TRANSFER_BUFFER+SIZE_OF_INT,"i32"),p=getValue(TRANSFER_BUFFER+2*SIZE_OF_INT,"i32"),w=[];this.exceededMatchLimit=!!p;let b=[],T=d;for(let x=0;x<c;x++){let z=getValue(T,"i32");T+=SIZE_OF_INT;let B=getValue(T,"i32");T+=SIZE_OF_INT;let N=getValue(T,"i32");if(T+=SIZE_OF_INT,b.length=B,T=unmarshalCaptures(this,t.tree,T,b),this.textPredicates[z].every((k=>k(b)))){let k=b[N],A=this.setProperties[z];A&&(k.setProperties=A);let M=this.assertedProperties[z];M&&(k.assertedProperties=M);let L=this.refutedProperties[z];L&&(k.refutedProperties=L),w.push(k)}}return C._free(d),w}predicatesForPattern(t){return this.predicates[t]}didExceedMatchLimit(){return this.exceededMatchLimit}}function getText(e,t,n){let r=n-t,a=e.textCallback(t,null,n);for(t+=a.length;t<n;){let o=e.textCallback(t,null,n);if(!(o&&o.length>0))break;t+=o.length,a+=o}return t>n&&(a=a.slice(0,r)),a}function unmarshalCaptures(e,t,n,r){for(let a=0,o=r.length;a<o;a++){let c=getValue(n,"i32"),d=unmarshalNode(t,n+=SIZE_OF_INT);n+=SIZE_OF_NODE,r[a]={name:e.captureNames[c],node:d}}return n}function assertInternal(e){if(e!==INTERNAL)throw new Error("Illegal constructor")}function isPoint(e){return e&&typeof e.row=="number"&&typeof e.column=="number"}function marshalNode(e){let t=TRANSFER_BUFFER;setValue(t,e.id,"i32"),t+=SIZE_OF_INT,setValue(t,e.startIndex,"i32"),t+=SIZE_OF_INT,setValue(t,e.startPosition.row,"i32"),t+=SIZE_OF_INT,setValue(t,e.startPosition.column,"i32"),t+=SIZE_OF_INT,setValue(t,e[0],"i32")}function unmarshalNode(e,t=TRANSFER_BUFFER){let n=getValue(t,"i32");if(n===0)return null;let r=getValue(t+=SIZE_OF_INT,"i32"),a=getValue(t+=SIZE_OF_INT,"i32"),o=getValue(t+=SIZE_OF_INT,"i32"),c=getValue(t+=SIZE_OF_INT,"i32"),d=new Node(INTERNAL,e);return d.id=n,d.startIndex=r,d.startPosition={row:a,column:o},d[0]=c,d}function marshalTreeCursor(e,t=TRANSFER_BUFFER){setValue(t+0*SIZE_OF_INT,e[0],"i32"),setValue(t+1*SIZE_OF_INT,e[1],"i32"),setValue(t+2*SIZE_OF_INT,e[2],"i32")}function unmarshalTreeCursor(e){e[0]=getValue(TRANSFER_BUFFER+0*SIZE_OF_INT,"i32"),e[1]=getValue(TRANSFER_BUFFER+1*SIZE_OF_INT,"i32"),e[2]=getValue(TRANSFER_BUFFER+2*SIZE_OF_INT,"i32")}function marshalPoint(e,t){setValue(e,t.row,"i32"),setValue(e+SIZE_OF_INT,t.column,"i32")}function unmarshalPoint(e){return{row:getValue(e,"i32"),column:getValue(e+SIZE_OF_INT,"i32")}}function marshalRange(e,t){marshalPoint(e,t.startPosition),marshalPoint(e+=SIZE_OF_POINT,t.endPosition),setValue(e+=SIZE_OF_POINT,t.startIndex,"i32"),setValue(e+=SIZE_OF_INT,t.endIndex,"i32"),e+=SIZE_OF_INT}function unmarshalRange(e){let t={};return t.startPosition=unmarshalPoint(e),e+=SIZE_OF_POINT,t.endPosition=unmarshalPoint(e),e+=SIZE_OF_POINT,t.startIndex=getValue(e,"i32"),e+=SIZE_OF_INT,t.endIndex=getValue(e,"i32"),t}function marshalEdit(e){let t=TRANSFER_BUFFER;marshalPoint(t,e.startPosition),t+=SIZE_OF_POINT,marshalPoint(t,e.oldEndPosition),t+=SIZE_OF_POINT,marshalPoint(t,e.newEndPosition),t+=SIZE_OF_POINT,setValue(t,e.startIndex,"i32"),t+=SIZE_OF_INT,setValue(t,e.oldEndIndex,"i32"),t+=SIZE_OF_INT,setValue(t,e.newEndIndex,"i32"),t+=SIZE_OF_INT}for(let e of Object.getOwnPropertyNames(ParserImpl.prototype))Object.defineProperty(Parser.prototype,e,{value:ParserImpl.prototype[e],enumerable:!1,writable:!1});Parser.Language=Language,Module.onRuntimeInitialized=()=>{ParserImpl.init(),resolveInitPromise()}})))}}return Parser})();typeof exports=="object"&&(module.exports=TreeSitter)});var Ke={id:"rastrolab.acode-c",name:"C Language Toolkit",main:"main.js",version:"1.0.0",readme:"readme.md",icon:"icon.png",files:["assets/tree-sitter.wasm","assets/tree-sitter-c.wasm","assets/clang-format.wasm"],minVersionCode:290,license:"MIT",keywords:["c","lint","linter","clang-format","formatter","snippets","completion","tree-sitter"],author:{name:"rastrolab",github:"rastrolab"},repository:"https://github.com/rastrolab/acode-c"};function Zt(e,t,n,r,a,o){this.indented=e,this.column=t,this.type=n,this.info=r,this.align=a,this.prev=o}function yt(e,t,n,r){var a=e.indented;return e.context&&e.context.type=="statement"&&n!="statement"&&(a=e.context.indented),e.context=new Zt(a,t,n,r,null,e.context)}function Ye(e){var t=e.context.type;return(t==")"||t=="]"||t=="}")&&(e.indented=e.context.indented),e.context=e.context.prev}function Bn(e,t,n){if(t.prevToken=="variable"||t.prevToken=="type"||/\S(?:[^- ]>|[*\]])\s*$|\*$/.test(e.string.slice(0,n))||t.typeAtEndOfLine&&e.column()==e.indentation())return!0}function Vt(e){for(;;){if(!e||e.type=="top")return!0;if(e.type=="}"&&e.prev.info!="namespace")return!1;e=e.prev}}function de(e){var t=e.statementIndentUnit,n=e.dontAlignCalls,r=e.keywords||{},a=e.types||{},o=e.builtin||{},c=e.blockKeywords||{},d=e.defKeywords||{},p=e.atoms||{},w=e.hooks||{},b=e.multiLineStrings,T=e.indentStatements!==!1,x=e.indentSwitch!==!1,z=e.namespaceSeparator,B=e.isPunctuationChar||/[\[\]{}\(\),;\:\.]/,N=e.numberStart||/[\d\.]/,k=e.number||/^(?:0x[a-f\d]+|0b[01]+|(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?)(u|ll?|l|f)?/i,A=e.isOperatorChar||/[+\-*&%=<>!?|\/]/,M=e.isIdentifierChar||/[\w\$_\xa1-\uffff]/,L=e.isReservedIdentifier||!1,O,se;function X(R,h){var u=R.next();if(w[u]){var f=w[u](R,h);if(f!==!1)return f}if(u=='"'||u=="'")return h.tokenize=K(u),h.tokenize(R,h);if(N.test(u)){if(R.backUp(1),R.match(k))return"number";R.next()}if(B.test(u))return O=u,null;if(u=="/"){if(R.eat("*"))return h.tokenize=le,le(R,h);if(R.eat("/"))return R.skipToEnd(),"comment"}if(A.test(u)){for(;!R.match(/^\/[\/*]/,!1)&&R.eat(A););return"operator"}if(R.eatWhile(M),z)for(;R.match(z);)R.eatWhile(M);var m=R.current();return we(r,m)?(we(c,m)&&(O="newstatement"),we(d,m)&&(se=!0),"keyword"):we(a,m)?"type":we(o,m)||L&&L(m)?(we(c,m)&&(O="newstatement"),"builtin"):we(p,m)?"atom":"variable"}function K(R){return function(h,u){for(var f=!1,m,y=!1;(m=h.next())!=null;){if(m==R&&!f){y=!0;break}f=!f&&m=="\\"}return(y||!(f||b))&&(u.tokenize=null),"string"}}function le(R,h){for(var u=!1,f;f=R.next();){if(f=="/"&&u){h.tokenize=null;break}u=f=="*"}return"comment"}function fe(R,h){e.typeFirstDefinitions&&R.eol()&&Vt(h.context)&&(h.typeAtEndOfLine=Bn(R,h,R.pos))}return{name:e.name,startState:function(R){return{tokenize:null,context:new Zt(-R,0,"top",null,!1),indented:0,startOfLine:!0,prevToken:null}},token:function(R,h){var u=h.context;if(R.sol()&&(u.align==null&&(u.align=!1),h.indented=R.indentation(),h.startOfLine=!0),R.eatSpace())return fe(R,h),null;O=se=null;var f=(h.tokenize||X)(R,h);if(f=="comment"||f=="meta")return f;if(u.align==null&&(u.align=!0),O==";"||O==":"||O==","&&R.match(/^\s*(?:\/\/.*)?$/,!1))for(;h.context.type=="statement";)Ye(h);else if(O=="{")yt(h,R.column(),"}");else if(O=="[")yt(h,R.column(),"]");else if(O=="(")yt(h,R.column(),")");else if(O=="}"){for(;u.type=="statement";)u=Ye(h);for(u.type=="}"&&(u=Ye(h));u.type=="statement";)u=Ye(h)}else O==u.type?Ye(h):T&&((u.type=="}"||u.type=="top")&&O!=";"||u.type=="statement"&&O=="newstatement")&&yt(h,R.column(),"statement",R.current());if(f=="variable"&&(h.prevToken=="def"||e.typeFirstDefinitions&&Bn(R,h,R.start)&&Vt(h.context)&&R.match(/^\s*\(/,!1))&&(f="def"),w.token){var m=w.token(R,h,f);m!==void 0&&(f=m)}return f=="def"&&e.styleDefs===!1&&(f="variable"),h.startOfLine=!1,h.prevToken=se?"def":f||O,fe(R,h),f},indent:function(R,h,u){if(R.tokenize!=X&&R.tokenize!=null||R.typeAtEndOfLine&&Vt(R.context))return null;var f=R.context,m=h&&h.charAt(0),y=m==f.type;if(f.type=="statement"&&m=="}"&&(f=f.prev),e.dontIndentStatements)for(;f.type=="statement"&&e.dontIndentStatements.test(f.info);)f=f.prev;if(w.indent){var I=w.indent(R,f,h,u.unit);if(typeof I=="number")return I}var P=f.prev&&f.prev.info=="switch";if(e.allmanIndentation&&/[{(]/.test(m)){for(;f.type!="top"&&f.type!="}";)f=f.prev;return f.indented}return f.type=="statement"?f.indented+(m=="{"?0:t||u.unit):f.align&&(!n||f.type!=")")?f.column+(y?0:1):f.type==")"&&!y?f.indented+(t||u.unit):f.indented+(y?0:u.unit)+(!y&&P&&!/^(?:case|default)\b/.test(h)?u.unit:0)},languageData:{indentOnInput:x?/^\s*(?:case .*?:|default:|\{\}?|\})$/:/^\s*[{}]$/,commentTokens:{line:"//",block:{open:"/*",close:"*/"}},autocomplete:Object.keys(r).concat(Object.keys(a)).concat(Object.keys(o)).concat(Object.keys(p)),...e.languageData}}}function $(e){for(var t={},n=e.split(" "),r=0;r<n.length;++r)t[n[r]]=!0;return t}function we(e,t){return typeof e=="function"?e(t):e.propertyIsEnumerable(t)}var Je="auto if break case register continue return default do sizeof static else struct switch extern typedef union for goto while enum const volatile inline restrict asm fortran",jn="alignas alignof and and_eq audit axiom bitand bitor catch class compl concept constexpr const_cast decltype delete dynamic_cast explicit export final friend import module mutable namespace new noexcept not not_eq operator or or_eq override private protected public reinterpret_cast requires static_assert static_cast template this thread_local throw try typeid typename using virtual xor xor_eq",Vn="bycopy byref in inout oneway out self super atomic nonatomic retain copy readwrite readonly strong weak assign typeof nullable nonnull null_resettable _cmd @interface @implementation @end @protocol @encode @property @synthesize @dynamic @class @public @package @private @protected @required @optional @try @catch @finally @import @selector @encode @defs @synchronized @autoreleasepool @compatibility_alias @available",qn="FOUNDATION_EXPORT FOUNDATION_EXTERN NS_INLINE NS_FORMAT_FUNCTION  NS_RETURNS_RETAINEDNS_ERROR_ENUM NS_RETURNS_NOT_RETAINED NS_RETURNS_INNER_POINTER NS_DESIGNATED_INITIALIZER NS_ENUM NS_OPTIONS NS_REQUIRES_NIL_TERMINATION NS_ASSUME_NONNULL_BEGIN NS_ASSUME_NONNULL_END NS_SWIFT_NAME NS_REFINED_FOR_SWIFT",Qs=$("int long char short double float unsigned signed void bool"),Js=$("SEL instancetype id Class Protocol BOOL");function et(e){return we(Qs,e)||/.+_t$/.test(e)}function Zn(e){return et(e)||we(Js,e)}var tt="case do else for if switch while struct enum union",wt="struct enum union";function xe(e,t){if(!t.startOfLine)return!1;for(var n,r=null;n=e.peek();){if(n=="\\"&&e.match(/^.$/)){r=xe;break}else if(n=="/"&&e.match(/^\/[\/\*]/,!1))break;e.next()}return t.tokenize=r,"meta"}function vt(e,t){return t.prevToken=="type"?"type":!1}function Et(e){return!e||e.length<2||e[0]!="_"?!1:e[1]=="_"||e[1]!==e[1].toLowerCase()}function ne(e){return e.eatWhile(/[\w\.']/),"number"}function Me(e,t){if(e.backUp(1),e.match(/^(?:R|u8R|uR|UR|LR)/)){var n=e.match(/^"([^\s\\()]{0,16})\(/);return n?(t.cpp11RawStringDelim=n[1],t.tokenize=Hn,Hn(e,t)):!1}return e.match(/^(?:u8|u|U|L)/)?e.match(/^["']/,!1)?"string":!1:(e.next(),!1)}function Gn(e){var t=/(\w+)::~?(\w+)$/.exec(e);return t&&t[1]==t[2]}function Wn(e,t){for(var n;(n=e.next())!=null;)if(n=='"'&&!e.eat('"')){t.tokenize=null;break}return"string"}function Hn(e,t){var n=t.cpp11RawStringDelim.replace(/[^\w\s]/g,"\\$&"),r=e.match(new RegExp(".*?\\)"+n+'"'));return r?t.tokenize=null:e.skipToEnd(),"string"}var Gt=de({name:"c",keywords:$(Je),types:et,blockKeywords:$(tt),defKeywords:$(wt),typeFirstDefinitions:!0,atoms:$("NULL true false"),isReservedIdentifier:Et,hooks:{"#":xe,"*":vt}}),Ra=de({name:"cpp",keywords:$(Je+" "+jn),types:et,blockKeywords:$(tt+" class try catch"),defKeywords:$(wt+" class namespace"),typeFirstDefinitions:!0,atoms:$("true false NULL nullptr"),dontIndentStatements:/^template$/,isIdentifierChar:/[\w\$_~\xa1-\uffff]/,isReservedIdentifier:Et,hooks:{"#":xe,"*":vt,u:Me,U:Me,L:Me,R:Me,0:ne,1:ne,2:ne,3:ne,4:ne,5:ne,6:ne,7:ne,8:ne,9:ne,token:function(e,t,n){if(n=="variable"&&e.peek()=="("&&(t.prevToken==";"||t.prevToken==null||t.prevToken=="}")&&Gn(e.current()))return"def"}},namespaceSeparator:"::"}),$a=de({name:"java",keywords:$("abstract assert break case catch class const continue default do else enum extends final finally for goto if implements import instanceof interface native new package private protected public return static strictfp super switch synchronized this throw throws transient try volatile while @interface"),types:$("var byte short int long float double boolean char void Boolean Byte Character Double Float Integer Long Number Object Short String StringBuffer StringBuilder Void"),blockKeywords:$("catch class do else finally for if switch try while"),defKeywords:$("class interface enum @interface"),typeFirstDefinitions:!0,atoms:$("true false null"),number:/^(?:0x[a-f\d_]+|0b[01_]+|(?:[\d_]+\.?\d*|\.\d+)(?:e[-+]?[\d_]+)?)(u|ll?|l|f)?/i,hooks:{"@":function(e){return e.match("interface",!1)?!1:(e.eatWhile(/[\w\$_]/),"meta")},'"':function(e,t){return e.match(/""$/)?(t.tokenize=Xn,t.tokenize(e,t)):!1}}}),Pa=de({name:"csharp",keywords:$("abstract as async await base break case catch checked class const continue default delegate do else enum event explicit extern finally fixed for foreach goto if implicit in init interface internal is lock namespace new operator out override params private protected public readonly record ref required return sealed sizeof stackalloc static struct switch this throw try typeof unchecked unsafe using virtual void volatile while add alias ascending descending dynamic from get global group into join let orderby partial remove select set value var yield"),types:$("Action Boolean Byte Char DateTime DateTimeOffset Decimal Double Func Guid Int16 Int32 Int64 Object SByte Single String Task TimeSpan UInt16 UInt32 UInt64 bool byte char decimal double short int long object sbyte float string ushort uint ulong"),blockKeywords:$("catch class do else finally for foreach if struct switch try while"),defKeywords:$("class interface namespace record struct var"),typeFirstDefinitions:!0,atoms:$("true false null"),hooks:{"@":function(e,t){return e.eat('"')?(t.tokenize=Wn,Wn(e,t)):(e.eatWhile(/[\w\$_]/),"meta")}}});function Xn(e,t){for(var n=!1;!e.eol();){if(!n&&e.match('"""')){t.tokenize=null;break}n=e.next()=="\\"&&!n}return"string"}function Qe(e){return function(t,n){for(var r;r=t.next();)if(r=="*"&&t.eat("/"))if(e==1){n.tokenize=null;break}else return n.tokenize=Qe(e-1),n.tokenize(t,n);else if(r=="/"&&t.eat("*"))return n.tokenize=Qe(e+1),n.tokenize(t,n);return"comment"}}var La=de({name:"scala",keywords:$("abstract case catch class def do else extends final finally for forSome if implicit import lazy match new null object override package private protected return sealed super this throw trait try type val var while with yield _ assert assume require print println printf readLine readBoolean readByte readShort readChar readInt readLong readFloat readDouble"),types:$("AnyVal App Application Array BufferedIterator BigDecimal BigInt Char Console Either Enumeration Equiv Error Exception Fractional Function IndexedSeq Int Integral Iterable Iterator List Map Numeric Nil NotNull Option Ordered Ordering PartialFunction PartialOrdering Product Proxy Range Responder Seq Serializable Set Specializable Stream StringBuilder StringContext Symbol Throwable Traversable TraversableOnce Tuple Unit Vector Boolean Byte Character CharSequence Class ClassLoader Cloneable Comparable Compiler Double Exception Float Integer Long Math Number Object Package Pair Process Runtime Runnable SecurityManager Short StackTraceElement StrictMath String StringBuffer System Thread ThreadGroup ThreadLocal Throwable Triple Void"),multiLineStrings:!0,blockKeywords:$("catch class enum do else finally for forSome if match switch try while"),defKeywords:$("class enum def object package trait type val var"),atoms:$("true false null"),indentStatements:!1,indentSwitch:!1,isOperatorChar:/[+\-*&%=<>!?|\/#:@]/,hooks:{"@":function(e){return e.eatWhile(/[\w\$_]/),"meta"},'"':function(e,t){return e.match('""')?(t.tokenize=Xn,t.tokenize(e,t)):!1},"'":function(e){return e.match(/^(\\[^'\s]+|[^\\'])'/)?"character":(e.eatWhile(/[\w\$_\xa1-\uffff]/),"atom")},"=":function(e,t){var n=t.context;return n.type=="}"&&n.align&&e.eat(">")?(t.context=new Zt(n.indented,n.column,n.type,n.info,null,n.prev),"operator"):!1},"/":function(e,t){return e.eat("*")?(t.tokenize=Qe(1),t.tokenize(e,t)):!1}},languageData:{closeBrackets:{brackets:["(","[","{","'",'"','"""']}}});function ea(e){return function(t,n){for(var r=!1,a,o=!1;!t.eol();){if(!e&&!r&&t.match('"')){o=!0;break}if(e&&t.match('"""')){o=!0;break}a=t.next(),!r&&a=="$"&&t.match("{")&&t.skipTo("}"),r=!r&&a=="\\"&&!e}return(o||!e)&&(n.tokenize=null),"string"}}var Oa=de({name:"kotlin",keywords:$("package as typealias class interface this super val operator var fun for is in This throw return annotation break continue object if else while do try when !in !is as? file import where by get set abstract enum open inner override private public internal protected catch finally out final vararg reified dynamic companion constructor init sealed field property receiver param sparam lateinit data inline noinline tailrec external annotation crossinline const operator infix suspend actual expect setparam"),types:$("Boolean Byte Character CharSequence Class ClassLoader Cloneable Comparable Compiler Double Exception Float Integer Long Math Number Object Package Pair Process Runtime Runnable SecurityManager Short StackTraceElement StrictMath String StringBuffer System Thread ThreadGroup ThreadLocal Throwable Triple Void Annotation Any BooleanArray ByteArray Char CharArray DeprecationLevel DoubleArray Enum FloatArray Function Int IntArray Lazy LazyThreadSafetyMode LongArray Nothing ShortArray Unit"),intendSwitch:!1,indentStatements:!1,multiLineStrings:!0,number:/^(?:0x[a-f\d_]+|0b[01_]+|(?:[\d_]+(\.\d+)?|\.\d+)(?:e[-+]?[\d_]+)?)(ul?|l|f)?/i,blockKeywords:$("catch class do else finally for if where try while enum"),defKeywords:$("class val var object interface fun"),atoms:$("true false null this"),hooks:{"@":function(e){return e.eatWhile(/[\w\$_]/),"meta"},"*":function(e,t){return t.prevToken=="."?"variable":"operator"},'"':function(e,t){return t.tokenize=ea(e.match('""')),t.tokenize(e,t)},"/":function(e,t){return e.eat("*")?(t.tokenize=Qe(1),t.tokenize(e,t)):!1},indent:function(e,t,n,r){var a=n&&n.charAt(0);if((e.prevToken=="}"||e.prevToken==")")&&n=="")return e.indented;if(e.prevToken=="operator"&&n!="}"&&e.context.type!="}"||e.prevToken=="variable"&&a=="."||(e.prevToken=="}"||e.prevToken==")")&&a==".")return r*2+t.indented;if(t.align&&t.type=="}")return t.indented+(e.context.type==(n||"").charAt(0)?0:r)}},languageData:{closeBrackets:{brackets:["(","[","{","'",'"','"""']}}}),Da=de({name:"shader",keywords:$("sampler1D sampler2D sampler3D samplerCube sampler1DShadow sampler2DShadow const attribute uniform varying break continue discard return for while do if else struct in out inout"),types:$("float int bool void vec2 vec3 vec4 ivec2 ivec3 ivec4 bvec2 bvec3 bvec4 mat2 mat3 mat4"),blockKeywords:$("for while do if else struct"),builtin:$("radians degrees sin cos tan asin acos atan pow exp log exp2 sqrt inversesqrt abs sign floor ceil fract mod min max clamp mix step smoothstep length distance dot cross normalize ftransform faceforward reflect refract matrixCompMult lessThan lessThanEqual greaterThan greaterThanEqual equal notEqual any all not texture1D texture1DProj texture1DLod texture1DProjLod texture2D texture2DProj texture2DLod texture2DProjLod texture3D texture3DProj texture3DLod texture3DProjLod textureCube textureCubeLod shadow1D shadow2D shadow1DProj shadow2DProj shadow1DLod shadow2DLod shadow1DProjLod shadow2DProjLod dFdx dFdy fwidth noise1 noise2 noise3 noise4"),atoms:$("true false gl_FragColor gl_SecondaryColor gl_Normal gl_Vertex gl_MultiTexCoord0 gl_MultiTexCoord1 gl_MultiTexCoord2 gl_MultiTexCoord3 gl_MultiTexCoord4 gl_MultiTexCoord5 gl_MultiTexCoord6 gl_MultiTexCoord7 gl_FogCoord gl_PointCoord gl_Position gl_PointSize gl_ClipVertex gl_FrontColor gl_BackColor gl_FrontSecondaryColor gl_BackSecondaryColor gl_TexCoord gl_FogFragCoord gl_FragCoord gl_FrontFacing gl_FragData gl_FragDepth gl_ModelViewMatrix gl_ProjectionMatrix gl_ModelViewProjectionMatrix gl_TextureMatrix gl_NormalMatrix gl_ModelViewMatrixInverse gl_ProjectionMatrixInverse gl_ModelViewProjectionMatrixInverse gl_TextureMatrixTranspose gl_ModelViewMatrixInverseTranspose gl_ProjectionMatrixInverseTranspose gl_ModelViewProjectionMatrixInverseTranspose gl_TextureMatrixInverseTranspose gl_NormalScale gl_DepthRange gl_ClipPlane gl_Point gl_FrontMaterial gl_BackMaterial gl_LightSource gl_LightModel gl_FrontLightModelProduct gl_BackLightModelProduct gl_TextureColor gl_EyePlaneS gl_EyePlaneT gl_EyePlaneR gl_EyePlaneQ gl_FogParameters gl_MaxLights gl_MaxClipPlanes gl_MaxTextureUnits gl_MaxTextureCoords gl_MaxVertexAttribs gl_MaxVertexUniformComponents gl_MaxVaryingFloats gl_MaxVertexTextureImageUnits gl_MaxTextureImageUnits gl_MaxFragmentUniformComponents gl_MaxCombineTextureImageUnits gl_MaxDrawBuffers"),indentSwitch:!1,hooks:{"#":xe}}),Ua=de({name:"nesc",keywords:$(Je+" as atomic async call command component components configuration event generic implementation includes interface module new norace nx_struct nx_union post provides signal task uses abstract extends"),types:et,blockKeywords:$(tt),atoms:$("null true false"),hooks:{"#":xe}}),za=de({name:"objectivec",keywords:$(Je+" "+Vn),types:Zn,builtin:$(qn),blockKeywords:$(tt+" @synthesize @try @catch @finally @autoreleasepool @synchronized"),defKeywords:$(wt+" @interface @implementation @protocol @class"),dontIndentStatements:/^@.*$/,typeFirstDefinitions:!0,atoms:$("YES NO NULL Nil nil true false nullptr"),isReservedIdentifier:Et,hooks:{"#":xe,"*":vt}}),Ba=de({name:"objectivecpp",keywords:$(Je+" "+Vn+" "+jn),types:Zn,builtin:$(qn),blockKeywords:$(tt+" @synthesize @try @catch @finally @autoreleasepool @synchronized class try catch"),defKeywords:$(wt+" @interface @implementation @protocol @class class namespace"),dontIndentStatements:/^@.*$|^template$/,typeFirstDefinitions:!0,atoms:$("YES NO NULL Nil nil true false nullptr"),isReservedIdentifier:Et,hooks:{"#":xe,"*":vt,u:Me,U:Me,L:Me,R:Me,0:ne,1:ne,2:ne,3:ne,4:ne,5:ne,6:ne,7:ne,8:ne,9:ne,token:function(e,t,n){if(n=="variable"&&e.peek()=="("&&(t.prevToken==";"||t.prevToken==null||t.prevToken=="}")&&Gn(e.current()))return"def"}},namespaceSeparator:"::"}),Wa=de({name:"squirrel",keywords:$("base break clone continue const default delete enum extends function in class foreach local resume return this throw typeof yield constructor instanceof static"),types:et,blockKeywords:$("case catch class else for foreach if switch try while"),defKeywords:$("function local class"),typeFirstDefinitions:!0,atoms:$("true false null"),hooks:{"#":xe}}),bt=null;function Kn(e){return function(t,n){for(var r=!1,a,o=!1;!t.eol();){if(!r&&t.match('"')&&(e=="single"||t.match('""'))){o=!0;break}if(!r&&t.match("``")){bt=Kn(e),o=!0;break}a=t.next(),r=e=="single"&&!r&&a=="\\"}return o&&(n.tokenize=null),"string"}}var Ha=de({name:"ceylon",keywords:$("abstracts alias assembly assert assign break case catch class continue dynamic else exists extends finally for function given if import in interface is let module new nonempty object of out outer package return satisfies super switch then this throw try value void while"),types:function(e){var t=e.charAt(0);return t===t.toUpperCase()&&t!==t.toLowerCase()},blockKeywords:$("case catch class dynamic else finally for function if interface module new object switch try while"),defKeywords:$("class dynamic function interface module object package value"),builtin:$("abstract actual aliased annotation by default deprecated doc final formal late license native optional sealed see serializable shared suppressWarnings tagged throws variable"),isPunctuationChar:/[\[\]{}\(\),;\:\.`]/,isOperatorChar:/[+\-*&%=<>!?|^~:\/]/,numberStart:/[\d#$]/,number:/^(?:#[\da-fA-F_]+|\$[01_]+|[\d_]+[kMGTPmunpf]?|[\d_]+\.[\d_]+(?:[eE][-+]?\d+|[kMGTPmunpf]|)|)/i,multiLineStrings:!0,typeFirstDefinitions:!0,atoms:$("true false null larger smaller equal empty finished"),indentSwitch:!1,styleDefs:!1,hooks:{"@":function(e){return e.eatWhile(/[\w\$_]/),"meta"},'"':function(e,t){return t.tokenize=Kn(e.match('""')?"triple":"single"),t.tokenize(e,t)},"`":function(e,t){return!bt||!e.match("`")?!1:(t.tokenize=bt,bt=null,t.tokenize(e,t))},"'":function(e){return e.match(/^(\\[^'\s]+|[^\\'])'/)?"string.special":(e.eatWhile(/[\w\$_\xa1-\uffff]/),"atom")},token:function(e,t,n){if((n=="variable"||n=="type")&&t.prevToken==".")return"variableName.special"}},languageData:{closeBrackets:{brackets:["(","[","{","'",'"','"""']}}});function ta(e){(e.interpolationStack||(e.interpolationStack=[])).push(e.tokenize)}function Yn(e){return(e.interpolationStack||(e.interpolationStack=[])).pop()}function na(e){return e.interpolationStack?e.interpolationStack.length:0}function qt(e,t,n,r){var a=!1;if(t.eat(e))if(t.eat(e))a=!0;else return"string";function o(c,d){for(var p=!1;!c.eol();){if(!r&&!p&&c.peek()=="$")return ta(d),d.tokenize=ra,"string";var w=c.next();if(w==e&&!p&&(!a||c.match(e+e))){d.tokenize=null;break}p=!r&&!p&&w=="\\"}return"string"}return n.tokenize=o,o(t,n)}function ra(e,t){return e.eat("$"),e.eat("{")?t.tokenize=null:t.tokenize=ia,null}function ia(e,t){return e.eatWhile(/[\w_]/),t.tokenize=Yn(t),"variable"}var ja=de({name:"dart",keywords:$("this super static final const abstract class extends external factory implements mixin get native set typedef with enum throw rethrow assert break case continue default in return new deferred async await covariant try catch finally do else for if switch while import library export part of show hide is as extension on yield late required sealed base interface when inline"),blockKeywords:$("try catch finally do else for if switch while"),builtin:$("void bool num int double dynamic var String Null Never"),atoms:$("true false null"),number:/^(?:0x[a-f\d_]+|(?:[\d_]+\.?[\d_]*|\.[\d_]+)(?:e[-+]?[\d_]+)?)/i,hooks:{"@":function(e){return e.eatWhile(/[\w\$_\.]/),"meta"},"'":function(e,t){return qt("'",e,t,!1)},'"':function(e,t){return qt('"',e,t,!1)},r:function(e,t){var n=e.peek();return n=="'"||n=='"'?qt(e.next(),e,t,!0):!1},"}":function(e,t){return na(t)>0?(t.tokenize=Yn(t),null):!1},"/":function(e,t){return e.eat("*")?(t.tokenize=Qe(1),t.tokenize(e,t)):!1},token:function(e,t,n){if(n=="variable"){var r=RegExp("^[_$]*[A-Z][a-zA-Z0-9_$]*$","g");if(r.test(e.current()))return"type"}}}});var St=Ks(Qn(),1),Fe=null,Le=null,Ne={text:null,tree:null};function Jn(e){return Le||(Le=(async()=>{let t=new Uint8Array(await e("tree-sitter.wasm"));await St.default.init({wasmBinary:t});let n=await St.default.Language.load(new Uint8Array(await e("tree-sitter-c.wasm")));return Fe=new St.default,Fe.setLanguage(n),!0})().catch(t=>{throw Le=null,t}),Le)}var Oe=()=>Fe!==null;function ve(e,t){if(Fe)return Ne.text!==e&&(Ne.tree&&Ne.tree.delete(),Ne={text:e,tree:Fe.parse(e)}),t(Ne.tree.rootNode)}function er(){Ne.tree&&Ne.tree.delete(),Ne={text:null,tree:null},Fe&&Fe.delete(),Fe=null,Le=null}function tr(e){p=()=>e.wasm;var n=[],r="./this.program",a=(s,i)=>{throw i},o="";function c(s){return e.locateFile?e.locateFile(s,o):o+s}var d,p,w=console.log.bind(console),b=console.error.bind(console),T,x=!1,z;function B(s,i){s||m(i)}var N,k,A,M,L,O,se,X,K,le,fe=!1;function R(){var s=ht.buffer;N=new Int8Array(s),A=new Int16Array(s),k=new Uint8Array(s),M=new Uint16Array(s),L=new Int32Array(s),O=new Uint32Array(s),se=new Float32Array(s),X=new Float64Array(s),K=new BigInt64Array(s),le=new BigUint64Array(s)}function h(){if(e.preRun)for(typeof e.preRun=="function"&&(e.preRun=[e.preRun]);e.preRun.length;)Wr(e.preRun.shift());j(Se)}function u(){fe=!0,Xe.aa()}function f(){if(e.postRun)for(typeof e.postRun=="function"&&(e.postRun=[e.postRun]);e.postRun.length;)ie(e.postRun.shift());j(re)}function m(s){var l;(l=e.onAbort)==null||l.call(e,s),s="Aborted("+s+")",b(s),x=!0,s+=". Build with -sASSERTIONS for more info.";var i=new WebAssembly.RuntimeError(s);throw i}var y;function I(){return c("clang-format-esm.wasm")}function P(s){if(s==y&&T)return new Uint8Array(T);if(p)return p(s);throw'sync fetching of the wasm failed: you can preload it to Module["wasmBinary"] manually, or emcc.py will do that for you when generating HTML (but not JS)'}function W(s,i){var l,_=P(s);l=_,l instanceof WebAssembly.Module||(l=new WebAssembly.Module(l));var g=new WebAssembly.Instance(l,i);return[g,l]}function H(){var s={a:Bs};return s}function Y(){function s(_,g){return Xe=_.exports,zs(Xe),R(),Xe}var i=H();if(e.instantiateWasm)return new Promise((_,g)=>{e.instantiateWasm(i,(v,E)=>{_(s(v,E))})});y??=I();var l=W(y,i);return s(l[0])}class J{name="ExitStatus";constructor(i){this.message=`Program terminated with exit(${i})`,this.status=i}}var j=s=>{for(;s.length>0;)s.shift()(e)},re=[],ie=s=>re.push(s),Se=[],Wr=s=>Se.push(s),Ft=!0,_n=s=>Dn.get(s),Hr=(s,i)=>_n(s)(i);class jr{constructor(i){this.excPtr=i,this.ptr=i-24}set_type(i){O[this.ptr+4>>2]=i}get_type(){return O[this.ptr+4>>2]}set_destructor(i){O[this.ptr+8>>2]=i}get_destructor(){return O[this.ptr+8>>2]}set_caught(i){i=i?1:0,N[this.ptr+12]=i}get_caught(){return N[this.ptr+12]!=0}set_rethrown(i){i=i?1:0,N[this.ptr+13]=i}get_rethrown(){return N[this.ptr+13]!=0}init(i,l){this.set_adjusted_ptr(0),this.set_type(i),this.set_destructor(l)}set_adjusted_ptr(i){O[this.ptr+16>>2]=i}get_adjusted_ptr(){return O[this.ptr+16>>2]}}var fn=0,Vr=0,qr=(s,i,l)=>{var _=new jr(s);throw _.init(i,l),fn=s,Vr++,fn},Zr=s=>{},Gr=(s,i,l,_)=>{},Xr=(s,i)=>{},Kr=(s,i)=>{},Yr=(s,i,l)=>{},Qr=(s,i)=>{},Jr=(s,i,l,_)=>{},mn=globalThis.TextDecoder&&new TextDecoder,pn=(s,i,l,_)=>{var g=i+l;if(_)return g;for(;s[i]&&!(i>=g);)++i;return i},hn=(s,i=0,l,_)=>{var g=pn(s,i,l,_);if(g-i>16&&s.buffer&&mn)return mn.decode(s.subarray(i,g));for(var v="";i<g;){var E=s[i++];if(!(E&128)){v+=String.fromCharCode(E);continue}var S=s[i++]&63;if((E&224)==192){v+=String.fromCharCode((E&31)<<6|S);continue}var F=s[i++]&63;if((E&240)==224?E=(E&15)<<12|S<<6|F:E=(E&7)<<18|S<<12|F<<6|s[i++]&63,E<65536)v+=String.fromCharCode(E);else{var D=E-65536;v+=String.fromCharCode(55296|D>>10,56320|D&1023)}}return v},gn=(s,i,l)=>s?hn(k,s,i,l):"",ei={varargs:void 0,getStr(s){var i=gn(s);return i}};function ti(s,i,l,_){ei.varargs=_}var ni=(s,i,l,_)=>{},ri=(s,i)=>{},ii=(s,i,l)=>{},si=(s,i,l)=>{},ai=()=>m(""),ot={},yn=s=>{for(;s.length;){var i=s.pop(),l=s.pop();l(i)}};function je(s){return this.fromWireType(O[s>>2])}var Ae={},Ce={},lt={},oi=class extends Error{constructor(i){super(i),this.name="InternalError"}},ct=s=>{throw new oi(s)},Te=(s,i,l)=>{s.forEach(S=>lt[S]=i);function _(S){var F=l(S);F.length!==s.length&&ct("Mismatched type converter count");for(var D=0;D<s.length;++D)ue(s[D],F[D])}var g=new Array(i.length),v=[],E=0;for(let[S,F]of i.entries())Ce.hasOwnProperty(F)?g[S]=Ce[F]:(v.push(F),Ae.hasOwnProperty(F)||(Ae[F]=[]),Ae[F].push(()=>{g[S]=Ce[F],++E,E===v.length&&_(g)}));v.length===0&&_(g)},li=s=>{var i=ot[s];delete ot[s];var l=i.rawConstructor,_=i.rawDestructor,g=i.fields,v=g.map(E=>E.getterReturnType).concat(g.map(E=>E.setterArgumentType));Te([s],v,E=>{var S={};for(var[F,D]of g.entries()){let U=E[F],V=D.getter,q=D.getterContext,G=E[F+g.length],ee=D.setter,oe=D.setterContext;S[D.fieldName]={read:te=>U.fromWireType(V(q,te)),write:(te,Q)=>{var Ie=[];ee(oe,te,G.toWireType(Ie,Q)),yn(Ie)},optional:U.optional}}return[{name:i.name,fromWireType:U=>{var V={};for(var q in S)V[q]=S[q].read(U);return _(U),V},toWireType:(U,V)=>{for(var q in S)if(!(q in V)&&!S[q].optional)throw new TypeError(`Missing field: "${q}"`);var G=l();for(q in S)S[q].write(G,V[q]);return U!==null&&U.push(_,G),G},readValueFromPointer:je,destructorFunction:_}]})},ae=s=>{for(var i="";;){var l=k[s++];if(!l)return i;i+=String.fromCharCode(l)}},Ve=class extends Error{constructor(i){super(i),this.name="BindingError"}},Z=s=>{throw new Ve(s)};function ci(s,i,l={}){var _=i.name;if(s||Z(`type "${_}" must have a positive integer typeid pointer`),Ce.hasOwnProperty(s)){if(l.ignoreDuplicateRegistrations)return;Z(`Cannot register type '${_}' twice`)}if(Ce[s]=i,delete lt[s],Ae.hasOwnProperty(s)){var g=Ae[s];delete Ae[s],g.forEach(v=>v())}}function ue(s,i,l={}){return ci(s,i,l)}var bn=(s,i,l)=>{switch(i){case 1:return l?_=>N[_]:_=>k[_];case 2:return l?_=>A[_>>1]:_=>M[_>>1];case 4:return l?_=>L[_>>2]:_=>O[_>>2];case 8:return l?_=>K[_>>3]:_=>le[_>>3];default:throw new TypeError(`invalid integer width (${i}): ${s}`)}},ui=(s,i,l,_,g)=>{i=ae(i);let v=_===0n,E=S=>S;if(v){let S=l*8;E=F=>BigInt.asUintN(S,F),g=E(g)}ue(s,{name:i,fromWireType:E,toWireType:(S,F)=>(typeof F=="number"&&(F=BigInt(F)),F),readValueFromPointer:bn(i,l,!v),destructorFunction:null})},di=(s,i,l,_)=>{i=ae(i),ue(s,{name:i,fromWireType:function(g){return!!g},toWireType:function(g,v){return v?l:_},readValueFromPointer:function(g){return this.fromWireType(k[g])},destructorFunction:null})},_i=s=>({count:s.count,deleteScheduled:s.deleteScheduled,preservePointerOnDelete:s.preservePointerOnDelete,ptr:s.ptr,ptrType:s.ptrType,smartPtr:s.smartPtr,smartPtrType:s.smartPtrType}),Ct=s=>{function i(l){return l.$$.ptrType.registeredClass.name}Z(i(s)+" instance already deleted")},kt=!1,wn=s=>{},fi=s=>{s.smartPtr?s.smartPtrType.rawDestructor(s.smartPtr):s.ptrType.registeredClass.rawDestructor(s.ptr)},vn=s=>{s.count.value-=1;var i=s.count.value===0;i&&fi(s)},qe=s=>globalThis.FinalizationRegistry?(kt=new FinalizationRegistry(i=>{vn(i.$$)}),qe=i=>{var l=i.$$,_=!!l.smartPtr;if(_){var g={$$:l};kt.register(i,g,i)}return i},wn=i=>kt.unregister(i),qe(s)):(qe=i=>i,s),ut=[],mi=()=>{for(;ut.length;){var s=ut.pop();s.$$.deleteScheduled=!1,s.delete()}},En,pi=()=>{let s=dt.prototype;Object.assign(s,{isAliasOf(l){if(!(this instanceof dt)||!(l instanceof dt))return!1;var _=this.$$.ptrType.registeredClass,g=this.$$.ptr;l.$$=l.$$;for(var v=l.$$.ptrType.registeredClass,E=l.$$.ptr;_.baseClass;)g=_.upcast(g),_=_.baseClass;for(;v.baseClass;)E=v.upcast(E),v=v.baseClass;return _===v&&g===E},clone(){if(this.$$.ptr||Ct(this),this.$$.preservePointerOnDelete)return this.$$.count.value+=1,this;var l=qe(Object.create(Object.getPrototypeOf(this),{$$:{value:_i(this.$$)}}));return l.$$.count.value+=1,l.$$.deleteScheduled=!1,l},delete(){this.$$.ptr||Ct(this),this.$$.deleteScheduled&&!this.$$.preservePointerOnDelete&&Z("Object already scheduled for deletion"),wn(this),vn(this.$$),this.$$.preservePointerOnDelete||(this.$$.smartPtr=void 0,this.$$.ptr=void 0)},isDeleted(){return!this.$$.ptr},deleteLater(){return this.$$.ptr||Ct(this),this.$$.deleteScheduled&&!this.$$.preservePointerOnDelete&&Z("Object already scheduled for deletion"),ut.push(this),ut.length===1&&En&&En(mi),this.$$.deleteScheduled=!0,this}});let i=Symbol.dispose;i&&(s[i]=s.delete)};function dt(){}var At=(s,i)=>Object.defineProperty(i,"name",{value:s}),Sn={},Rt=(s,i,l)=>{if(s[i].overloadTable===void 0){var _=s[i];s[i]=function(...g){return s[i].overloadTable.hasOwnProperty(g.length)||Z(`Function '${l}' called with an invalid number of arguments (${g.length}) - expects one of (${s[i].overloadTable})!`),s[i].overloadTable[g.length].apply(this,g)},s[i].overloadTable=[],s[i].overloadTable[_.argCount]=_}},_t=(s,i,l)=>{e.hasOwnProperty(s)?((l===void 0||e[s].overloadTable!==void 0&&e[s].overloadTable[l]!==void 0)&&Z(`Cannot register public name '${s}' twice`),Rt(e,s,s),e[s].overloadTable.hasOwnProperty(l)&&Z(`Cannot register multiple overloads of a function with the same number of arguments (${l})!`),e[s].overloadTable[l]=i):(e[s]=i,e[s].argCount=l)},hi=48,gi=57,yi=s=>{s=s.replace(/[^a-zA-Z0-9_]/g,"$");var i=s.charCodeAt(0);return i>=hi&&i<=gi?`_${s}`:s};function bi(s,i,l,_,g,v,E,S){this.name=s,this.constructor=i,this.instancePrototype=l,this.rawDestructor=_,this.baseClass=g,this.getActualType=v,this.upcast=E,this.downcast=S,this.pureVirtualFunctions=[]}var $t=(s,i,l)=>{for(;i!==l;)i.upcast||Z(`Expected null or instance of ${l.name}, got an instance of ${i.name}`),s=i.upcast(s),i=i.baseClass;return s},Pt=s=>{if(s===null)return"null";var i=typeof s;return i==="object"||i==="array"||i==="function"?s.toString():""+s};function wi(s,i){if(i===null)return this.isReference&&Z(`null is not a valid ${this.name}`),0;i.$$||Z(`Cannot pass "${Pt(i)}" as a ${this.name}`),i.$$.ptr||Z(`Cannot pass deleted object as a pointer of type ${this.name}`);var l=i.$$.ptrType.registeredClass,_=$t(i.$$.ptr,l,this.registeredClass);return _}function vi(s,i){var l;if(i===null)return this.isReference&&Z(`null is not a valid ${this.name}`),this.isSmartPointer?(l=this.rawConstructor(),s!==null&&s.push(this.rawDestructor,l),l):0;(!i||!i.$$)&&Z(`Cannot pass "${Pt(i)}" as a ${this.name}`),i.$$.ptr||Z(`Cannot pass deleted object as a pointer of type ${this.name}`),!this.isConst&&i.$$.ptrType.isConst&&Z(`Cannot convert argument of type ${i.$$.smartPtrType?i.$$.smartPtrType.name:i.$$.ptrType.name} to parameter type ${this.name}`);var _=i.$$.ptrType.registeredClass;if(l=$t(i.$$.ptr,_,this.registeredClass),this.isSmartPointer)switch(i.$$.smartPtr===void 0&&Z("Passing raw pointer to smart pointer is illegal"),this.sharingPolicy){case 0:i.$$.smartPtrType===this?l=i.$$.smartPtr:Z(`Cannot convert argument of type ${i.$$.smartPtrType?i.$$.smartPtrType.name:i.$$.ptrType.name} to parameter type ${this.name}`);break;case 1:l=i.$$.smartPtr;break;case 2:if(i.$$.smartPtrType===this)l=i.$$.smartPtr;else{var g=i.clone();l=this.rawShare(l,Dt.toHandle(()=>g.delete())),s!==null&&s.push(this.rawDestructor,l)}break;default:Z("Unsupported sharing policy")}return l}function Ei(s,i){if(i===null)return this.isReference&&Z(`null is not a valid ${this.name}`),0;i.$$||Z(`Cannot pass "${Pt(i)}" as a ${this.name}`),i.$$.ptr||Z(`Cannot pass deleted object as a pointer of type ${this.name}`),i.$$.ptrType.isConst&&Z(`Cannot convert argument of type ${i.$$.ptrType.name} to parameter type ${this.name}`);var l=i.$$.ptrType.registeredClass,_=$t(i.$$.ptr,l,this.registeredClass);return _}var Tn=(s,i,l)=>{if(i===l)return s;if(l.baseClass===void 0)return null;var _=Tn(s,i,l.baseClass);return _===null?null:l.downcast(_)},Si={},Ti=(s,i)=>{for(i===void 0&&Z("ptr should not be undefined");s.baseClass;)i=s.upcast(i),s=s.baseClass;return i},Ii=(s,i)=>(i=Ti(s,i),Si[i]),ft=(s,i)=>{(!i.ptrType||!i.ptr)&&ct("makeClassHandle requires ptr and ptrType");var l=!!i.smartPtrType,_=!!i.smartPtr;return l!==_&&ct("Both smartPtrType and smartPtr must be specified"),i.count={value:1},qe(Object.create(s,{$$:{value:i,writable:!0}}))};function Mi(s){var i=this.getPointee(s);if(!i)return this.destructor(s),null;var l=Ii(this.registeredClass,i);if(l!==void 0){if(l.$$.count.value===0)return l.$$.ptr=i,l.$$.smartPtr=s,l.clone();var _=l.clone();return this.destructor(s),_}function g(){return this.isSmartPointer?ft(this.registeredClass.instancePrototype,{ptrType:this.pointeeType,ptr:i,smartPtrType:this,smartPtr:s}):ft(this.registeredClass.instancePrototype,{ptrType:this,ptr:s})}var v=this.registeredClass.getActualType(i),E=Sn[v];if(!E)return g.call(this);var S;this.isConst?S=E.constPointerType:S=E.pointerType;var F=Tn(i,this.registeredClass,S.registeredClass);return F===null?g.call(this):this.isSmartPointer?ft(S.registeredClass.instancePrototype,{ptrType:S,ptr:F,smartPtrType:this,smartPtr:s}):ft(S.registeredClass.instancePrototype,{ptrType:S,ptr:F})}var xi=()=>{Object.assign(mt.prototype,{getPointee(s){return this.rawGetPointee&&(s=this.rawGetPointee(s)),s},destructor(s){var i;(i=this.rawDestructor)==null||i.call(this,s)},readValueFromPointer:je,fromWireType:Mi})};function mt(s,i,l,_,g,v,E,S,F,D,U){this.name=s,this.registeredClass=i,this.isReference=l,this.isConst=_,this.isSmartPointer=g,this.pointeeType=v,this.sharingPolicy=E,this.rawGetPointee=S,this.rawConstructor=F,this.rawShare=D,this.rawDestructor=U,!g&&i.baseClass===void 0?_?(this.toWireType=wi,this.destructorFunction=null):(this.toWireType=Ei,this.destructorFunction=null):this.toWireType=vi}var Ni=(s,i,l)=>{e.hasOwnProperty(s)||ct("Replacing nonexistent public symbol"),e[s].overloadTable!==void 0&&l!==void 0?e[s].overloadTable[l]=i:(e[s]=i,e[s].argCount=l)},me=(s,i,l=!1)=>{s=ae(s);function _(){var v=_n(i);return v}var g=_();return typeof g!="function"&&Z(`unknown function pointer with signature ${s}: ${i}`),g};class Fi extends Error{}var In=s=>{var i=Ln(s),l=ae(i);return ye(i),l},pt=(s,i)=>{var l=[],_={};function g(v){if(!_[v]&&!Ce[v]){if(lt[v]){lt[v].forEach(g);return}l.push(v),_[v]=!0}}throw i.forEach(g),new Fi(`${s}: `+l.map(In).join([", "]))},Ci=(s,i,l,_,g,v,E,S,F,D,U,V,q)=>{U=ae(U),v=me(g,v),S&&=me(E,S),D&&=me(F,D),q=me(V,q);var G=yi(U);_t(G,function(){pt(`Cannot construct ${U} due to unbound types`,[_])}),Te([s,i,l],_?[_]:[],ee=>{ee=ee[0];var oe,te;_?(oe=ee.registeredClass,te=oe.instancePrototype):te=dt.prototype;var Q=At(U,function(...Ht){if(Object.getPrototypeOf(this)!==Ie)throw new Ve(`Use 'new' to construct ${U}`);if(_e.constructor_body===void 0)throw new Ve(`${U} has no accessible constructor`);var Un=_e.constructor_body[Ht.length];if(Un===void 0)throw new Ve(`Tried to invoke ctor of ${U} with invalid number of parameters (${Ht.length}) - expected (${Object.keys(_e.constructor_body).toString()}) parameters instead!`);return Un.apply(this,Ht)}),Ie=Object.create(te,{constructor:{value:Q}});Q.prototype=Ie;var _e=new bi(U,Q,Ie,q,oe,v,S,D);_e.baseClass&&(_e.baseClass.__derivedClasses??=[],_e.baseClass.__derivedClasses.push(_e));var Wt=new mt(U,_e,!0,!1,!1),be=new mt(U+"*",_e,!1,!1,!1),gt=new mt(U+" const*",_e,!1,!0,!1);return Sn[s]={pointerType:be,constPointerType:gt},Ni(G,Q),[Wt,be,gt]})};function ki(s){for(var i=1;i<s.length;++i)if(s[i]!==null&&s[i].destructorFunction===void 0)return!0;return!1}function Lt(s,i,l,_,g,v){var E=i.length;E<2&&Z("argTypes array size mismatch! Must at least get return value and 'this' types!");var S=i[1]!==null&&l!==null,F=ki(i),D=!i[0].isVoid,U=E-2,V=new Array(U),q=[],G=[],ee=function(...oe){G.length=0;var te;q.length=S?2:1,q[0]=g,S&&(te=i[1].toWireType(G,this),q[1]=te);for(var Q=0;Q<U;++Q)V[Q]=i[Q+2].toWireType(G,oe[Q]),q.push(V[Q]);var Ie=_(...q);function _e(Wt){if(F)yn(G);else for(var be=S?1:2;be<i.length;be++){var gt=be===1?te:V[be-2];i[be].destructorFunction!==null&&i[be].destructorFunction(gt)}if(D)return i[0].fromWireType(Wt)}return _e(Ie)};return At(s,ee)}var Ot=(s,i)=>{for(var l=[],_=0;_<s;_++)l.push(O[i+_*4>>2]);return l},Mn=s=>{s=s.trim();let i=s.indexOf("(");return i===-1?s:s.slice(0,i)},Ai=(s,i,l,_,g,v,E,S,F)=>{var D=Ot(l,_);i=ae(i),i=Mn(i),v=me(g,v,S),Te([],[s],U=>{U=U[0];var V=`${U.name}.${i}`;function q(){pt(`Cannot call ${V} due to unbound types`,D)}i.startsWith("@@")&&(i=Symbol[i.substring(2)]);var G=U.registeredClass.constructor;return G[i]===void 0?(q.argCount=l-1,G[i]=q):(Rt(G,i,V),G[i].overloadTable[l-1]=q),Te([],D,ee=>{var oe=[ee[0],null].concat(ee.slice(1)),te=Lt(V,oe,null,v,E,S);if(G[i].overloadTable===void 0?(te.argCount=l-1,G[i]=te):G[i].overloadTable[l-1]=te,U.registeredClass.__derivedClasses)for(let Q of U.registeredClass.__derivedClasses)Q.constructor.hasOwnProperty(i)||(Q.constructor[i]=te);return[]}),[]})},Ri=(s,i,l,_,g,v)=>{var E=Ot(i,l);g=me(_,g),Te([],[s],S=>{S=S[0];var F=`constructor ${S.name}`;if(S.registeredClass.constructor_body===void 0&&(S.registeredClass.constructor_body=[]),S.registeredClass.constructor_body[i-1]!==void 0)throw new Ve(`Cannot register multiple constructors with identical number of parameters (${i-1}) for class '${S.name}'! Overload resolution is currently only performed using the parameter count, not actual type info!`);return S.registeredClass.constructor_body[i-1]=()=>{pt(`Cannot construct ${S.name} due to unbound types`,E)},Te([],E,D=>(D.splice(1,0,null),S.registeredClass.constructor_body[i-1]=Lt(F,D,null,g,v),[])),[]})},$i=(s,i,l,_,g,v,E,S,F,D)=>{var U=Ot(l,_);i=ae(i),i=Mn(i),v=me(g,v,F),Te([],[s],V=>{V=V[0];var q=`${V.name}.${i}`;i.startsWith("@@")&&(i=Symbol[i.substring(2)]),S&&V.registeredClass.pureVirtualFunctions.push(i);function G(){pt(`Cannot call ${q} due to unbound types`,U)}var ee=V.registeredClass.instancePrototype,oe=ee[i];return oe===void 0||oe.overloadTable===void 0&&oe.className!==V.name&&oe.argCount===l-2?(G.argCount=l-2,G.className=V.name,ee[i]=G):(Rt(ee,i,q),ee[i].overloadTable[l-2]=G),Te([],U,te=>{var Q=Lt(q,te,V,v,E,F);return ee[i].overloadTable===void 0?(Q.argCount=l-2,ee[i]=Q):ee[i].overloadTable[l-2]=Q,[]}),[]})},xn=[],Re=[0,1,,1,null,1,!0,1,!1,1],Pi=s=>{s>9&&--Re[s+1]===0&&(Re[s]=void 0,xn.push(s))},Dt={toValue:s=>(s||Z(`Cannot use deleted val. handle = ${s}`),Re[s]),toHandle:s=>{switch(s){case void 0:return 2;case null:return 4;case!0:return 6;case!1:return 8;default:{let i=xn.pop()||Re.length;return Re[i]=s,Re[i+1]=1,i}}}},Li={name:"emscripten::val",fromWireType:s=>{var i=Dt.toValue(s);return Pi(s),i},toWireType:(s,i)=>Dt.toHandle(i),readValueFromPointer:je,destructorFunction:null},Oi=s=>ue(s,Li),Ut=(s,i,l)=>{switch(i){case 1:return l?function(_){return this.fromWireType(N[_])}:function(_){return this.fromWireType(k[_])};case 2:return l?function(_){return this.fromWireType(A[_>>1])}:function(_){return this.fromWireType(M[_>>1])};case 4:return l?function(_){return this.fromWireType(L[_>>2])}:function(_){return this.fromWireType(O[_>>2])};default:throw new TypeError(`invalid integer width (${i}): ${s}`)}};function Di(s){return s===0?"object":s===1?"number":"string"}var Ui=(s,i,l,_,g)=>{i=ae(i);let v=Di(g);switch(v){case"object":{let D=function(){};D.values={},ue(s,{name:i,constructor:D,valueType:v,fromWireType:function(U){return this.constructor.values[U]},toWireType:(U,V)=>V.value,readValueFromPointer:Ut(i,l,_),destructorFunction:null}),_t(i,D);break}case"number":{var E={};ue(s,{name:i,keysMap:E,valueType:v,fromWireType:D=>D,toWireType:(D,U)=>U,readValueFromPointer:Ut(i,l,_),destructorFunction:null}),_t(i,E),delete e[i].argCount;break}case"string":{var S={},F={},E={};ue(s,{name:i,valuesMap:S,reverseMap:F,keysMap:E,valueType:v,fromWireType:function(U){return this.reverseMap[U]},toWireType:function(U,V){return this.valuesMap[V]},readValueFromPointer:Ut(i,l,_),destructorFunction:null}),_t(i,E),delete e[i].argCount;break}}},zi=(s,i)=>{var l=Ce[s];return l===void 0&&Z(`${i} has unknown type ${In(s)}`),l},Bi=(s,i,l)=>{var _=zi(s,"enum");switch(i=ae(i),_.valueType){case"object":{var g=_.constructor,v=Object.create(_.constructor.prototype,{value:{value:l},constructor:{value:At(`${_.name}_${i}`,function(){})}});g.values[l]=v,g[i]=v;break}case"number":{_.keysMap[i]=l;break}case"string":{_.valuesMap[i]=l,_.reverseMap[l]=i,_.keysMap[i]=i;break}}},Wi=(s,i)=>{switch(i){case 4:return function(l){return this.fromWireType(se[l>>2])};case 8:return function(l){return this.fromWireType(X[l>>3])};default:throw new TypeError(`invalid float width (${i}): ${s}`)}},Hi=(s,i,l)=>{i=ae(i),ue(s,{name:i,fromWireType:_=>_,toWireType:(_,g)=>g,readValueFromPointer:Wi(i,l),destructorFunction:null})},ji=(s,i,l,_,g)=>{i=ae(i);let v=_===0,E=F=>F;if(v){var S=32-8*l;E=F=>F<<S>>>S,g=E(g)}ue(s,{name:i,fromWireType:E,toWireType:(F,D)=>D,readValueFromPointer:bn(i,l,_!==0),destructorFunction:null})},Vi=(s,i,l)=>{var _=[Int8Array,Uint8Array,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array,BigInt64Array,BigUint64Array],g=_[i];function v(E){var S=O[E>>2],F=O[E+4>>2];return new g(N.buffer,F,S)}l=ae(l),ue(s,{name:l,fromWireType:v,readValueFromPointer:v},{ignoreDuplicateRegistrations:!0})},qi=(s,i,l,_)=>{if(!(_>0))return 0;for(var g=l,v=l+_-1,E=0;E<s.length;++E){var S=s.codePointAt(E);if(S<=127){if(l>=v)break;i[l++]=S}else if(S<=2047){if(l+1>=v)break;i[l++]=192|S>>6,i[l++]=128|S&63}else if(S<=65535){if(l+2>=v)break;i[l++]=224|S>>12,i[l++]=128|S>>6&63,i[l++]=128|S&63}else{if(l+3>=v)break;i[l++]=240|S>>18,i[l++]=128|S>>12&63,i[l++]=128|S>>6&63,i[l++]=128|S&63,E++}}return i[l]=0,l-g},$e=(s,i,l)=>qi(s,k,i,l),Nn=s=>{for(var i=0,l=0;l<s.length;++l){var _=s.charCodeAt(l);_<=127?i++:_<=2047?i+=2:_>=55296&&_<=57343?(i+=4,++l):i+=3}return i},Zi=(s,i)=>{i=ae(i);var l=!0;ue(s,{name:i,fromWireType(_){var g=O[_>>2],v=_+4,E;if(l)E=gn(v,g,!0);else{E="";for(var S=0;S<g;++S)E+=String.fromCharCode(k[v+S])}return ye(_),E},toWireType(_,g){g instanceof ArrayBuffer&&(g=new Uint8Array(g));var v,E=typeof g=="string";E||ArrayBuffer.isView(g)&&g.BYTES_PER_ELEMENT==1||Z("Cannot pass non-string to std::string"),l&&E?v=Nn(g):v=g.length;var S=Bt(4+v+1),F=S+4;if(O[S>>2]=v,E)if(l)$e(g,F,v+1);else for(var D=0;D<v;++D){var U=g.charCodeAt(D);U>255&&(ye(S),Z("String has UTF-16 code units that do not fit in 8 bits")),k[F+D]=U}else k.set(g,F);return _!==null&&_.push(ye,S),S},readValueFromPointer:je,destructorFunction(_){ye(_)}})},Fn=globalThis.TextDecoder?new TextDecoder("utf-16le"):void 0,Gi=(s,i,l)=>{var _=s>>1,g=pn(M,_,i/2,l);if(g-_>16&&Fn)return Fn.decode(M.subarray(_,g));for(var v="",E=_;E<g;++E){var S=M[E];v+=String.fromCharCode(S)}return v},Xi=(s,i,l)=>{if(l??=2147483647,l<2)return 0;l-=2;for(var _=i,g=l<s.length*2?l/2:s.length,v=0;v<g;++v){var E=s.charCodeAt(v);A[i>>1]=E,i+=2}return A[i>>1]=0,i-_},Ki=s=>s.length*2,Yi=(s,i,l)=>{for(var _="",g=s>>2,v=0;!(v>=i/4);v++){var E=O[g+v];if(!E&&!l)break;_+=String.fromCodePoint(E)}return _},Qi=(s,i,l)=>{if(l??=2147483647,l<4)return 0;for(var _=i,g=_+l-4,v=0;v<s.length;++v){var E=s.codePointAt(v);if(E>65535&&v++,L[i>>2]=E,i+=4,i+4>g)break}return L[i>>2]=0,i-_},Ji=s=>{for(var i=0,l=0;l<s.length;++l){var _=s.codePointAt(l);_>65535&&l++,i+=4}return i},es=(s,i,l)=>{l=ae(l);var _,g,v;i===2?(_=Gi,g=Xi,v=Ki):(_=Yi,g=Qi,v=Ji),ue(s,{name:l,fromWireType:E=>{var S=O[E>>2],F=_(E+4,S*i,!0);return ye(E),F},toWireType:(E,S)=>{typeof S!="string"&&Z(`Cannot pass non-string to C++ string type ${l}`);var F=v(S),D=Bt(4+F+i);return O[D>>2]=F/i,g(S,D+4,F+i),E!==null&&E.push(ye,D),D},readValueFromPointer:je,destructorFunction(E){ye(E)}})},ts=(s,i,l,_,g,v)=>{ot[s]={name:ae(i),rawConstructor:me(l,_),rawDestructor:me(g,v),fields:[]}},ns=(s,i,l,_,g,v,E,S,F,D)=>{ot[s].fields.push({fieldName:ae(i),getterReturnType:l,getter:me(_,g),getterContext:v,setterArgumentType:E,setter:me(S,F),setterContext:D})},rs=(s,i)=>{i=ae(i),ue(s,{isVoid:!0,name:i,fromWireType:()=>{},toWireType:(l,_)=>{}})},Cn=0,is=()=>{Ft=!1,Cn=0},ss=9007199254740992,as=-9007199254740992,Pe=s=>s<as||s>ss?NaN:Number(s);function os(s,i){s=Pe(s);var l=new Date(s*1e3);L[i>>2]=l.getUTCSeconds(),L[i+4>>2]=l.getUTCMinutes(),L[i+8>>2]=l.getUTCHours(),L[i+12>>2]=l.getUTCDate(),L[i+16>>2]=l.getUTCMonth(),L[i+20>>2]=l.getUTCFullYear()-1900,L[i+24>>2]=l.getUTCDay();var _=Date.UTC(l.getUTCFullYear(),0,1,0,0,0,0),g=(l.getTime()-_)/(1e3*60*60*24)|0;L[i+28>>2]=g}var ls=s=>s%4===0&&(s%100!==0||s%400===0),cs=[0,31,60,91,121,152,182,213,244,274,305,335],us=[0,31,59,90,120,151,181,212,243,273,304,334],ds=s=>{var i=ls(s.getFullYear()),l=i?cs:us,_=l[s.getMonth()]+s.getDate()-1;return _};function _s(s,i){s=Pe(s);var l=new Date(s*1e3);L[i>>2]=l.getSeconds(),L[i+4>>2]=l.getMinutes(),L[i+8>>2]=l.getHours(),L[i+12>>2]=l.getDate(),L[i+16>>2]=l.getMonth(),L[i+20>>2]=l.getFullYear()-1900,L[i+24>>2]=l.getDay();var _=ds(l)|0;L[i+28>>2]=_,L[i+36>>2]=-(l.getTimezoneOffset()*60);var g=new Date(l.getFullYear(),0,1),v=new Date(l.getFullYear(),6,1).getTimezoneOffset(),E=g.getTimezoneOffset(),S=(v!=E&&l.getTimezoneOffset()==Math.min(E,v))|0;L[i+32>>2]=S}function ms(s,i,l,_,g,v,E){return g=Pe(g),-52}function ps(s,i,l,_,g,v){v=Pe(v)}var Ze={},kn=s=>{if(s instanceof J||s=="unwind")return z;a(1,s)},An=()=>Ft||Cn>0,Rn=s=>{var i;z=s,An()||((i=e.onExit)==null||i.call(e,s),x=!0),a(s,new J(s))},hs=(s,i)=>{z=s,Rn(s)},$n=hs,gs=()=>{if(!An())try{$n(z)}catch(s){kn(s)}},ys=s=>{if(!x)try{s(),gs()}catch(i){kn(i)}},bs=()=>performance.now(),ws=(s,i)=>{if(Ze[s]&&(clearTimeout(Ze[s].id),delete Ze[s]),!i)return 0;var l=setTimeout(()=>{delete Ze[s],ys(()=>On(s,bs()))},i);return Ze[s]={id:l,timeout_ms:i},0},vs=(s,i,l,_)=>{var g=new Date().getFullYear(),v=new Date(g,0,1),E=new Date(g,6,1),S=v.getTimezoneOffset(),F=E.getTimezoneOffset(),D=Math.max(S,F);O[s>>2]=D*60,L[i>>2]=+(S!=F);var U=G=>{var ee=G>=0?"-":"+",oe=Math.abs(G),te=String(Math.floor(oe/60)).padStart(2,"0"),Q=String(oe%60).padStart(2,"0");return`UTC${ee}${te}${Q}`},V=U(S),q=U(F);F<S?($e(V,l,17),$e(q,_,17)):($e(V,_,17),$e(q,l,17))},Es=()=>Date.now(),Pn=()=>2147483648,Ss=()=>Pn(),Ts=(s,i)=>Math.ceil(s/i)*i,Is=s=>{var i=ht.buffer.byteLength,l=(s-i+65535)/65536|0;try{return ht.grow(l),R(),1}catch{}},Ms=s=>{var i=k.length;s>>>=0;var l=Pn();if(s>l)return!1;for(var _=1;_<=4;_*=2){var g=i*(1+.2/_);g=Math.min(g,s+100663296);var v=Math.min(l,Ts(Math.max(s,g),65536)),E=Is(v);if(E)return!0}return!1},zt={},xs=()=>r||"./this.program",Ge=()=>{var g;if(!Ge.strings){var s=(((g=globalThis.navigator)==null?void 0:g.language)??"C").replace("-","_")+".UTF-8",i={USER:"web_user",LOGNAME:"web_user",PATH:"/",PWD:"/",HOME:"/home/web_user",LANG:s,_:xs()};for(var l in zt)zt[l]===void 0?delete i[l]:i[l]=zt[l];var _=[];for(var l in i)_.push(`${l}=${i[l]}`);Ge.strings=_}return Ge.strings},Ns=(s,i)=>{var l=0,_=0;for(var g of Ge()){var v=i+l;O[s+_>>2]=v,l+=$e(g,v,1/0)+1,_+=4}return 0},Fs=(s,i)=>{var l=Ge();O[s>>2]=l.length;var _=0;for(var g of l)_+=Nn(g)+1;return O[i>>2]=_,0},Cs=s=>52,ks=(s,i)=>{var l=0,_=0,g=0;{var v=2;s==0?l=2:(s==1||s==2)&&(l=64),g=1}return N[i]=v,A[i+2>>1]=g,K[i+8>>3]=BigInt(l),K[i+16>>3]=BigInt(_),0};function As(s,i,l,_,g){return _=Pe(_),52}var Rs=(s,i,l,_)=>52;function $s(s,i,l,_){return i=Pe(i),70}var Ps=[null,[],[]],Ls=(s,i)=>{var l=Ps[s];i===0||i===10?((s===1?w:b)(hn(l)),l.length=0):l.push(i)},Os=(s,i,l,_)=>{for(var g=0,v=0;v<l;v++){var E=O[i>>2],S=O[i+4>>2];i+=8;for(var F=0;F<S;F++)Ls(s,k[E+F]);g+=S}return O[_>>2]=g,0};if(pi(),xi(),e.noExitRuntime&&(Ft=e.noExitRuntime),e.print&&(w=e.print),e.printErr&&(b=e.printErr),e.wasmBinary&&(T=e.wasmBinary),e.arguments&&(n=e.arguments),e.thisProgram&&(r=e.thisProgram),e.preInit)for(typeof e.preInit=="function"&&(e.preInit=[e.preInit]);e.preInit.length>0;)e.preInit.shift()();var Bt,ye,Ln,On,Ds,Us,ht,Dn;function zs(s){Bt=s.ca,ye=s.da,Ln=s.ea,On=s.fa,Ds=ht=s.$,Us=Dn=s.ba}var Bs={w:Hr,k:qr,P:Zr,Q:Gr,N:Xr,I:Kr,u:Yr,J:Qr,K:Jr,z:ti,t:ni,M:ri,q:ii,s:si,R:ai,A:li,j:ui,Y:di,p:Ci,g:Ai,l:Ri,c:$i,W:Oi,_:Ui,d:Bi,i:Hi,b:ji,a:Vi,X:Zi,e:es,L:ts,f:ns,Z:rs,x:is,D:os,E:_s,B:ms,C:ps,r:ws,F:vs,O:Es,n:Ss,m:Ms,T:Ns,U:Fs,V:$n,h:Cs,H:ks,y:As,v:Rs,G:$s,o:Os,S:Rn};function Ws(){h();function s(){var i;e.calledRun=!0,!x&&(u(),(i=e.onRuntimeInitialized)==null||i.call(e),f())}e.setStatus?(e.setStatus("Running..."),setTimeout(()=>{setTimeout(()=>e.setStatus(""),1),s()},1)):s()}var Xe;return Xe=Y(),Ws(),e}var De;function rr(e){De=e,It=()=>{}}var nr=typeof FinalizationRegistry>"u"?{register:()=>{},unregister:()=>{}}:new FinalizationRegistry(e=>{e.delete()}),nt=class{constructor(){It(),this._impl=new De.ClangFormat,nr.register(this,this._impl,this)}with_style(t){return this._impl.with_style(t),this}with_fallback_style(t){return this._impl.with_fallback_style(t),this}format(t,n="<stdin>"){let r=this._impl.format(t,n);return Tt(r)??t}format_range(t,n,r,a="<stdin>"){let o=this._impl.format_range(t,a,n,r);return Tt(o)??t}format_line(t,n,r,a="<stdin>"){let o=this._impl.format_line(t,a,n,r);return Tt(o)??t}static version(){return It(),De.ClangFormat.version()}static dump_config({style:t="file",filename:n="<stdin>",code:r=""}={}){It();let a=De.ClangFormat.dump_config(t,n,r);return Tt(a)}[Symbol.dispose](){this._impl&&(nr.unregister(this),this._impl.delete(),this._impl=null)}};function It(){throw new Error("uninit")}function Tt(e){let{status:t,content:n}=e;if(t===De.ResultStatus.Error)throw Error(n);return t===De.ResultStatus.Unchanged?null:n}function Xt(e,t="<stdin>",n="LLVM"){let r=new nt;try{return r.with_style(n).format(e,t)}finally{r[Symbol.dispose]()}}function Kt(e,t,n,r="<stdin>",a="LLVM"){let o=new nt().with_style(a);try{if(t<1)throw Error("start line should be at least 1");if(t>n)throw Error("start line should not exceed end line");return o.format_line(e,t,n,r)}finally{o[Symbol.dispose]()}}var Ue;async function sa(e){if(typeof Response=="function"&&e instanceof Response){if(typeof WebAssembly.compileStreaming=="function")try{return await WebAssembly.compileStreaming(e)}catch(r){if(e.ok&&t(e.type)&&e.headers.get("Content-Type")!=="application/wasm")console.warn("`WebAssembly.compileStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n",r);else throw r}let n=await e.arrayBuffer();return await WebAssembly.compile(n)}else return await WebAssembly.compile(e);function t(n){switch(n){case"basic":case"cors":case"default":return!0}return!1}}async function Yt(e){if(Ue!==void 0)return Ue;e===void 0&&(e=new URL("clang-format.wasm","file:///acode-c/")),(typeof e=="string"||typeof Request=="function"&&e instanceof Request||typeof URL=="function"&&e instanceof URL)&&(e=fetch(e));let t=await sa(await e);return Ue=aa(t)}function aa(e){return Ue=tr({wasm:e}),rr(Ue),Ue}var rt=null,Qt=!1;function ir(e){return rt||(rt=(async()=>{let t=await e("clang-format.wasm");return await Yt(t),Qt=!0,!0})().catch(t=>{throw rt=null,t}),rt)}var ze=()=>Qt,sr=["LLVM","Google","Chromium","Mozilla","WebKit","Microsoft","GNU","Linux","Custom"],Mt={style:"LLVM",indentWidth:4,useTab:!1,columnLimit:100,keepStyleIndent:!1,custom:""};function it(e={}){let t={...Mt,...e};if(t.style==="Custom")return(t.custom||"").trim()||"LLVM";if(t.style==="Linux")return"{BasedOnStyle: LLVM, IndentWidth: 8, TabWidth: 8, UseTab: Always, ColumnLimit: 80, BreakBeforeBraces: Linux, AllowShortIfStatementsOnASingleLine: Never, AllowShortLoopsOnASingleLine: false, AllowShortFunctionsOnASingleLine: None, IndentCaseLabels: false}";if(t.keepStyleIndent)return t.style;let n=[`BasedOnStyle: ${t.style}`,`IndentWidth: ${t.indentWidth}`,`TabWidth: ${t.indentWidth}`,`UseTab: ${t.useTab?"ForIndentation":"Never"}`];return t.columnLimit>=0&&n.push(`ColumnLimit: ${t.columnLimit}`),`{${n.join(", ")}}`}function Be(e,t,n){if(!Qt)throw new Error("clang-format is not loaded");return n?Kt(e,n.fromLine,n.toLine,"main.c",t):Xt(e,"main.c",t)}function ar(e,t={}){let n={...Mt,...t},r=n.useTab?"	":" ".repeat(n.indentWidth),a=e.replace(/\r\n?/g,`
`).split(`
`),o=[],c=0,d=0,p=!1,w=0;for(let b of a){let T=b.replace(/\s+$/,"");if(!T.trim()){++w<=2&&o.length&&o.push("");continue}w=0;let x=T.trim();if(p){o.push(r.repeat(c)+" "+x.replace(/^\*?\s?/,"* ").replace(/^\* \*\//,"*/")),x.includes("*/")&&(p=!1);continue}let z=x.replace(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\/\/.*$/g,""),B=/\/\*/.test(z)&&!/\*\//.test(z),N=z.replace(/\/\*.*?\*\//g,""),k=(N.match(/^\s*}+/)||[""])[0].replace(/\s/g,"").length,A=c-k;/^(case\b.*|default\s*):/.test(x)&&A>0&&(A-=1),x[0]==="#"&&(A=0),o.push(r.repeat(Math.max(0,A)+(d>0?1:0))+x);for(let M of N)M==="{"?c++:M==="}"?c=Math.max(0,c-1):M==="("?d++:M===")"&&(d=Math.max(0,d-1));B&&(p=!0)}for(;o.length&&o[o.length-1]==="";)o.pop();return o.join(`
`)+`
`}var oa=`
#stdio.h
fn|int printf(const char *format, ...)|Write formatted output to stdout. Returns characters written or a negative value on error.
fn|int fprintf(FILE *stream, const char *format, ...)|Write formatted output to a stream.
fn|int sprintf(char *buf, const char *format, ...)|Write formatted output into buf. Unbounded: prefer snprintf.
fn|int snprintf(char *buf, size_t size, const char *format, ...)|Write at most size bytes (including NUL) of formatted output into buf.
fn|int dprintf(int fd, const char *format, ...)|Write formatted output to a file descriptor.
fn|int vprintf(const char *format, va_list ap)|printf taking a va_list.
fn|int vfprintf(FILE *stream, const char *format, va_list ap)|fprintf taking a va_list.
fn|int vsnprintf(char *buf, size_t size, const char *format, va_list ap)|snprintf taking a va_list.
fn|int vsprintf(char *buf, const char *format, va_list ap)|sprintf taking a va_list. Unbounded: prefer vsnprintf.
fn|int scanf(const char *format, ...)|Read formatted input from stdin. Returns the number of items assigned or EOF.
fn|int fscanf(FILE *stream, const char *format, ...)|Read formatted input from a stream.
fn|int sscanf(const char *str, const char *format, ...)|Read formatted input from a string.
fn|int puts(const char *s)|Write s and a trailing newline to stdout.
fn|int fputs(const char *s, FILE *stream)|Write s to a stream (no newline added).
fn|int putchar(int c)|Write one character to stdout.
fn|int putc(int c, FILE *stream)|Write one character to a stream (may be a macro).
fn|int fputc(int c, FILE *stream)|Write one character to a stream.
fn|int getchar(void)|Read one character from stdin. Returns an int so EOF can be detected.
fn|int getc(FILE *stream)|Read one character from a stream (may be a macro).
fn|int fgetc(FILE *stream)|Read one character from a stream.
fn|int ungetc(int c, FILE *stream)|Push a character back onto an input stream.
fn|char *fgets(char *s, int size, FILE *stream)|Read at most size-1 characters, stopping after a newline. Returns NULL on EOF/error.
fn|char *gets(char *s)|REMOVED in C11. Cannot be used safely: use fgets.
fn|ssize_t getline(char **lineptr, size_t *n, FILE *stream)|POSIX. Read a whole line into a malloc'd buffer. Caller frees *lineptr.
fn|FILE *fopen(const char *path, const char *mode)|Open a file. Modes: r, w, a, r+, w+, a+ (add b for binary). Returns NULL on failure.
fn|FILE *freopen(const char *path, const char *mode, FILE *stream)|Reopen a stream on a different file.
fn|FILE *fdopen(int fd, const char *mode)|POSIX. Associate a stream with a file descriptor.
fn|FILE *tmpfile(void)|Create a temporary binary file removed on close.
fn|int fclose(FILE *stream)|Flush and close a stream.
fn|int fflush(FILE *stream)|Flush buffered output. fflush(NULL) flushes all output streams.
fn|size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream)|Read nmemb items of size bytes. Returns the number of items read.
fn|size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream)|Write nmemb items of size bytes. Returns the number of items written.
fn|int fseek(FILE *stream, long offset, int whence)|Reposition a stream. whence: SEEK_SET, SEEK_CUR, SEEK_END.
fn|long ftell(FILE *stream)|Current position of a stream, or -1 on error.
fn|void rewind(FILE *stream)|Reset the stream position to the start.
fn|int fgetpos(FILE *stream, fpos_t *pos)|Store the current position.
fn|int fsetpos(FILE *stream, const fpos_t *pos)|Restore a stored position.
fn|int feof(FILE *stream)|Nonzero if the end-of-file indicator is set.
fn|int ferror(FILE *stream)|Nonzero if the error indicator is set.
fn|void clearerr(FILE *stream)|Clear the EOF and error indicators.
fn|void perror(const char *s)|Print s and the message for the current errno to stderr.
fn|int remove(const char *path)|Delete a file.
fn|int rename(const char *old, const char *new)|Rename or move a file.
fn|int setvbuf(FILE *stream, char *buf, int mode, size_t size)|Set stream buffering (_IOFBF, _IOLBF, _IONBF).
fn|void setbuf(FILE *stream, char *buf)|Set stream buffer.
fn|int fileno(FILE *stream)|POSIX. File descriptor of a stream.
fn|FILE *popen(const char *command, const char *type)|POSIX. Run a command and open a pipe to it.
fn|int pclose(FILE *stream)|POSIX. Close a popen stream and wait for the command.
T |FILE|Opaque stream type.
T |fpos_t|Stream position type.
M |stdin|Standard input stream.
M |stdout|Standard output stream.
M |stderr|Standard error stream.
M |EOF|End-of-file / error return value (negative int).
M |BUFSIZ|Default stream buffer size.
M |SEEK_SET|fseek origin: start of file.
M |SEEK_CUR|fseek origin: current position.
M |SEEK_END|fseek origin: end of file.
M |FILENAME_MAX|Maximum length of a file name.
M |FOPEN_MAX|Minimum number of files that can be open at once.

#stdlib.h
fn|void *malloc(size_t size)|Allocate size uninitialised bytes. Returns NULL on failure; release with free.
fn|void *calloc(size_t nmemb, size_t size)|Allocate zero-initialised memory for nmemb elements.
fn|void *realloc(void *ptr, size_t size)|Resize an allocation. Assign to a temporary: on failure the original block is still valid.
fn|void free(void *ptr)|Release memory from malloc/calloc/realloc. free(NULL) is a no-op.
fn|void exit(int status)|Terminate the program after running atexit handlers and flushing streams.
fn|void _Exit(int status)|Terminate immediately without cleanup.
fn|void abort(void)|Abnormal termination (SIGABRT).
fn|int atexit(void (*func)(void))|Register a function to run at normal exit.
fn|int abs(int j)|Absolute value of an int.
fn|long labs(long j)|Absolute value of a long.
fn|long long llabs(long long j)|Absolute value of a long long.
fn|div_t div(int numerator, int denominator)|Quotient and remainder in one call.
fn|ldiv_t ldiv(long numerator, long denominator)|Quotient and remainder for long.
fn|int rand(void)|Pseudo-random int in [0, RAND_MAX]. Seed with srand.
fn|void srand(unsigned int seed)|Seed rand().
fn|int atoi(const char *nptr)|Convert string to int. No error detection: prefer strtol.
fn|long atol(const char *nptr)|Convert string to long. No error detection: prefer strtol.
fn|double atof(const char *nptr)|Convert string to double. No error detection: prefer strtod.
fn|long strtol(const char *nptr, char **endptr, int base)|Convert string to long with error checking via endptr and errno.
fn|unsigned long strtoul(const char *nptr, char **endptr, int base)|Convert string to unsigned long.
fn|long long strtoll(const char *nptr, char **endptr, int base)|Convert string to long long.
fn|unsigned long long strtoull(const char *nptr, char **endptr, int base)|Convert string to unsigned long long.
fn|double strtod(const char *nptr, char **endptr)|Convert string to double with error checking.
fn|float strtof(const char *nptr, char **endptr)|Convert string to float.
fn|void qsort(void *base, size_t nmemb, size_t size, int (*compar)(const void *, const void *))|Sort an array in place with a comparison callback.
fn|void *bsearch(const void *key, const void *base, size_t nmemb, size_t size, int (*compar)(const void *, const void *))|Binary search a sorted array.
fn|char *getenv(const char *name)|Value of an environment variable, or NULL.
fn|int setenv(const char *name, const char *value, int overwrite)|POSIX. Set an environment variable.
fn|int system(const char *command)|Run a shell command. Avoid with untrusted input.
fn|int mkstemp(char *template)|POSIX. Create a unique temporary file from a template ending in XXXXXX.
fn|long long atoll(const char *nptr)|Convert string to long long. No error detection: prefer strtoll.
fn|long random(void)|POSIX. Pseudo-random long in [0, 2^31).
fn|void srandom(unsigned int seed)|POSIX. Seed random().
fn|int rand_r(unsigned int *seedp)|POSIX. Re-entrant rand() with caller-supplied seed.
fn|double drand48(void)|POSIX. Uniform double in [0.0, 1.0).
fn|int unsetenv(const char *name)|POSIX. Remove an environment variable.
fn|char *mkdtemp(char *template)|POSIX. Create a unique temporary directory from a template ending in XXXXXX.
fn|char *realpath(const char *path, char *resolved_path)|POSIX. Canonicalise a path.
fn|int posix_memalign(void **memptr, size_t alignment, size_t size)|POSIX. Aligned allocation.
fn|void *aligned_alloc(size_t alignment, size_t size)|C11. Aligned allocation.
T |div_t|Result of div().
T |size_t|Unsigned type of sizeof results (also in stddef.h, string.h, stdio.h).
M |NULL|Null pointer constant.
M |EXIT_SUCCESS|Successful termination status (0).
M |EXIT_FAILURE|Unsuccessful termination status.
M |RAND_MAX|Maximum value returned by rand().

#string.h
fn|size_t strlen(const char *s)|Length of s excluding the terminating NUL.
fn|size_t strnlen(const char *s, size_t maxlen)|POSIX. Length of s, at most maxlen.
fn|char *strcpy(char *dest, const char *src)|Copy src into dest including NUL. Unbounded: prefer snprintf/memcpy with a length check.
fn|char *strncpy(char *dest, const char *src, size_t n)|Copy at most n bytes. Does NOT NUL-terminate if src is n or longer.
fn|char *strcat(char *dest, const char *src)|Append src to dest. Unbounded.
fn|char *strncat(char *dest, const char *src, size_t n)|Append at most n bytes of src, always NUL-terminating.
fn|int strcmp(const char *s1, const char *s2)|Compare two strings. Returns 0 when equal.
fn|int strncmp(const char *s1, const char *s2, size_t n)|Compare at most n bytes.
fn|int strcoll(const char *s1, const char *s2)|Compare using the current locale.
fn|char *strchr(const char *s, int c)|First occurrence of c in s, or NULL.
fn|char *strrchr(const char *s, int c)|Last occurrence of c in s, or NULL.
fn|char *strstr(const char *haystack, const char *needle)|First occurrence of needle in haystack, or NULL.
fn|size_t strspn(const char *s, const char *accept)|Length of the initial segment made only of accept characters.
fn|size_t strcspn(const char *s, const char *reject)|Length of the initial segment containing no reject characters.
fn|char *strpbrk(const char *s, const char *accept)|First character of s that is in accept.
fn|char *strtok(char *str, const char *delim)|Split a string into tokens. Not thread-safe, modifies str.
fn|char *strtok_r(char *str, const char *delim, char **saveptr)|POSIX. Re-entrant strtok.
fn|char *strsep(char **stringp, const char *delim)|BSD/POSIX. Split a string in place; replaces strtok.
fn|void *memccpy(void *dest, const void *src, int c, size_t n)|POSIX/C23. Copy until byte c is found or n bytes are copied.
fn|char *strsignal(int sig)|POSIX. Description of a signal number.
fn|char *strdup(const char *s)|POSIX/C23. Duplicate a string with malloc. Caller frees.
fn|char *strndup(const char *s, size_t n)|POSIX/C23. Duplicate at most n bytes with malloc.
fn|char *strerror(int errnum)|Message text for an errno value.
fn|void *memcpy(void *dest, const void *src, size_t n)|Copy n bytes. Regions must not overlap.
fn|void *memmove(void *dest, const void *src, size_t n)|Copy n bytes; regions may overlap.
fn|void *memset(void *s, int c, size_t n)|Fill n bytes with the byte c.
fn|int memcmp(const void *s1, const void *s2, size_t n)|Compare n bytes.
fn|void *memchr(const void *s, int c, size_t n)|Find byte c in the first n bytes.
#strings.h
fn|int strcasecmp(const char *s1, const char *s2)|POSIX. Case-insensitive strcmp.
fn|int strncasecmp(const char *s1, const char *s2, size_t n)|POSIX. Case-insensitive strncmp.

#math.h
fn|double sqrt(double x)|Square root. Link with -lm.
fn|double cbrt(double x)|Cube root.
fn|double pow(double x, double y)|x raised to the power y.
fn|double exp(double x)|e raised to x.
fn|double exp2(double x)|2 raised to x.
fn|double log(double x)|Natural logarithm.
fn|double log2(double x)|Base-2 logarithm.
fn|double log10(double x)|Base-10 logarithm.
fn|double sin(double x)|Sine (radians).
fn|double cos(double x)|Cosine (radians).
fn|double tan(double x)|Tangent (radians).
fn|double asin(double x)|Arc sine.
fn|double acos(double x)|Arc cosine.
fn|double atan(double x)|Arc tangent.
fn|double atan2(double y, double x)|Arc tangent of y/x using signs to pick the quadrant.
fn|double sinh(double x)|Hyperbolic sine.
fn|double cosh(double x)|Hyperbolic cosine.
fn|double tanh(double x)|Hyperbolic tangent.
fn|double ceil(double x)|Smallest integer not less than x.
fn|double floor(double x)|Largest integer not greater than x.
fn|double round(double x)|Round to nearest, halves away from zero.
fn|double trunc(double x)|Round toward zero.
fn|double fabs(double x)|Absolute value of a double.
fn|double fmod(double x, double y)|Floating-point remainder.
fn|double hypot(double x, double y)|sqrt(x*x + y*y) without overflow.
fn|double fmax(double x, double y)|Larger of two values.
fn|double fmin(double x, double y)|Smaller of two values.
fn|double copysign(double x, double y)|Magnitude of x with the sign of y.
fn|double frexp(double x, int *exp)|Split into normalised fraction and power of two.
fn|double ldexp(double x, int exp)|x times 2 to the exp.
fn|double modf(double x, double *iptr)|Split into integer and fractional parts.
fn|float sqrtf(float x)|float square root.
fn|float powf(float x, float y)|float pow.
fn|float fabsf(float x)|float absolute value.
fn|int isnan(double x)|Nonzero if x is NaN (macro).
fn|int isinf(double x)|Nonzero if x is infinite (macro).
M |M_PI|pi (POSIX / GNU extension).
M |M_E|e (POSIX / GNU extension).
M |HUGE_VAL|Positive overflow value for double.
M |INFINITY|Positive infinity (float).
M |NAN|Quiet NaN (float).

#ctype.h
fn|int isalpha(int c)|Nonzero if c is a letter.
fn|int isdigit(int c)|Nonzero if c is 0-9.
fn|int isalnum(int c)|Nonzero if c is a letter or digit.
fn|int isspace(int c)|Nonzero if c is whitespace.
fn|int isupper(int c)|Nonzero if c is upper case.
fn|int islower(int c)|Nonzero if c is lower case.
fn|int ispunct(int c)|Nonzero if c is punctuation.
fn|int isprint(int c)|Nonzero if c is printable (including space).
fn|int isgraph(int c)|Nonzero if c is printable and not space.
fn|int iscntrl(int c)|Nonzero if c is a control character.
fn|int isxdigit(int c)|Nonzero if c is a hex digit.
fn|int toupper(int c)|Convert to upper case.
fn|int tolower(int c)|Convert to lower case.

#time.h
fn|time_t time(time_t *tloc)|Current calendar time in seconds since the epoch.
fn|clock_t clock(void)|Processor time used. Divide by CLOCKS_PER_SEC.
fn|double difftime(time_t end, time_t beginning)|Seconds between two times.
fn|time_t mktime(struct tm *tm)|Convert broken-down local time to time_t.
fn|struct tm *localtime(const time_t *timer)|Convert to local broken-down time (static storage).
fn|struct tm *localtime_r(const time_t *timer, struct tm *result)|POSIX. Re-entrant localtime.
fn|struct tm *gmtime(const time_t *timer)|Convert to UTC broken-down time (static storage).
fn|struct tm *gmtime_r(const time_t *timer, struct tm *result)|POSIX. Re-entrant gmtime.
fn|size_t strftime(char *s, size_t max, const char *format, const struct tm *tm)|Format a broken-down time.
fn|char *asctime(const struct tm *tm)|Convert broken-down time to a string.
fn|char *ctime(const time_t *timer)|Convert time_t to a string.
fn|int clock_gettime(clockid_t clk_id, struct timespec *tp)|POSIX. Read a clock (CLOCK_REALTIME, CLOCK_MONOTONIC).
fn|int nanosleep(const struct timespec *req, struct timespec *rem)|POSIX. High-resolution sleep.
T |time_t|Calendar time type.
T |clock_t|Processor time type.
T |struct tm|Broken-down time.
M |CLOCKS_PER_SEC|clock() ticks per second.
M |CLOCK_MONOTONIC|Monotonic clock id.
M |CLOCK_REALTIME|Wall-clock id.

#stdint.h
T |int8_t|Exactly 8-bit signed integer.
T |int16_t|Exactly 16-bit signed integer.
T |int32_t|Exactly 32-bit signed integer.
T |int64_t|Exactly 64-bit signed integer.
T |uint8_t|Exactly 8-bit unsigned integer.
T |uint16_t|Exactly 16-bit unsigned integer.
T |uint32_t|Exactly 32-bit unsigned integer.
T |uint64_t|Exactly 64-bit unsigned integer.
T |intptr_t|Signed integer able to hold a pointer.
T |uintptr_t|Unsigned integer able to hold a pointer.
T |intmax_t|Largest signed integer type.
T |uintmax_t|Largest unsigned integer type.
M |INT32_MAX|Maximum int32_t.
M |INT32_MIN|Minimum int32_t.
M |INT64_MAX|Maximum int64_t.
M |UINT32_MAX|Maximum uint32_t.
M |UINT64_MAX|Maximum uint64_t.
M |SIZE_MAX|Maximum size_t.

#inttypes.h
M |PRId32|printf conversion for int32_t.
M |PRId64|printf conversion for int64_t.
M |PRIu32|printf conversion for uint32_t.
M |PRIu64|printf conversion for uint64_t.
M |PRIx64|printf hex conversion for uint64_t.
fn|intmax_t strtoimax(const char *nptr, char **endptr, int base)|Convert string to intmax_t.

#stdbool.h
T |bool|Boolean type (a keyword in C23).
M |true|Boolean true (1).
M |false|Boolean false (0).

#stddef.h
T |size_t|Unsigned type of sizeof results.
T |ptrdiff_t|Signed type of pointer subtraction.
T |wchar_t|Wide character type.
M |NULL|Null pointer constant.
fn|size_t offsetof(type, member)|Byte offset of member within type (macro).

#limits.h
M |INT_MAX|Maximum int.
M |INT_MIN|Minimum int.
M |UINT_MAX|Maximum unsigned int.
M |LONG_MAX|Maximum long.
M |LONG_MIN|Minimum long.
M |ULONG_MAX|Maximum unsigned long.
M |LLONG_MAX|Maximum long long.
M |LLONG_MIN|Minimum long long.
M |CHAR_BIT|Bits in a char.
M |CHAR_MAX|Maximum char.
M |SHRT_MAX|Maximum short.
M |PATH_MAX|Maximum path length (POSIX).

#float.h
M |DBL_MAX|Maximum finite double.
M |DBL_MIN|Minimum positive normalised double.
M |DBL_EPSILON|Difference between 1.0 and the next double.
M |FLT_MAX|Maximum finite float.
M |FLT_EPSILON|Difference between 1.0f and the next float.

#errno.h
M |errno|Thread-local error code set by failing library calls.
M |EINVAL|Invalid argument.
M |ENOENT|No such file or directory.
M |ENOMEM|Out of memory.
M |EACCES|Permission denied.
M |EEXIST|File exists.
M |EINTR|Interrupted system call.
M |EAGAIN|Resource temporarily unavailable.
M |ERANGE|Result out of range.

#assert.h
fn|void assert(scalar expression)|Abort with a diagnostic if the expression is false. Disabled by -DNDEBUG.

#signal.h
fn|sighandler_t signal(int signum, sighandler_t handler)|Install a signal handler. Prefer sigaction.
fn|int raise(int sig)|Send a signal to the calling process.
fn|int kill(pid_t pid, int sig)|POSIX. Send a signal to a process.
fn|int sigaction(int signum, const struct sigaction *act, struct sigaction *oldact)|POSIX. Examine or change a signal action.
fn|int sigemptyset(sigset_t *set)|POSIX. Initialise an empty signal set.
fn|int sigaddset(sigset_t *set, int signum)|POSIX. Add a signal to a set.
M |SIGINT|Interactive attention (Ctrl-C).
M |SIGTERM|Termination request.
M |SIGKILL|Kill (cannot be caught).
M |SIGSEGV|Invalid memory access.
M |SIGALRM|Timer expired.
M |SIGCHLD|Child stopped or terminated.
M |SIG_IGN|Ignore the signal.
M |SIG_DFL|Default action.

#setjmp.h
fn|int setjmp(jmp_buf env)|Save the calling environment. Returns 0, or nonzero after longjmp.
fn|void longjmp(jmp_buf env, int val)|Restore the environment saved by setjmp.
T |jmp_buf|Saved execution context.

#stdarg.h
fn|void va_start(va_list ap, last)|Start iterating variadic arguments (macro).
fn|type va_arg(va_list ap, type)|Fetch the next variadic argument (macro).
fn|void va_end(va_list ap)|End variadic iteration (macro).
fn|void va_copy(va_list dest, va_list src)|Copy a va_list (macro).
T |va_list|Variadic argument cursor.

#locale.h
fn|char *setlocale(int category, const char *locale)|Set or query the program locale.
M |LC_ALL|All locale categories.

#unistd.h
fn|ssize_t read(int fd, void *buf, size_t count)|Read up to count bytes from a descriptor.
fn|ssize_t write(int fd, const void *buf, size_t count)|Write up to count bytes to a descriptor.
fn|int close(int fd)|Close a file descriptor.
fn|off_t lseek(int fd, off_t offset, int whence)|Reposition a descriptor.
fn|int pipe(int pipefd[2])|Create a pipe: pipefd[0] reads, pipefd[1] writes.
fn|int dup(int oldfd)|Duplicate a descriptor.
fn|int dup2(int oldfd, int newfd)|Duplicate onto a specific descriptor.
fn|pid_t fork(void)|Create a child process. Returns 0 in the child.
fn|int execvp(const char *file, char *const argv[])|Replace the process image, searching PATH.
fn|int execl(const char *path, const char *arg, ...)|Replace the process image.
fn|int execlp(const char *file, const char *arg, ...)|Replace the process image, searching PATH. The argument list must end with (char *)NULL.
fn|int execv(const char *path, char *const argv[])|Replace the process image using an argument vector.
fn|int execve(const char *path, char *const argv[], char *const envp[])|Replace the process image with an explicit environment.
fn|void _exit(int status)|Terminate immediately without running atexit handlers or flushing stdio (use in a child after fork).
fn|unsigned int alarm(unsigned int seconds)|Deliver SIGALRM after the given number of seconds.
fn|int pause(void)|Sleep until a signal is delivered.
fn|int gethostname(char *name, size_t len)|Host name of the machine.
fn|uid_t getuid(void)|Real user id.
fn|uid_t geteuid(void)|Effective user id.
fn|gid_t getgid(void)|Real group id.
fn|int fsync(int fd)|Flush a descriptor's data to storage.
fn|int ftruncate(int fd, off_t length)|Set a file's length.
fn|int link(const char *oldpath, const char *newpath)|Create a hard link.
fn|int symlink(const char *target, const char *linkpath)|Create a symbolic link.
fn|pid_t setsid(void)|Create a new session.
fn|int chown(const char *path, uid_t owner, gid_t group)|Change file owner and group.
fn|pid_t getpid(void)|Process id.
fn|pid_t getppid(void)|Parent process id.
fn|unsigned int sleep(unsigned int seconds)|Sleep for seconds.
fn|int usleep(useconds_t usec)|Sleep for microseconds (obsolete: use nanosleep).
fn|int access(const char *path, int mode)|Check file accessibility (R_OK, W_OK, X_OK, F_OK).
fn|int unlink(const char *path)|Remove a name from the filesystem.
fn|int chdir(const char *path)|Change working directory.
fn|char *getcwd(char *buf, size_t size)|Current working directory.
fn|int isatty(int fd)|Nonzero if fd refers to a terminal.
fn|int getopt(int argc, char *const argv[], const char *optstring)|Parse short command-line options.
fn|long sysconf(int name)|Query system configuration.
fn|int rmdir(const char *path)|Remove an empty directory.
fn|ssize_t readlink(const char *path, char *buf, size_t bufsiz)|Read a symbolic link.
M |STDIN_FILENO|Descriptor 0.
M |STDOUT_FILENO|Descriptor 1.
M |STDERR_FILENO|Descriptor 2.
M |optarg|Argument of the current getopt option.
M |optind|Index of the next argv element for getopt.

#sys/wait.h
fn|pid_t wait(int *wstatus)|Wait for any child to change state.
fn|pid_t waitpid(pid_t pid, int *wstatus, int options)|Wait for a specific child.
M |WIFEXITED|True if the child exited normally.
M |WEXITSTATUS|Exit status of the child.

#fcntl.h
fn|int open(const char *path, int flags, ...)|Open a file and return a descriptor. Flags: O_RDONLY, O_WRONLY, O_RDWR, O_CREAT...
fn|int fcntl(int fd, int cmd, ...)|Manipulate a descriptor.
M |O_RDONLY|Open read-only.
M |O_WRONLY|Open write-only.
M |O_RDWR|Open read-write.
M |O_CREAT|Create the file if it does not exist.
M |O_TRUNC|Truncate to zero length.
M |O_APPEND|Append on each write.
M |O_NONBLOCK|Non-blocking mode.

#sys/stat.h
fn|int stat(const char *path, struct stat *buf)|Get file status.
fn|int fstat(int fd, struct stat *buf)|Get file status from a descriptor.
fn|int mkdir(const char *path, mode_t mode)|Create a directory.
fn|int chmod(const char *path, mode_t mode)|Change file permissions.

#dirent.h
fn|DIR *opendir(const char *name)|Open a directory stream.
fn|struct dirent *readdir(DIR *dirp)|Read the next directory entry.
fn|int closedir(DIR *dirp)|Close a directory stream.

#sys/time.h
fn|int gettimeofday(struct timeval *tv, struct timezone *tz)|POSIX (obsolescent). Wall-clock time with microseconds; prefer clock_gettime.
T |struct timeval|Seconds and microseconds.

#sys/select.h
fn|int select(int nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds, struct timeval *timeout)|Wait until descriptors are ready.
M |FD_SET|Add a descriptor to an fd_set.
M |FD_ISSET|Test a descriptor in an fd_set.
M |FD_ZERO|Clear an fd_set.

#sys/mman.h
fn|void *mmap(void *addr, size_t length, int prot, int flags, int fd, off_t offset)|Map a file or anonymous memory.
fn|int munmap(void *addr, size_t length)|Unmap memory.
M |PROT_READ|Pages may be read.
M |PROT_WRITE|Pages may be written.
M |MAP_PRIVATE|Private copy-on-write mapping.
M |MAP_SHARED|Shared mapping.
M |MAP_FAILED|Value returned by mmap on failure.

#pthread.h
fn|int pthread_create(pthread_t *thread, const pthread_attr_t *attr, void *(*start_routine)(void *), void *arg)|Start a new thread. Link with -pthread.
fn|int pthread_join(pthread_t thread, void **retval)|Wait for a thread to finish.
fn|int pthread_detach(pthread_t thread)|Mark a thread as detached.
fn|pthread_t pthread_self(void)|Calling thread id.
fn|void pthread_exit(void *retval)|Terminate the calling thread.
fn|int pthread_mutex_init(pthread_mutex_t *mutex, const pthread_mutexattr_t *attr)|Initialise a mutex.
fn|int pthread_mutex_lock(pthread_mutex_t *mutex)|Lock a mutex.
fn|int pthread_mutex_trylock(pthread_mutex_t *mutex)|Lock a mutex without blocking.
fn|int pthread_mutex_unlock(pthread_mutex_t *mutex)|Unlock a mutex.
fn|int pthread_mutex_destroy(pthread_mutex_t *mutex)|Destroy a mutex.
fn|int pthread_cond_init(pthread_cond_t *cond, const pthread_condattr_t *attr)|Initialise a condition variable.
fn|int pthread_cond_wait(pthread_cond_t *cond, pthread_mutex_t *mutex)|Wait on a condition variable.
fn|int pthread_cond_signal(pthread_cond_t *cond)|Wake one waiter.
fn|int pthread_cond_broadcast(pthread_cond_t *cond)|Wake all waiters.
fn|int pthread_cond_destroy(pthread_cond_t *cond)|Destroy a condition variable.
T |pthread_t|Thread handle.
T |pthread_mutex_t|Mutex.
T |pthread_cond_t|Condition variable.
M |PTHREAD_MUTEX_INITIALIZER|Static mutex initialiser.
M |PTHREAD_COND_INITIALIZER|Static condition variable initialiser.

#sys/socket.h
fn|int socket(int domain, int type, int protocol)|Create a socket.
fn|int bind(int sockfd, const struct sockaddr *addr, socklen_t addrlen)|Bind an address to a socket.
fn|int listen(int sockfd, int backlog)|Mark a socket as passive.
fn|int accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen)|Accept a connection.
fn|int connect(int sockfd, const struct sockaddr *addr, socklen_t addrlen)|Connect a socket.
fn|ssize_t send(int sockfd, const void *buf, size_t len, int flags)|Send on a connected socket.
fn|ssize_t recv(int sockfd, void *buf, size_t len, int flags)|Receive from a connected socket.
fn|ssize_t sendto(int sockfd, const void *buf, size_t len, int flags, const struct sockaddr *dest_addr, socklen_t addrlen)|Send a datagram.
fn|ssize_t recvfrom(int sockfd, void *buf, size_t len, int flags, struct sockaddr *src_addr, socklen_t *addrlen)|Receive a datagram.
fn|int setsockopt(int sockfd, int level, int optname, const void *optval, socklen_t optlen)|Set a socket option.
fn|int shutdown(int sockfd, int how)|Shut down part of a connection.
M |AF_INET|IPv4 address family.
M |AF_INET6|IPv6 address family.
M |SOCK_STREAM|TCP socket type.
M |SOCK_DGRAM|UDP socket type.
M |SOL_SOCKET|Socket-level option level.
M |SO_REUSEADDR|Allow address reuse.

#netinet/in.h
fn|uint16_t htons(uint16_t hostshort)|Host to network byte order (16-bit).
fn|uint32_t htonl(uint32_t hostlong)|Host to network byte order (32-bit).
fn|uint16_t ntohs(uint16_t netshort)|Network to host byte order (16-bit).
fn|uint32_t ntohl(uint32_t netlong)|Network to host byte order (32-bit).
T |struct sockaddr_in|IPv4 socket address.
M |INADDR_ANY|Bind to all interfaces.

#arpa/inet.h
fn|int inet_pton(int af, const char *src, void *dst)|Parse a text address into binary form.
fn|const char *inet_ntop(int af, const void *src, char *dst, socklen_t size)|Format a binary address as text.

#netdb.h
fn|int getaddrinfo(const char *node, const char *service, const struct addrinfo *hints, struct addrinfo **res)|Resolve a host and service name.
fn|void freeaddrinfo(struct addrinfo *res)|Free getaddrinfo results.
fn|const char *gai_strerror(int errcode)|Message for a getaddrinfo error.

#poll.h
fn|int poll(struct pollfd *fds, nfds_t nfds, int timeout)|Wait for events on descriptors.
`,ce=new Map,ke=[];(function(){let t=[];for(let n of oa.split(`
`)){let r=n.trim();if(!r)continue;if(r[0]==="#"){t=r.slice(1).split(",");for(let b of t)ke.includes(b)||ke.push(b);continue}let[a,o,...c]=r.split("|"),d=c.join("|"),p;if(a==="fn"){let b=/([A-Za-z_]\w*)\s*\(/.exec(o);if(!b)continue;p={name:b[1],sig:o,doc:d,headers:[...t],kind:"function"}}else if(a==="T ")p={name:o,sig:o,doc:d,headers:[...t],kind:"type"};else if(a==="M ")p={name:o,sig:o,doc:d,headers:[...t],kind:"macro"};else continue;let w=ce.get(p.name);if(w)for(let b of p.headers)w.headers.includes(b)||w.headers.push(b);else ce.set(p.name,p)}ke.sort()})();var or={"inttypes.h":["stdint.h"],"pthread.h":["time.h"],"sys/socket.h":[],"netinet/in.h":["sys/socket.h"],"arpa/inet.h":["netinet/in.h","sys/socket.h"],"netdb.h":["netinet/in.h","sys/socket.h"],"dirent.h":[]},lr=new Set(["sizeof","alignof","_Alignof","_Static_assert","static_assert","_Generic","__attribute__","__asm__","asm","typeof","__typeof__","defined","__builtin_expect","__builtin_unreachable","__builtin_trap"]);var la=["@codemirror/state","@codemirror/view","@codemirror/language","@codemirror/autocomplete","@codemirror/lint","@codemirror/commands","@lezer/highlight"];function cr(e){let t=[],n=o=>{try{let c=e(o);return c&&typeof c=="object"&&t.push(c),c}catch{return}},r=n("codemirror");for(let o of la)n(o);if(r)for(let o of Object.values(r))o&&typeof o=="object"&&!t.includes(o)&&t.push(o);let a=new Map;return{get(o){if(a.has(o))return a.get(o);let c;for(let d of t)try{if(d[o]!==void 0){c=d[o];break}}catch{}return a.set(o,c),c},has(...o){return o.every(c=>this.get(c)!==void 0)},sources:t}}function Ee(e,t){if(t(e)!==!1)for(let n=0,r=e.childCount;n<r;n++)Ee(e.child(n),t)}var We=new Set(["init_declarator","pointer_declarator","array_declarator","function_declarator","parenthesized_declarator","attributed_declarator","abstract_pointer_declarator"]);function he(e){for(;e;){let t=e.type;if(t==="identifier"||t==="type_identifier"||t==="field_identifier")return e;if(!We.has(t))return null;e=e.childForFieldName("declarator")||e.namedChild(0)}return null}function ur(e){for(;e;){if(e.type==="pointer_declarator"||e.type==="array_declarator"||e.type==="function_declarator")return!0;if(!We.has(e.type))return!1;e=e.childForFieldName("declarator")||e.namedChild(0)}return!1}function nn(e){for(;e;){if(e.type==="pointer_declarator")return!0;if(!We.has(e.type))return!1;e=e.childForFieldName("declarator")||e.namedChild(0)}return!1}var ca=new Set(["identifier","field_identifier","type_identifier"]);function Jt(e,t){if(t!=="declarator")return[];let n=e.childForFieldName("type"),r=[];for(let a=0;a<e.namedChildCount;a++){let o=e.namedChild(a);n&&o.startIndex===n.startIndex&&o.type===n.type||(We.has(o.type)||ca.has(o.type))&&r.push(o)}return r}function ua(e){for(;e;){if(e.type==="array_declarator"){let t=e.childForFieldName("size");return t&&t.type==="number_literal"&&/^\d+$/.test(t.text)?parseInt(t.text,10):null}if(!We.has(e.type))return null;e=e.childForFieldName("declarator")||e.namedChild(0)}return null}function en(e){for(;e;){if(e.type==="function_declarator"){let t=e.childForFieldName("declarator");return t&&t.type==="parenthesized_declarator"?null:e}if(!We.has(e.type))return null;e=e.childForFieldName("declarator")||e.namedChild(0)}return null}function da(e){if(e.type==="parameter_declaration"){for(let t=e.parent;t;t=t.parent){let n=t.type;if(n==="function_definition")return{from:t.startIndex,to:t.endIndex,global:!1};if(n==="compound_statement"||n==="declaration"||n==="field_declaration"||n==="type_definition"||n==="translation_unit")return null}return null}for(let t=e.parent;t;t=t.parent){let n=t.type;if(n==="compound_statement"||n==="for_statement")return{from:t.startIndex,to:t.endIndex,global:!1};if(n==="translation_unit")return{from:t.startIndex,to:t.endIndex,global:!0}}return{from:0,to:1/0,global:!0}}function pe(e){let t=[],n=(r,a,o,c)=>{if(!r)return;let d=da(o);!d&&a!=="field"||t.push({name:r.text,kind:a,identFrom:r.startIndex,identTo:r.endIndex,row:r.startPosition.row,scopeFrom:d?d.from:0,scopeTo:d?d.to:1/0,global:d?d.global:!0,...c})};return Ee(e,r=>{var a;switch(r.type){case"function_definition":{let o=r.childForFieldName("declarator"),c=en(o),d=he(o);return d&&t.push({name:d.text,kind:"function",identFrom:d.startIndex,identTo:d.endIndex,row:d.startPosition.row,scopeFrom:0,scopeTo:1/0,global:!0,defFrom:r.startIndex,defTo:r.endIndex,detail:_a(r)}),!0}case"declaration":{let o=r.childForFieldName("type");for(let c of Jt(r,"declarator")){let d=he(c);if(!d)continue;en(c)?n(d,"prototype",r,{defFrom:r.startIndex,defTo:r.endIndex,detail:tn(r.text.replace(/;\s*$/,""))}):n(d,"variable",r,{arrayLen:ua(c),isStatic:/\bstatic\b/.test(r.text.slice(0,o?o.startIndex-r.startIndex+1:0)),hasInit:c.type==="init_declarator",scalar:!!o&&o.type==="primitive_type"&&!ur(c),declFrom:r.startIndex})}return!0}case"parameter_declaration":{let o=he(r.childForFieldName("declarator"));if(o){let c=r.childForFieldName("type");n(o,"parameter",r,{arrayLen:null,scalar:!!c&&c.type==="primitive_type"&&!ur(r.childForFieldName("declarator"))})}return!0}case"type_definition":{for(let o of Jt(r,"declarator"))n(he(o),"typedef",r,{defFrom:r.startIndex,defTo:r.endIndex,detail:tn(r.text)});return!0}case"preproc_def":case"preproc_function_def":{let o=r.childForFieldName("name");if(o){let c=r.type==="preproc_function_def"?o.text+(((a=r.childForFieldName("parameters"))==null?void 0:a.text)??""):o.text;n(o,"macro",r,{defFrom:r.startIndex,defTo:r.endIndex,detail:`#define ${c}`})}return!0}case"enumerator":return n(r.childForFieldName("name"),"enumerator",r,{}),!0;case"field_declaration":{for(let o of Jt(r,"declarator"))n(he(o),"field",r,{});return!0}case"struct_specifier":case"union_specifier":case"enum_specifier":{let o=r.childForFieldName("name");if(o&&r.childForFieldName("body")){let c=r.type.replace("_specifier","");n(o,c,r,{defFrom:r.startIndex,defTo:r.endIndex,detail:`${c} ${o.text}`})}return!0}default:return!0}}),t}function tn(e){return e.replace(/\s+/g," ").trim()}function _a(e){let t=e.childForFieldName("body"),n=t?t.startIndex:e.endIndex;return tn(e.text.slice(0,n-e.startIndex))}function ge(e,t,n){let r=null;for(let a of e){if(a.name!==t||a.kind==="field"||n<a.scopeFrom||n>a.scopeTo||!a.global&&a.identFrom>n)continue;if(!r){r=a;continue}let o=a.scopeTo-a.scopeFrom,c=r.scopeTo-r.scopeFrom;(o<c||o===c&&r.kind==="prototype"&&a.kind!=="prototype")&&(r=a)}return r}function dr(e){let t=new Set(["function","prototype","typedef","macro","struct","union","enum","variable"]);return pe(e).filter(n=>n.global&&t.has(n.kind)&&(n.kind!=="variable"||n.scopeFrom===0)).map(n=>({name:n.name,kind:n.kind,row:n.row,from:n.identFrom,detail:n.detail||n.name})).sort((n,r)=>n.from-r.from)}function _r(e,t){let n=[];return Ee(e,r=>(r.childCount===0&&(r.type==="identifier"||r.type==="type_identifier"||r.type==="field_identifier")&&r.text===t&&n.push({from:r.startIndex,to:r.endIndex,type:r.type}),!0)),n}function rn(e,t){let n=e.descendantForIndex(t,t);if(n&&n.startIndex===t&&t>0){let r=e.descendantForIndex(t-1,t-1);r&&/identifier$/.test(r.type)&&!n.type.endsWith("identifier")&&(n=r)}return n&&/identifier$/.test(n.type)?{name:n.text,from:n.startIndex,to:n.endIndex,type:n.type}:null}function fr(e){return[...new Set(e.filter(t=>t.kind==="field").map(t=>t.name))]}function mr(e,t){let n=e.descendantForIndex(t,t);for(;n&&n.type!=="function_definition";)n=n.parent;if(!n)return null;let r=n.childForFieldName("declarator"),a=he(r),o=en(r),c=[],d=o&&o.childForFieldName("parameters");if(d)for(let b=0;b<d.namedChildCount;b++){let T=d.namedChild(b);if(T.type==="parameter_declaration"){let x=he(T.childForFieldName("declarator"));x&&c.push(x.text)}}let p=n.childForFieldName("type"),w=!!p&&p.text==="void"&&!nn(r);return{name:a?a.text:"",params:c,returnsVoid:w,from:n.startIndex,row:n.startPosition.row}}var pr=["stdio.h","stdlib.h","string.h","stddef.h","time.h","wchar.h","locale.h"],fa={size_t:pr,NULL:pr,ssize_t:["unistd.h","sys/types.h","stdio.h","sys/socket.h"],off_t:["unistd.h","sys/types.h","sys/stat.h","stdio.h","fcntl.h"],pid_t:["unistd.h","sys/types.h","sys/wait.h","signal.h","fcntl.h","pthread.h"],time_t:["time.h","sys/types.h","sys/stat.h"],va_list:["stdarg.h","stdio.h","stdlib.h"],intptr_t:["stdint.h","inttypes.h","unistd.h"],uint8_t:["stdint.h","inttypes.h","sys/types.h"],uint16_t:["stdint.h","inttypes.h","sys/types.h","arpa/inet.h","netinet/in.h"],uint32_t:["stdint.h","inttypes.h","sys/types.h","arpa/inet.h","netinet/in.h"],uint64_t:["stdint.h","inttypes.h","sys/types.h"],int8_t:["stdint.h","inttypes.h","sys/types.h"],int16_t:["stdint.h","inttypes.h","sys/types.h"],int32_t:["stdint.h","inttypes.h","sys/types.h"],int64_t:["stdint.h","inttypes.h","sys/types.h"],PATH_MAX:["limits.h","linux/limits.h","sys/syslimits.h"],errno:["errno.h"]},ma=new Set(["bool","true","false","nullptr"]),pa=new Set(["exit","abort","_Exit","quick_exit","longjmp","pthread_exit","__builtin_unreachable","execv","execvp","execl","execlp","execve"]),ha=new Set(["malloc","calloc","realloc","strdup","strndup","fopen","fdopen","popen","opendir","tmpfile","aligned_alloc"]),hr={strcpy:["warning","strcpy() does not check bounds; use snprintf() or memcpy() with an explicit length"],strcat:["warning","strcat() does not check bounds; track the length and use snprintf()/memcpy()"],sprintf:["warning","sprintf() cannot bound its output; use snprintf()"],vsprintf:["warning","vsprintf() cannot bound its output; use vsnprintf()"],tmpnam:["warning","tmpnam() is race-prone; use mkstemp()"],mktemp:["warning","mktemp() is race-prone; use mkstemp()"],atoi:["info","atoi() cannot report errors; use strtol()"],atol:["info","atol() cannot report errors; use strtol()"],atof:["info","atof() cannot report errors; use strtod()"],strncpy:["info","strncpy() does not NUL-terminate when the source fills the buffer"],alloca:["info","alloca() can overflow the stack silently; prefer a fixed array or malloc()"]},gr={printf:0,fprintf:1,sprintf:1,snprintf:2,dprintf:1,vprintf:0,vfprintf:1,vsnprintf:2,vsprintf:1},yr={scanf:0,fscanf:1,sscanf:1},ga=new Set(["vprintf","vfprintf","vsnprintf","vsprintf"]),ya={std:"c17",semantic:!0,unused:!0,hints:!0};function br(e,t=!1){let n=t?/%(\*?)([-+ #0']*)(\*|\d+)?(?:\.(\*|\d+))?(hh|h|ll|l|j|z|t|L)?([diouxXeEfFgGaAcspn%]|\[[^\]]*\])/g:/%()([-+ #0']*)(\*|\d+)?(?:\.(\*|\d+))?(hh|h|ll|l|j|z|t|L)?([diouxXeEfFgGaAcspn%]|\[[^\]]*\])/g,r=[],a;for(;a=n.exec(e);){let o=a[6][0]==="["?"[":a[6];if(o==="%")continue;let c=(a[3]==="*"?1:0)+(a[4]==="*"?1:0);r.push({conv:o,length:a[5]||"",suppressed:a[1]==="*",stars:c,width:a[3]&&a[3]!=="*"?a[3]:null,text:a[0]})}return r}function sn(e){if(!e)return null;if(e.type==="string_literal")return e.text.replace(/^[LuU8]*"/,"").replace(/"$/,"");if(e.type==="concatenated_string"){let t="";for(let n=0;n<e.namedChildCount;n++){let r=sn(e.namedChild(n));if(r===null)return null;t+=r}return t}return null}function an(e){switch(e.type){case"string_literal":case"concatenated_string":return"string";case"char_literal":return"char";case"number_literal":return/^0[xX]/.test(e.text)?"int":/[.eE]|[fF]$/.test(e.text)?"float":"int";case"sizeof_expression":return"size_t";case"call_expression":{let t=e.childForFieldName("function");return t&&(t.text==="strlen"||t.text==="fread"||t.text==="fwrite")?"size_t":null}case"parenthesized_expression":return e.namedChild(0)?an(e.namedChild(0)):null;default:return null}}function wr(e){let t=e.childForFieldName("arguments"),n=[];if(!t)return n;for(let r=0;r<t.namedChildCount;r++){let a=t.namedChild(r);a.type!=="comment"&&n.push(a)}return n}function ba(e){let t=new Set,n=!1,r=-1;Ee(e,o=>{if(o.type==="preproc_include"){let c=o.childForFieldName("path");if(c){let d=c.text;d[0]==="<"?t.add(d.slice(1,-1)):n=!0}return r=o.endIndex,!1}return o.type==="translation_unit"||o.type.startsWith("preproc_if")||o.type==="preproc_else"||o.type==="preproc_elif"});let a=!0;for(;a;){a=!1;for(let o of[...t])for(let c of or[o]||[])t.has(c)||(t.add(c),a=!0)}return{system:t,hasUser:n,lastIncludeEnd:r}}function wa(e,t,n){if(n.lastIncludeEnd>=0){let c=t.indexOf(`
`,n.lastIncludeEnd);return c===-1?t.length:c+1}let r=0,a=/^(?:\s*(?:\/\*[\s\S]*?\*\/|\/\/[^\n]*)\s*)*/.exec(t);a&&(r=a[0].length);let o=/^(\s*#ifndef\s+\w+\s*\n\s*#define\s+\w+[^\n]*\n)/.exec(t.slice(r));return o&&(r+=o[0].length),r}function xt(e,t={}){let n={...ya,...t};return ve(e,a=>va(a,e,n))||[]}function va(e,t,n){let r=[],a=(u,f,m,y,I,P)=>{if(!n.hints&&f==="info")return;let W=P?P[0]:u.startIndex,H=P?P[1]:u.endIndex;H<=W&&(H=Math.min(W+1,t.length)),r.push({from:W,to:H,severity:f,message:m,code:y,fix:I})};if(e.hasError()){let u=f=>{if(f.isMissing()){let m=f.startIndex;m>0&&(t[m]===`
`||t[m]==="\r"||m>=t.length)&&(m-=1),r.push({from:m,to:m+1,severity:"error",message:`Syntax error: missing '${f.type}'`,code:"syntax"});return}if(f.type==="ERROR"){let m=t.indexOf(`
`,f.startIndex),y=m===-1?f.endIndex:Math.min(f.endIndex,m),I=t.slice(f.startIndex,y).trim().slice(0,24);r.push({from:f.startIndex,to:Math.max(y,f.startIndex+1),severity:"error",message:`Syntax error near '${I}'`,code:"syntax"});return}if(f.hasError())for(let m=0;m<f.childCount;m++)u(f.child(m))};u(e)}if(!n.semantic)return vr(r);let o=ba(e),c=pe(e),d=new Set(c.map(u=>u.name)),p=new Set(c.map(u=>u.identFrom)),w=new Set,b=n.std==="c23",T=o.hasUser?"info":"warning",x=new Set,z=(u,f)=>{let m=ce.get(f);if(!m||d.has(f)||b&&ma.has(f))return;let y=new Set([...m.headers,...fa[f]||[]]);for(let H of y)if(o.system.has(H))return;let I=m.headers[0],P=f+"@"+u.startIndex;if(x.has(P))return;x.add(P);let W=wa(e,t,o);a(u,T,`'${f}' is declared in <${I}>, which is not included`,"missing-include",{label:`Add #include <${I}>`,from:W,to:W,insert:`#include <${I}>
`})},B=u=>u.hasError();if(Ee(e,u=>{if(u!==e&&B(u))return!1;switch(u.type){case"identifier":case"type_identifier":{if(p.has(u.startIndex))break;let f=ce.get(u.text);if(f&&f.kind!=="function"&&z(u,u.text),u.type==="identifier"){let m=ge(c,u.text,u.startIndex);m&&w.add(m)}break}case"primitive_type":{let f=ce.get(u.text);f&&f.kind==="type"&&z(u,u.text);break}case"null":case"true":case"false":z(u,u.type==="null"?"NULL":u.type);break;case"call_expression":N(u);break;case"if_statement":case"while_statement":case"do_statement":M(u),u.type==="if_statement"&&L(u.childForFieldName("consequence"),"if");break;case"binary_expression":O(u);break;case"subscript_expression":X(u);break;case"function_definition":K(u);break;case"compound_statement":le(u);break;default:}return!0}),n.unused&&!e.hasError()){for(let u of c)u.kind==="variable"&&!u.global&&!w.has(u)&&!u.name.startsWith("_")&&r.push({from:u.identFrom,to:u.identTo,severity:"info",message:`Unused variable '${u.name}'`,code:"unused"});for(let u of c)u.kind==="variable"&&u.global&&u.isStatic&&!w.has(u)&&r.push({from:u.identFrom,to:u.identTo,severity:"info",message:`Unused static variable '${u.name}'`,code:"unused"});if(!n.hints)for(let u=r.length-1;u>=0;u--)r[u].severity==="info"&&r.splice(u,1)}return vr(r);function N(u){let f=u.childForFieldName("function");if(!f||f.type!=="identifier")return;let m=f.text,y=wr(u),I=ge(c,m,f.startIndex);if(I&&w.add(I),m==="gets")a(f,"error","gets() was removed in C11 and cannot be used safely; use fgets()","gets");else if(hr[m]&&!I){let[P,W]=hr[m];a(f,P,W,"unsafe-call")}if(I||(ce.get(m)?z(f,m):!lr.has(m)&&!m.startsWith("__")&&!/^[A-Z][A-Z0-9_]*$/.test(m)&&a(f,o.hasUser?"info":"warning",`Call to undeclared function '${m}' (implicit declaration is invalid since C99)`,"implicit-decl")),!I&&m in gr&&!ga.has(m)?k(u,m,y):!I&&m in yr&&A(u,m,y),!I&&(m==="malloc"||m==="calloc")&&y.length===1&&m==="malloc"){let P=y[0];P.type==="number_literal"&&P.text==="0"&&a(P,"info","malloc(0) returns an implementation-defined result","malloc-zero")}}function k(u,f,m){let y=gr[f],I=m[y];if(!I)return;let P=sn(I);if(P===null){m.length===y+1&&(I.type==="identifier"||I.type==="call_expression"||I.type==="subscript_expression"||I.type==="field_expression")&&a(I,"warning",`Format string is not a literal and no arguments follow; use ${f}("%s", ...) to avoid format-string injection`,"format-nonliteral");return}let W=br(P),H=W.reduce((j,re)=>j+1+re.stars,0),Y=m.length-y-1;Y<H?a(I,"error",`Format string expects ${H} argument${H===1?"":"s"} but ${Y} ${Y===1?"was":"were"} given`,"format-args"):Y>H&&a(m[y+1+H],"warning",`Format string consumes ${H} argument${H===1?"":"s"} but ${Y} given`,"format-args");let J=y+1;for(let j of W){J+=j.stars;let re=m[J++];if(!re)break;let ie=an(re);if(!ie)continue;let Se=re;j.conv==="s"&&ie!=="string"?a(Se,"warning",`'%s' expects a string but the argument is ${ie==="size_t"?"a size":"a "+ie}`,"format-type"):"diuoxXc".includes(j.conv)?ie==="string"?a(Se,"warning",`'%${j.conv}' expects an integer but the argument is a string`,"format-type"):ie==="float"?a(Se,"warning",`'%${j.conv}' expects an integer but the argument is floating-point`,"format-type"):ie==="size_t"&&"diu".includes(j.conv)&&!j.length&&a(Se,"warning",`'%${j.conv}' expects int but the argument is size_t; use %zu`,"format-type"):"eEfFgGaA".includes(j.conv)&&(ie==="string"||ie==="int"||ie==="char"||ie==="size_t")&&a(Se,"warning",`'%${j.conv}' expects a double but the argument is ${ie==="int"?"an integer":"a "+ie}`,"format-type")}}function A(u,f,m){let y=yr[f],I=m[y],P=sn(I);if(P==null)return;let W=br(P,!0).filter(J=>!J.suppressed),H=W.length,Y=m.length-y-1;Y<H?a(I,"error",`Format string expects ${H} pointer argument${H===1?"":"s"} but ${Y} given`,"format-args"):Y>H&&a(m[y+1+H],"warning",`Format string consumes ${H} argument${H===1?"":"s"} but ${Y} given`,"format-args");for(let J of W)if(J.conv==="s"&&!J.width){a(I,"warning",`scanf '%s' without a field width can overflow the buffer (e.g. "%63s")`,"scanf-width");break}for(let J=y+1;J<m.length;J++){let j=m[J],re=an(j);if(re&&re!=="string")a(j,"error","scanf needs a pointer argument (did you forget '&'?)","scanf-pointer");else if(j.type==="identifier"){let ie=ge(c,j.text,j.startIndex);ie&&ie.scalar&&a(j,"error",`scanf needs a pointer: use &${j.text}`,"scanf-pointer",{label:`Use &${j.text}`,from:j.startIndex,to:j.startIndex,insert:"&"})}}}function M(u){let f=u.childForFieldName("condition");if(!f||f.type!=="parenthesized_expression")return;let m=f.namedChild(0);if(m&&m.type==="assignment_expression"){let y=m.childForFieldName("operator");y&&y.text==="="&&a(m,"warning","Assignment used as a condition; did you mean '=='? (add extra parentheses if intended)","assign-in-cond")}}function L(u,f){u&&u.type==="expression_statement"&&u.namedChildCount===0&&a(u,"warning",`Empty body after '${f}' - stray semicolon?`,"empty-body")}function O(u){let f=u.childForFieldName("operator"),m=u.childForFieldName("left"),y=u.childForFieldName("right");!f||!m||!y||((f.text==="=="||f.text==="!=")&&(se(m)||se(y))&&a(u,"warning","Comparing a string literal with '"+f.text+"' compares pointers; use strcmp()","string-compare"),(f.text==="/"||f.text==="%")&&y.type==="number_literal"&&/^0+$/.test(y.text)&&a(y,"error","Division by zero","div-zero"))}function se(u){return u.type==="string_literal"||u.type==="concatenated_string"}function X(u){let f=u.childForFieldName("argument"),m=u.childForFieldName("index");if(!f||!m||f.type!=="identifier"||m.type!=="number_literal"||!/^\d+$/.test(m.text))return;let y=ge(c,f.text,f.startIndex);y&&y.arrayLen!=null&&parseInt(m.text,10)>=y.arrayLen&&a(m,"error",`Index ${m.text} is out of bounds for '${f.text}' (size ${y.arrayLen})`,"bounds")}function K(u){let f=u.childForFieldName("type"),m=u.childForFieldName("declarator"),y=u.childForFieldName("body"),I=he(m);if(!f||!I||!y)return;let P=f.text==="void"&&!nn(m),W=I.text;W==="main"&&P&&a(f,"warning","'main' must return int","main-return");let H=!1,Y=!1,J=!1;Ee(y,j=>{if(j.type==="return_statement")j.namedChildCount>0&&j.namedChild(0).type!=="comment"?(H=!0,P&&a(j,"error",`Void function '${W}' should not return a value`,"void-return")):(Y=!0,P||a(j,"warning",`Non-void function '${W}' returns without a value`,"return-value"));else if(j.type==="call_expression"){let re=j.childForFieldName("function");re&&pa.has(re.text)&&(J=!0)}else if(j.type==="function_definition")return!1;return!0}),!P&&W!=="main"&&!H&&!J&&(/\bwhile\s*\(\s*(?:1|true)\s*\)|\bfor\s*\(\s*;\s*;\s*\)|__asm__|\basm\b/.test(y.text)||a(I,"warning",`Non-void function '${W}' never returns a value`,"no-return"))}function le(u){let f=[];for(let m=0;m<u.namedChildCount;m++){let y=u.namedChild(m);y.type!=="comment"&&f.push(y)}for(let m=0;m<f.length;m++){let y=f[m],I=f[m+1];if(I&&(y.type==="return_statement"||y.type==="break_statement"||y.type==="continue_statement"||y.type==="goto_statement")&&I.type!=="labeled_statement"&&I.type!=="case_statement"&&I.type!=="preproc_call"&&a(I,"info","Unreachable code","unreachable"),y.type==="expression_statement"){let W=y.namedChild(0);if(W&&W.type==="call_expression"){let H=W.childForFieldName("function"),Y=wr(W);if(H&&H.text==="free"&&Y.length===1&&Y[0].type==="identifier"){let J=Y[0].text;for(let j=m+1;j<f.length;j++){let re=h(f[j],J);if(re==="reassigned")break;if(re){a(re,"warning",`'${J}' is used after it was freed`,"use-after-free");break}}}}}let P=fe(y);if(P){let W=f[m+1];!(W&&(W.type==="if_statement"&&R(W.childForFieldName("condition"),P.name)||W.type==="expression_statement"&&/assert/.test(W.text)&&W.text.includes(P.name)))&&W&&a(P.node,"info",`Result of ${P.fn}() is not checked for NULL before use`,"unchecked-alloc")}}}function fe(u){let f=null,m=null;if(u.type==="declaration"){let y=u.namedChild(1);for(let I=0;I<u.namedChildCount;I++){let P=u.namedChild(I);P.type==="init_declarator"&&(f=P.childForFieldName("value"),m=he(P.childForFieldName("declarator")))}}else if(u.type==="expression_statement"){let y=u.namedChild(0);if(y&&y.type==="assignment_expression"){let I=y.childForFieldName("left");I&&I.type==="identifier"&&(m=I,f=y.childForFieldName("right"))}}if(!f||!m)return null;for(;f.type==="cast_expression";)f=f.childForFieldName("value");if(f&&f.type==="call_expression"){let y=f.childForFieldName("function");if(y&&ha.has(y.text)&&!ge(c,y.text,y.startIndex))return{name:m.text,fn:y.text,node:f}}return null}function R(u,f){if(!u)return!1;let m=!1;return Ee(u,y=>(y.type==="identifier"&&y.text===f&&(m=!0),!m)),m}function h(u,f){if(u.type==="expression_statement"){let y=u.namedChild(0);if(y&&y.type==="assignment_expression"){let I=y.childForFieldName("left");if(I&&I.type==="identifier"&&I.text===f)return"reassigned"}}if(u.type==="labeled_statement"||u.type==="return_statement"&&!R(u,f))return null;let m=null;return Ee(u,y=>{if(m)return!1;if(y.type==="assignment_expression"){let I=y.childForFieldName("left");if(I&&I.type==="identifier"&&I.text===f)return m=m||"reassigned-inner",!1}return y.type==="identifier"&&y.text===f?(m=y,!1):!0}),m==="reassigned-inner"?"reassigned":m}}function vr(e){let t=new Set,n=[];for(let r of e){let a=`${r.from}:${r.to}:${r.code}:${r.message}`;t.has(a)||(t.add(a),n.push(r))}return n.sort((r,a)=>r.from-a.from),n}function Er(e){let t=[],n=[],r={")":"(","]":"[","}":"{"},a=0,o=e.length;for(;a<o;){let p=e[a],w=e[a+1];if(p==="/"&&w==="/"){for(;a<o&&e[a]!==`
`;)a++;continue}if(p==="/"&&w==="*"){let b=e.indexOf("*/",a+2);if(b===-1){t.push({from:a,to:a+2,severity:"error",message:"Unterminated comment",code:"syntax"});break}a=b+2;continue}if(p==='"'||p==="'"){let b=a++;for(;a<o&&e[a]!==p&&e[a]!==`
`;)a+=e[a]==="\\"?2:1;e[a]!==p&&t.push({from:b,to:b+1,severity:"error",message:`Unterminated ${p==='"'?"string":"character"} literal`,code:"syntax"}),a++;continue}if(p==="("||p==="["||p==="{")n.push({c:p,i:a});else if(r[p]){let b=n.pop();(!b||b.c!==r[p])&&t.push({from:a,to:a+1,severity:"error",message:`Unmatched '${p}'`,code:"syntax"})}a++}for(let p of n)t.push({from:p.i,to:p.i+1,severity:"error",message:`Unclosed '${p.c}'`,code:"syntax"});let c=/\b(gets|strcpy|strcat|sprintf)\s*\(/g,d;for(;d=c.exec(e);){let p=d[1]==="gets";t.push({from:d.index,to:d.index+d[1].length,severity:p?"error":"warning",message:p?"gets() was removed in C11; use fgets()":`${d[1]}() does not check bounds`,code:"unsafe-call"})}return t.sort((p,w)=>p.from-w.from)}var Sr=["auto","break","case","const","continue","default","do","else","enum","extern","for","goto","if","inline","register","restrict","return","sizeof","static","struct","switch","typedef","union","volatile","while","_Alignas","_Alignof","_Atomic","_Generic","_Noreturn","_Static_assert","_Thread_local","constexpr","typeof","nullptr","static_assert","thread_local","alignas","alignof"],Tr=["void","char","short","int","long","float","double","signed","unsigned","_Bool","_Complex","_Imaginary","bool","size_t","ssize_t","ptrdiff_t","int8_t","int16_t","int32_t","int64_t","uint8_t","uint16_t","uint32_t","uint64_t","intptr_t","uintptr_t","off_t","pid_t","FILE"],Ir=["include","define","undef","if","ifdef","ifndef","elif","elifdef","elifndef","else","endif","error","warning","pragma","line","embed"],st=[{label:"main",detail:"int main(void)",body:`int main(void) {
	\${}
	return 0;
}`},{label:"maina",detail:"int main(argc, argv)",body:`int main(int argc, char *argv[]) {
	\${}
	return 0;
}`},{label:"inc",detail:"#include <...>",body:"#include <${stdio.h}>"},{label:"incl",detail:'#include "..."',body:'#include "${header.h}"'},{label:"stdhdr",detail:"common standard headers",body:`#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
`},{label:"def",detail:"#define",body:"#define ${NAME} ${value}"},{label:"defm",detail:"function-like macro",body:"#define ${NAME}(${x}) (${x})"},{label:"ifdef",detail:"#ifdef ... #endif",body:"#ifdef ${MACRO}\n${}\n#endif /* ${MACRO} */"},{label:"ifndef",detail:"#ifndef ... #endif",body:"#ifndef ${MACRO}\n${}\n#endif /* ${MACRO} */"},{label:"guard",detail:"include guard",body:`#ifndef \${HEADER_H}
#define \${HEADER_H}

\${}

#endif /* \${HEADER_H} */`},{label:"once",detail:"#pragma once",body:`#pragma once
`},{label:"cpp",detail:'extern "C" wrapper for headers',body:`#ifdef __cplusplus
extern "C" {
#endif

\${}

#ifdef __cplusplus
}
#endif`},{label:"if",detail:"if",body:"if (${cond}) {\n	${}\n}"},{label:"ife",detail:"if / else",body:`if (\${cond}) {
	\${}
} else {
	\${}
}`},{label:"elif",detail:"else if",body:"else if (${cond}) {\n	${}\n}"},{label:"for",detail:"for (int i...)",body:"for (${size_t} ${i} = 0; ${i} < ${n}; ${i}++) {\n	${}\n}"},{label:"forr",detail:"reverse for loop",body:"for (${int} ${i} = ${n} - 1; ${i} >= 0; ${i}--) {\n	${}\n}"},{label:"fore",detail:"for over array",body:"for (size_t ${i} = 0; ${i} < sizeof(${arr}) / sizeof((${arr})[0]); ${i}++) {\n	${}\n}"},{label:"while",detail:"while",body:"while (${cond}) {\n	${}\n}"},{label:"do",detail:"do ... while",body:"do {\n	${}\n} while (${cond});"},{label:"switch",detail:"switch",body:`switch (\${expr}) {
case \${value}:
	\${}
	break;
default:
	break;
}`},{label:"case",detail:"case ...: break;",body:"case ${value}:\n	${}\n	break;"},{label:"fn",detail:"function",body:"${void} ${name}(${void}) {\n	${}\n}"},{label:"sfn",detail:"static function",body:"static ${void} ${name}(${void}) {\n	${}\n}"},{label:"struct",detail:"struct",body:"struct ${name} {\n	${int} ${field};\n};"},{label:"tdstruct",detail:"typedef struct",body:"typedef struct ${name} {\n	${int} ${field};\n} ${name}_t;"},{label:"enum",detail:"enum",body:"enum ${name} {\n	${NAME_A},\n	${NAME_B},\n};"},{label:"tdenum",detail:"typedef enum",body:"typedef enum {\n	${NAME_A},\n	${NAME_B},\n} ${name}_t;"},{label:"union",detail:"union",body:"union ${name} {\n	${int} ${a};\n	${float} ${b};\n};"},{label:"tdfn",detail:"function pointer typedef",body:"typedef ${int} (*${name}_fn)(${void});"},{label:"arr",detail:"array with length",body:"${int} ${name}[${N}] = {${0}};"},{label:"sassert",detail:"_Static_assert",body:'_Static_assert(${cond}, "${message}");'},{label:"pf",detail:"printf",body:'printf("${%d}\\n", ${value});'},{label:"epf",detail:"fprintf(stderr, ...)",body:'fprintf(stderr, "${message}\\n"${});'},{label:"sc",detail:"scanf with check",body:`if (scanf("\${%d}", &\${var}) != 1) {
	fprintf(stderr, "invalid input\\n");
	return 1;
}`},{label:"readline",detail:"read a line with fgets",body:"char ${line}[${256}];\nif (fgets(${line}, sizeof ${line}, ${stdin}) == NULL) {\n	${}\n}\n${line}[strcspn(${line}, \"\\n\")] = '\\0';"},{label:"getlineloop",detail:"POSIX getline loop",body:"char *${line} = NULL;\nsize_t ${cap} = 0;\nssize_t ${len};\nwhile ((${len} = getline(&${line}, &${cap}, ${stdin})) != -1) {\n	${}\n}\nfree(${line});"},{label:"freadfile",detail:"open, read, close file",body:`FILE *\${fp} = fopen(\${"path"}, "r");
if (\${fp} == NULL) {
	perror("fopen");
	return 1;
}
\${}
fclose(\${fp});`},{label:"fwritefile",detail:"open for writing",body:'FILE *${fp} = fopen(${"path"}, "w");\nif (${fp} == NULL) {\n	perror("fopen");\n	return 1;\n}\nfprintf(${fp}, "${}");\nfclose(${fp});'},{label:"slurp",detail:"read whole file into memory",body:`static char *read_file(const char *path, size_t *out_len) {
	FILE *f = fopen(path, "rb");
	if (!f) return NULL;
	fseek(f, 0, SEEK_END);
	long n = ftell(f);
	rewind(f);
	char *buf = malloc((size_t)n + 1);
	if (!buf) { fclose(f); return NULL; }
	size_t got = fread(buf, 1, (size_t)n, f);
	buf[got] = '\\0';
	fclose(f);
	if (out_len) *out_len = got;
	return buf;
}`},{label:"mallocchk",detail:"malloc with NULL check",body:'${int} *${p} = malloc(${n} * sizeof *${p});\nif (${p} == NULL) {\n	perror("malloc");\n	return ${1};\n}\n${}'},{label:"callocchk",detail:"calloc with NULL check",body:'${int} *${p} = calloc(${n}, sizeof *${p});\nif (${p} == NULL) {\n	perror("calloc");\n	return ${1};\n}\n${}'},{label:"reallocsafe",detail:"safe realloc",body:"${int} *${tmp} = realloc(${p}, ${n} * sizeof *${p});\nif (${tmp} == NULL) {\n	free(${p});\n	return ${1};\n}\n${p} = ${tmp};"},{label:"freen",detail:"free and NULL",body:"free(${p});\n${p} = NULL;"},{label:"memzero",detail:"memset to zero",body:"memset(${p}, 0, sizeof *${p});"},{label:"swap",detail:"swap two variables",body:"${int} ${tmp} = ${a};\n${a} = ${b};\n${b} = ${tmp};"},{label:"countof",detail:"array length macro",body:"#define COUNT_OF(a) (sizeof(a) / sizeof((a)[0]))"},{label:"minmax",detail:"MIN / MAX macros",body:`#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))`},{label:"perr",detail:"perror and return",body:'perror("${msg}");\nreturn ${1};'},{label:"errnomsg",detail:"report errno",body:'fprintf(stderr, "${msg}: %s\\n", strerror(errno));'},{label:"assertx",detail:"assert",body:"assert(${cond});"},{label:"goto",detail:"goto cleanup pattern",body:`int rc = -1;
\${}

cleanup:
	return rc;`},{label:"qsortcmp",detail:"qsort comparator",body:"static int cmp_${int}(const void *a, const void *b) {\n	const ${int} x = *(const ${int} *)a;\n	const ${int} y = *(const ${int} *)b;\n	return (x > y) - (x < y);\n}"},{label:"bsearchcall",detail:"bsearch call",body:"${int} *${hit} = bsearch(&${key}, ${arr}, ${n}, sizeof ${arr}[0], ${cmp});"},{label:"strtolchk",detail:"checked strtol",body:`char *end;
errno = 0;
long \${v} = strtol(\${str}, &end, 10);
if (errno != 0 || end == \${str} || *end != '\\0') {
	fprintf(stderr, "invalid number: %s\\n", \${str});
	return 1;
}`},{label:"timeit",detail:"measure elapsed time",body:`struct timespec t0, t1;
clock_gettime(CLOCK_MONOTONIC, &t0);
\${}
clock_gettime(CLOCK_MONOTONIC, &t1);
double ms = (t1.tv_sec - t0.tv_sec) * 1e3 + (t1.tv_nsec - t0.tv_nsec) / 1e6;
printf("elapsed: %.3f ms\\n", ms);`},{label:"getoptloop",detail:"getopt option loop",body:`int opt;
while ((opt = getopt(argc, argv, "\${ho:v}")) != -1) {
	switch (opt) {
	case 'h':
		\${}
		break;
	default:
		fprintf(stderr, "usage: %s [-h]\\n", argv[0]);
		return 1;
	}
}`},{label:"sigint",detail:"SIGINT handler",body:`static volatile sig_atomic_t \${stop} = 0;
static void on_signal(int sig) { (void)sig; \${stop} = 1; }
/* in main: */
signal(SIGINT, on_signal);`},{label:"pthread",detail:"create and join a thread",body:`static void *\${worker}(void *arg) {
	\${}
	return NULL;
}

pthread_t \${tid};
pthread_create(&\${tid}, NULL, \${worker}, NULL);
pthread_join(\${tid}, NULL);`},{label:"mutex",detail:"lock / unlock",body:"pthread_mutex_lock(&${mu});\n${}\npthread_mutex_unlock(&${mu});"},{label:"doc",detail:"Doxygen function comment",body:`/**
 * @brief \${Summary.}
 *
 * @param \${name} \${description}
 * @return \${description}
 */`},{label:"fileh",detail:"file header comment",body:`/**
 * @file \${file.c}
 * @brief \${Summary.}
 */`},{label:"todo",detail:"TODO comment",body:"/* TODO: ${} */"}];function Ea(e){let t=e.indexOf("("),n=e.lastIndexOf(")");if(t<0||n<t)return null;let r=e.slice(t+1,n).trim();if(r===""||r==="void")return[];let a=[],o=0,c="";for(let p of r)p==="("||p==="["?o++:(p===")"||p==="]")&&o--,p===","&&o===0?(a.push(c),c=""):c+=p;a.push(c);let d=[];for(let p of a){let w=p.trim();if(w==="...")continue;let b=/\(\s*\*\s*(\w+)\s*\)/.exec(w);if(b){d.push(b[1]);continue}let T=/(\w+)\s*(?:\[[^\]]*\])*\s*$/.exec(w),x=w.replace(/[*\s]+/g," ").trim().split(" ");d.push(T&&x.length>1?T[1]:"arg")}return d}function on(e,t){let n=Ea(t);return n?n.length===0?`${e}()`:`${e}(${n.map(r=>`\${${r}}`).join(", ")})`:`${e}(\${})`}function Mr(){let e=[];for(let t of Sr)e.push({label:t,type:"keyword",boost:-2});for(let t of Tr)e.push({label:t,type:"type",boost:-1});for(let t of ce.values())t.kind==="function"?e.push({label:t.name,type:"function",detail:`<${t.headers[0]}>`,info:`${t.sig}

${t.doc}`,template:on(t.name,t.sig),boost:0}):t.kind==="type"?e.push({label:t.name,type:"type",detail:`<${t.headers[0]}>`,info:t.doc,boost:-1}):e.push({label:t.name,type:"constant",detail:`<${t.headers[0]}>`,info:t.doc,boost:-1});return e}function xr(){return st.map(e=>({label:e.label,type:"text",detail:e.detail,template:e.body,boost:3,isSnippet:!0}))}var Nr=()=>ke.map(e=>({label:e,type:"namespace",boost:0})),Fr=()=>Ir.map(e=>({label:e,type:"keyword"})),Sa={function:"function",prototype:"function",variable:"variable",parameter:"variable",typedef:"type",macro:"constant",enumerator:"enum",struct:"type",union:"type",enum:"type",field:"property"},He={text:null,value:null};function Cr(e,t){if(He.text!==e){let a=ve(e,o=>pe(o));He={text:e,value:a||[]}}let n=[],r=new Set;for(let a of He.value){if(a.kind==="field"||!(t>=a.scopeFrom&&t<=a.scopeTo&&(a.global||a.identFrom<=t))||r.has(a.name))continue;r.add(a.name);let c=a.kind==="function"||a.kind==="prototype";n.push({label:a.name,type:Sa[a.kind]||"variable",detail:c?a.detail:a.kind,template:c?on(a.name,a.detail||""):void 0,boost:a.global?8:12})}return n}function kr(e){if(He.text!==e){let t=ve(e,n=>pe(n));He={text:e,value:t||[]}}return fr(He.value).map(t=>({label:t,type:"property",boost:5}))}var Ta="acode-c-toolkit";function at(e,t){return t.lintEnabled?e.length>4e5?[]:Oe()?xt(e,{std:t.std,semantic:t.semanticLint,unused:t.unusedHints,hints:t.infoHints}):Er(e):[]}function Ar(e,t){let n=[],r=e.get("EditorState"),a=e.get("EditorView"),o=e.get("StateField"),c=null;if(o&&(c=o.define({create:()=>Ta,update:b=>b}),n.push(c)),r){n.push(r.languageData.of(()=>[{commentTokens:{line:"//",block:{open:"/*",close:"*/"}}}]));let b=xa(e,t);b&&n.push(r.languageData.of(()=>[{autocomplete:b}]))}let d=e.get("linter"),p=e.get("lintGutter");d?(n.push(d(b=>{if(!t.isAlive())return[];let T=t.getSettings(),x=b.state.doc.toString();return at(x,T).map(z=>Ia(z,x.length,T))},{delay:500})),p&&t.getSettings().lintGutter&&n.push(p())):o&&a&&e.get("Decoration")&&e.get("StateEffect")&&e.get("ViewPlugin")&&n.push(...Ma(e,t));let w=e.get("hoverTooltip");return w&&n.push(w((b,T)=>{if(!t.isAlive()||!t.getSettings().hoverDocs)return null;let x=b.state.wordAt(T);if(!x)return null;let z=b.state.sliceDoc(x.from,x.to),B=ln(b.state.doc.toString(),z,T);return B?{pos:x.from,end:x.to,above:!0,create(){let N=document.createElement("div");N.className="cm-c-doc";let k=document.createElement("code");if(k.textContent=B.sig,N.appendChild(k),B.doc){let A=document.createElement("div");A.textContent=B.doc,N.appendChild(A)}if(B.header){let A=document.createElement("div");A.className="cm-c-doc-hdr",A.textContent=B.header,N.appendChild(A)}return{dom:N}}}:null},{hoverTime:350})),a&&n.push(a.baseTheme({".cm-c-doc":{padding:"6px 10px",maxWidth:"min(88vw, 520px)",fontSize:"0.92em",lineHeight:"1.4",whiteSpace:"pre-wrap"},".cm-c-doc code":{display:"block",fontFamily:"monospace",fontWeight:"600",marginBottom:"3px"},".cm-c-doc-hdr":{opacity:"0.65",marginTop:"3px",fontSize:"0.9em"},".cm-c-squiggle-error":{textDecoration:"underline wavy #e5484d",textUnderlineOffset:"3px"},".cm-c-squiggle-warning":{textDecoration:"underline wavy #d9a21b",textUnderlineOffset:"3px"},".cm-c-squiggle-info":{textDecoration:"underline dotted #7a8aa0",textUnderlineOffset:"3px"}})),{extensions:n,marker:c}}function Ia(e,t,n){let r={from:Math.min(e.from,t),to:Math.min(Math.max(e.to,e.from+1),t),severity:e.severity,message:e.message,source:"C"};return e.fix&&(r.actions=[{name:e.fix.label,apply(a,o){let c=a.state.doc.toString(),d=at(c,n).find(w=>w.code===e.code&&w.message===e.message&&w.fix&&Math.abs(w.from-o)<2),p=d&&d.fix||null;p&&a.dispatch({changes:{from:p.from,to:p.to,insert:p.insert}})}}]),r}function Ma(e,t){let n=e.get("StateField"),r=e.get("StateEffect"),a=e.get("Decoration"),o=e.get("EditorView"),c=e.get("ViewPlugin"),d=r.define(),p=n.define({create:()=>a.none,update(b,T){b=b.map(T.changes);for(let x of T.effects)x.is(d)&&(b=x.value);return b},provide:b=>o.decorations.from(b)}),w=c.fromClass(class{constructor(b){this.view=b,this.timer=null,this.schedule()}update(b){b.docChanged&&this.schedule()}schedule(){clearTimeout(this.timer),this.timer=setTimeout(()=>this.run(),600)}run(){if(!t.isAlive())return;let b=this.view.state.doc.toString(),T=at(b,t.getSettings()).filter(x=>x.severity!=="info"||t.getSettings().infoHints).map(x=>a.mark({class:`cm-c-squiggle-${x.severity}`,attributes:{title:x.message}}).range(Math.min(x.from,b.length),Math.min(Math.max(x.to,x.from+1),b.length))).sort((x,z)=>x.from-z.from);this.view.dispatch({effects:d.of(a.set(T,!0))})}destroy(){clearTimeout(this.timer)}});return[p,w]}function xa(e,t){let n=e.get("snippetCompletion"),r=e.get("syntaxTree"),a=Mr(),o=xr(),c=Nr(),d=Fr(),p=B=>{let N={label:B.label,type:B.type,detail:B.detail,info:B.info,boost:B.boost};return B.template?n?n(B.template,N):{...N,apply:B.template.replace(/\$\{([^}]*)\}/g,"$1").replace(/\t/g,"  ")}:N},w=a.map(p),b=o.map(p),T=c.map(p),x=d.map(p),z=(B,N)=>{if(!r)return!1;try{let k=r(B).resolveInner(N,-1);return/comment|string/i.test(k.name)||/comment|string/i.test(k.parent?k.parent.name:"")}catch{return!1}};return B=>{if(!t.isAlive())return null;let N=t.getSettings();if(!N.completion)return null;let{state:k,pos:A}=B,M=k.doc.lineAt(A),L=M.text.slice(0,A-M.from),O=/^\s*#\s*include\s*([<"])([\w/.\-]*)$/.exec(L);if(O){let h=O[1]==="<"?">":'"',u=k.sliceDoc(A,A+1);return{from:A-O[2].length,options:T.map(m=>({...m,apply:u===h?m.label:m.label+h})),validFor:/^[\w/.\-]*$/}}let se=/^\s*#\s*(\w*)$/.exec(L);if(se)return{from:A-se[1].length,options:x,validFor:/^\w*$/};if(z(k,A))return null;let X=/(?:->|(?<![\d.])\.)(\w*)$/.exec(L);if(X){let h=kr(k.doc.toString());return h.length?{from:A-X[1].length,options:h,validFor:/^\w*$/}:null}let K=B.matchBefore(/\w+/);if(!K&&!B.explicit||K&&K.to-K.from<(N.minChars||2)&&!B.explicit)return null;let le=K?K.from:A,fe=k.doc.toString(),R=Cr(fe,A).map(p);return{from:le,options:[...R,...b,...w],validFor:/^\w*$/}}}function ln(e,t,n){let r=ve(e,o=>{let c=pe(o),d=null;for(let w of c)w.name!==t||w.kind==="field"||!w.global&&(n<w.scopeFrom||n>w.scopeTo)||(!d||!w.global&&d.global||w.kind==="function"&&d.kind!=="function")&&(d=w);if(!d)return null;let p=d.detail||`${d.kind} ${d.name}`;return{sig:d.kind==="variable"||d.kind==="parameter"?`${d.kind}: ${d.name}`:p,doc:"",header:`defined at line ${d.row+1}`}});if(r)return r;let a=ce.get(t);return a?{sig:a.sig,doc:a.doc,header:`#include <${a.headers[0]}>`}:null}function Rr(e,t){let n=()=>e(),r=()=>n()&&n().editor||null,a=c=>!!(c&&c.state&&typeof c.dispatch=="function"&&c.state.doc),o={view:r,isCM:()=>a(r()),fileName(){let c=n()&&n().activeFile;return c&&c.name||""},fileUri(){let c=n()&&n().activeFile;return c&&c.uri||""},isCFile(){return/\.(c|h)$/i.test(o.fileName())},text(){let c=r();return c?a(c)?c.state.doc.toString():c.getValue():""},cursor(){let c=r();if(!c)return 0;if(a(c))return c.state.selection.main.head;let d=c.getCursorPosition();return c.session.doc.positionToIndex(d)},selection(){let c=r();if(!c)return{from:0,to:0};if(a(c)){let p=c.state.selection.main;return{from:p.from,to:p.to}}let d=c.getSelectionRange();return{from:c.session.doc.positionToIndex(d.start),to:c.session.doc.positionToIndex(d.end)}},lineOf(c){let d=r();return a(d)?d.state.doc.lineAt(c).number:d.session.doc.indexToPosition(c).row+1},lineStart(c){let d=r();return a(d)?d.state.doc.line(Math.max(1,Math.min(c,d.state.doc.lines))).from:d.session.doc.positionToIndex({row:c-1,column:0})},wordAtCursor(){if(!r())return null;let d=o.text(),{from:p,to:w}=o.selection();if(p!==w)return d.slice(p,w).trim()||null;let b=p,T=b,x=b;for(;T>0&&/\w/.test(d[T-1]);)T--;for(;x<d.length&&/\w/.test(d[x]);)x++;return T===x?null:d.slice(T,x)},goto(c,d){let p=r();if(p)if(a(p)){let w=t&&t.get("EditorView"),b={selection:d?{anchor:d.from,head:d.to}:{anchor:c}};w&&(b.effects=w.scrollIntoView(c,{y:"center"})),p.dispatch(b),p.focus()}else{let w=p.session.doc.indexToPosition(c);p.gotoLine(w.row+1,w.column,!0),p.focus()}},change(c,d){let p=r();if(!(!p||!c.length))if(a(p)){let w={changes:c};d!=null&&(w.selection={anchor:d}),p.dispatch(w)}else{let w=[...c].sort((b,T)=>T.from-b.from);for(let b of w){let T=p.session.doc;T.replace({start:T.indexToPosition(b.from),end:T.indexToPosition(b.to)},b.insert)}}},replaceAll(c){let d=o.text();if(d===c)return!1;let p=0,w=Math.min(d.length,c.length);for(;p<w&&d.charCodeAt(p)===c.charCodeAt(p);)p++;let b=0;for(;b<w-p&&d.charCodeAt(d.length-1-b)===c.charCodeAt(c.length-1-b);)b++;return o.change([{from:p,to:d.length-b,insert:c.slice(p,c.length-b)}]),!0},insert(c){let{from:d,to:p}=o.selection();o.change([{from:d,to:p,insert:c}],d+c.length)},insertSnippet(c){let d=r(),p=t&&t.get("snippet");if(a(d)&&p){let{from:w,to:b}=o.selection();return p(c)(d,{label:"snippet"},w,b),d.focus(),!0}return o.insert(c.replace(/\$\{([^}]*)\}/g,"$1").replace(/\t/g,"    ")),!1},focus(){let c=r();c&&c.focus&&c.focus()}};return o}function $r(e){let t=n=>{try{return e.require(n)}catch{return null}};return{toast(n,r=2500){let a=t("toast");typeof a=="function"?a(n,r):console.log("[C Toolkit]",n)},async select(n,r,a){let o=t("select");if(typeof o=="function")try{let w=await o(n,r,{textTransform:!1,...a||{}});return w===null?void 0:w}catch{return}let c=r.map((w,b)=>`${b+1}. ${Array.isArray(w)?w[1]:w}`).join(`
`),d=parseInt(window.prompt(`${n}
${c}`,"1")||"",10),p=r[d-1];return p===void 0?void 0:Array.isArray(p)?p[0]:p},async prompt(n,r="",a="text",o){let c=t("prompt");if(typeof c=="function")try{let p=await c(n,r,a,o);return p==null?void 0:String(p)}catch{return}let d=window.prompt(n,r);return d===null?void 0:d},async alert(n,r){let a=t("alert");if(typeof a=="function")try{await a(n,r);return}catch{}window.alert(`${n}

${r}`)},async confirm(n,r){let a=t("confirm");if(typeof a=="function")try{return!!await a(n,r)}catch{return!1}return window.confirm(`${n}

${r}`)},async copy(n){try{if(navigator.clipboard&&navigator.clipboard.writeText)return await navigator.clipboard.writeText(n),!0}catch{}let r=window.cordova&&window.cordova.plugins&&window.cordova.plugins.clipboard;return r&&r.copy?(r.copy(n),!0):!1}}}var Lr="acode-c-toolkit.settings.v1",Pr={...Mt,useProjectConfig:!0,lintEnabled:!0,semanticLint:!0,unusedHints:!0,infoHints:!0,lintGutter:!0,std:"c17",completion:!0,hoverDocs:!0,minChars:2};function Or(){try{let e=localStorage.getItem(Lr);if(e)return{...Pr,...JSON.parse(e)}}catch{}return{...Pr}}function cn(e){try{localStorage.setItem(Lr,JSON.stringify(e))}catch{}}var un=[{id:"hello",title:"Hello, world",group:"Basics",code:`#include <stdio.h>

int main(void) {
    printf("Hello, world!\\n");
    return 0;
}
`},{id:"args",title:"Command-line arguments (getopt)",group:"Basics",code:`#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static void usage(const char *prog) {
    fprintf(stderr, "usage: %s [-v] [-n count] file...\\n", prog);
}

int main(int argc, char *argv[]) {
    int verbose = 0;
    long count = 1;
    int opt;

    while ((opt = getopt(argc, argv, "vn:h")) != -1) {
        switch (opt) {
        case 'v':
            verbose = 1;
            break;
        case 'n':
            count = strtol(optarg, NULL, 10);
            break;
        case 'h':
        default:
            usage(argv[0]);
            return opt == 'h' ? 0 : 2;
        }
    }

    for (int i = optind; i < argc; i++) {
        if (verbose) printf("processing %s (x%ld)\\n", argv[i], count);
    }
    return 0;
}
`},{id:"fizzbuzz",title:"FizzBuzz",group:"Basics",code:`#include <stdio.h>

int main(void) {
    for (int i = 1; i <= 100; i++) {
        if (i % 15 == 0)
            puts("FizzBuzz");
        else if (i % 3 == 0)
            puts("Fizz");
        else if (i % 5 == 0)
            puts("Buzz");
        else
            printf("%d\\n", i);
    }
    return 0;
}
`},{id:"vector",title:"Dynamic array (vector of int)",group:"Data structures",code:`#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *data;
    size_t len;
    size_t cap;
} Vec;

static void vec_init(Vec *v) {
    v->data = NULL;
    v->len = 0;
    v->cap = 0;
}

static int vec_push(Vec *v, int value) {
    if (v->len == v->cap) {
        size_t new_cap = v->cap ? v->cap * 2 : 8;
        int *tmp = realloc(v->data, new_cap * sizeof *tmp);
        if (tmp == NULL) return -1;
        v->data = tmp;
        v->cap = new_cap;
    }
    v->data[v->len++] = value;
    return 0;
}

static void vec_free(Vec *v) {
    free(v->data);
    vec_init(v);
}

int main(void) {
    Vec v;
    vec_init(&v);
    for (int i = 0; i < 20; i++) {
        if (vec_push(&v, i * i) != 0) {
            perror("vec_push");
            vec_free(&v);
            return 1;
        }
    }
    for (size_t i = 0; i < v.len; i++) printf("%d ", v.data[i]);
    putchar('\\n');
    vec_free(&v);
    return 0;
}
`},{id:"linkedlist",title:"Singly linked list",group:"Data structures",code:`#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int value;
    struct Node *next;
} Node;

static Node *push_front(Node *head, int value) {
    Node *n = malloc(sizeof *n);
    if (n == NULL) return head;
    n->value = value;
    n->next = head;
    return n;
}

static Node *reverse(Node *head) {
    Node *prev = NULL;
    while (head != NULL) {
        Node *next = head->next;
        head->next = prev;
        prev = head;
        head = next;
    }
    return prev;
}

static void print_list(const Node *n) {
    for (; n != NULL; n = n->next) printf("%d -> ", n->value);
    puts("NULL");
}

static void free_list(Node *n) {
    while (n != NULL) {
        Node *next = n->next;
        free(n);
        n = next;
    }
}

int main(void) {
    Node *list = NULL;
    for (int i = 1; i <= 5; i++) list = push_front(list, i);
    print_list(list);
    list = reverse(list);
    print_list(list);
    free_list(list);
    return 0;
}
`},{id:"stack",title:"Fixed-size stack and queue (ring buffer)",group:"Data structures",code:`#include <stdbool.h>
#include <stdio.h>

#define CAPACITY 8

typedef struct {
    int items[CAPACITY];
    size_t head;
    size_t count;
} Queue;

static bool queue_push(Queue *q, int v) {
    if (q->count == CAPACITY) return false;
    q->items[(q->head + q->count) % CAPACITY] = v;
    q->count++;
    return true;
}

static bool queue_pop(Queue *q, int *out) {
    if (q->count == 0) return false;
    *out = q->items[q->head];
    q->head = (q->head + 1) % CAPACITY;
    q->count--;
    return true;
}

int main(void) {
    Queue q = {0};
    for (int i = 0; i < 10; i++) {
        if (!queue_push(&q, i)) printf("full at %d\\n", i);
    }
    int v;
    while (queue_pop(&q, &v)) printf("%d ", v);
    putchar('\\n');
    return 0;
}
`},{id:"hashtable",title:"Hash table (string to int, open addressing)",group:"Data structures",code:`#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char *key;
    int value;
    int used;
} Entry;

typedef struct {
    Entry *entries;
    size_t cap;
    size_t len;
} Table;

/* FNV-1a */
static uint64_t hash_str(const char *s) {
    uint64_t h = 1469598103934665603ULL;
    for (; *s; s++) {
        h ^= (unsigned char)*s;
        h *= 1099511628211ULL;
    }
    return h;
}

static int table_init(Table *t, size_t cap) {
    t->entries = calloc(cap, sizeof *t->entries);
    t->cap = cap;
    t->len = 0;
    return t->entries ? 0 : -1;
}

static int table_set(Table *t, const char *key, int value) {
    if (t->len * 2 >= t->cap) return -1; /* keep load factor under 50% */
    size_t i = hash_str(key) % t->cap;
    while (t->entries[i].used) {
        if (strcmp(t->entries[i].key, key) == 0) {
            t->entries[i].value = value;
            return 0;
        }
        i = (i + 1) % t->cap;
    }
    t->entries[i].key = strdup(key);
    if (t->entries[i].key == NULL) return -1;
    t->entries[i].value = value;
    t->entries[i].used = 1;
    t->len++;
    return 0;
}

static int *table_get(Table *t, const char *key) {
    size_t i = hash_str(key) % t->cap;
    while (t->entries[i].used) {
        if (strcmp(t->entries[i].key, key) == 0) return &t->entries[i].value;
        i = (i + 1) % t->cap;
    }
    return NULL;
}

static void table_free(Table *t) {
    for (size_t i = 0; i < t->cap; i++) free(t->entries[i].key);
    free(t->entries);
}

int main(void) {
    Table t;
    if (table_init(&t, 64) != 0) return 1;
    table_set(&t, "apple", 3);
    table_set(&t, "pear", 5);
    int *v = table_get(&t, "pear");
    printf("pear = %d\\n", v ? *v : -1);
    table_free(&t);
    return 0;
}
`},{id:"bst",title:"Binary search tree",group:"Data structures",code:`#include <stdio.h>
#include <stdlib.h>

typedef struct Tree {
    int key;
    struct Tree *left;
    struct Tree *right;
} Tree;

static Tree *insert(Tree *t, int key) {
    if (t == NULL) {
        Tree *n = calloc(1, sizeof *n);
        if (n != NULL) n->key = key;
        return n;
    }
    if (key < t->key)
        t->left = insert(t->left, key);
    else if (key > t->key)
        t->right = insert(t->right, key);
    return t;
}

static void inorder(const Tree *t) {
    if (t == NULL) return;
    inorder(t->left);
    printf("%d ", t->key);
    inorder(t->right);
}

static void destroy(Tree *t) {
    if (t == NULL) return;
    destroy(t->left);
    destroy(t->right);
    free(t);
}

int main(void) {
    Tree *root = NULL;
    int keys[] = {50, 30, 70, 20, 40, 60, 80};
    for (size_t i = 0; i < sizeof keys / sizeof keys[0]; i++) root = insert(root, keys[i]);
    inorder(root);
    putchar('\\n');
    destroy(root);
    return 0;
}
`},{id:"sorts",title:"Sorting: quicksort and qsort()",group:"Algorithms",code:`#include <stdio.h>
#include <stdlib.h>

static void swap(int *a, int *b) {
    int t = *a;
    *a = *b;
    *b = t;
}

static void quicksort(int *a, int lo, int hi) {
    if (lo >= hi) return;
    int pivot = a[lo + (hi - lo) / 2];
    int i = lo, j = hi;
    while (i <= j) {
        while (a[i] < pivot) i++;
        while (a[j] > pivot) j--;
        if (i <= j) swap(&a[i++], &a[j--]);
    }
    quicksort(a, lo, j);
    quicksort(a, i, hi);
}

static int cmp_int(const void *a, const void *b) {
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

int main(void) {
    int a[] = {9, 4, 7, 1, 8, 2, 6, 3, 5, 0};
    int n = (int)(sizeof a / sizeof a[0]);
    quicksort(a, 0, n - 1);
    for (int i = 0; i < n; i++) printf("%d ", a[i]);
    putchar('\\n');

    int b[] = {3, 1, 2};
    qsort(b, 3, sizeof b[0], cmp_int);
    printf("%d %d %d\\n", b[0], b[1], b[2]);
    return 0;
}
`},{id:"primes",title:"Sieve of Eratosthenes",group:"Algorithms",code:`#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    const size_t n = 100;
    bool *composite = calloc(n + 1, sizeof *composite);
    if (composite == NULL) return 1;
    for (size_t i = 2; i * i <= n; i++) {
        if (composite[i]) continue;
        for (size_t j = i * i; j <= n; j += i) composite[j] = true;
    }
    for (size_t i = 2; i <= n; i++) {
        if (!composite[i]) printf("%zu ", i);
    }
    putchar('\\n');
    free(composite);
    return 0;
}
`},{id:"strings",title:"String utilities (reverse, trim, split)",group:"Algorithms",code:`#include <ctype.h>
#include <stdio.h>
#include <string.h>

static void reverse(char *s) {
    for (size_t i = 0, j = strlen(s); i + 1 < j; i++, j--) {
        char t = s[i];
        s[i] = s[j - 1];
        s[j - 1] = t;
    }
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) end--;
    *end = '\\0';
    return s;
}

int main(void) {
    char buf[] = "  hello, c world  ";
    char *t = trim(buf);
    printf("[%s]\\n", t);
    reverse(t);
    printf("[%s]\\n", t);

    char csv[] = "a,b,c";
    char *save = NULL;
    for (char *tok = strtok_r(csv, ",", &save); tok; tok = strtok_r(NULL, ",", &save))
        printf("token: %s\\n", tok);
    return 0;
}
`},{id:"filecopy",title:"Copy a file",group:"Files & system",code:`#include <stdio.h>

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "usage: %s src dst\\n", argv[0]);
        return 2;
    }
    FILE *in = fopen(argv[1], "rb");
    if (in == NULL) {
        perror(argv[1]);
        return 1;
    }
    FILE *out = fopen(argv[2], "wb");
    if (out == NULL) {
        perror(argv[2]);
        fclose(in);
        return 1;
    }
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, in)) > 0) {
        if (fwrite(buf, 1, n, out) != n) {
            perror("write");
            fclose(in);
            fclose(out);
            return 1;
        }
    }
    fclose(in);
    return fclose(out) == 0 ? 0 : 1;
}
`},{id:"wc",title:"Word count (wc clone)",group:"Files & system",code:`#include <ctype.h>
#include <stdio.h>

int main(void) {
    unsigned long lines = 0, words = 0, chars = 0;
    int c, in_word = 0;
    while ((c = getchar()) != EOF) {
        chars++;
        if (c == '\\n') lines++;
        if (isspace(c)) {
            in_word = 0;
        } else if (!in_word) {
            in_word = 1;
            words++;
        }
    }
    printf("%lu %lu %lu\\n", lines, words, chars);
    return 0;
}
`},{id:"fork",title:"fork / exec / wait",group:"Files & system",code:`#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void) {
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return 1;
    }
    if (pid == 0) {
        execlp("echo", "echo", "hello from child", (char *)NULL);
        perror("execlp");
        _exit(127);
    }
    int status;
    if (waitpid(pid, &status, 0) < 0) {
        perror("waitpid");
        return 1;
    }
    if (WIFEXITED(status)) printf("child exited with %d\\n", WEXITSTATUS(status));
    return 0;
}
`},{id:"threads",title:"Threads with a mutex (pthread)",group:"Files & system",code:`#include <pthread.h>
#include <stdio.h>

#define THREADS 4
#define ITERATIONS 100000

static long counter = 0;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

static void *worker(void *arg) {
    (void)arg;
    for (int i = 0; i < ITERATIONS; i++) {
        pthread_mutex_lock(&lock);
        counter++;
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

int main(void) {
    pthread_t tid[THREADS];
    for (int i = 0; i < THREADS; i++) pthread_create(&tid[i], NULL, worker, NULL);
    for (int i = 0; i < THREADS; i++) pthread_join(tid[i], NULL);
    printf("counter = %ld (expected %d)\\n", counter, THREADS * ITERATIONS);
    return 0;
}
`},{id:"tcpecho",title:"TCP echo server",group:"Files & system",code:`#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

int main(void) {
    int srv = socket(AF_INET, SOCK_STREAM, 0);
    if (srv < 0) {
        perror("socket");
        return 1;
    }
    int yes = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(8080);

    if (bind(srv, (struct sockaddr *)&addr, sizeof addr) < 0 || listen(srv, 16) < 0) {
        perror("bind/listen");
        close(srv);
        return 1;
    }
    puts("listening on :8080");

    for (;;) {
        int cli = accept(srv, NULL, NULL);
        if (cli < 0) {
            perror("accept");
            continue;
        }
        char buf[1024];
        ssize_t n;
        while ((n = recv(cli, buf, sizeof buf, 0)) > 0) send(cli, buf, (size_t)n, 0);
        close(cli);
    }
}
`},{id:"matrix",title:"Matrix multiply",group:"Algorithms",code:`#include <stdio.h>

#define N 3

static void matmul(const double a[N][N], const double b[N][N], double out[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            double sum = 0.0;
            for (int k = 0; k < N; k++) sum += a[i][k] * b[k][j];
            out[i][j] = sum;
        }
    }
}

int main(void) {
    double a[N][N] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    double id[N][N] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
    double r[N][N];
    matmul(a, id, r);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) printf("%6.1f", r[i][j]);
        putchar('\\n');
    }
    return 0;
}
`},{id:"makefile-note",title:"Header + implementation pair (module skeleton)",group:"Basics",code:`/* ---- counter.h ---- */
#ifndef COUNTER_H
#define COUNTER_H

#include <stddef.h>

typedef struct Counter Counter;

Counter *counter_new(void);
void counter_inc(Counter *c);
size_t counter_get(const Counter *c);
void counter_free(Counter *c);

#endif /* COUNTER_H */

/* ---- counter.c ---- */
#include "counter.h"

#include <stdlib.h>

struct Counter {
    size_t value;
};

Counter *counter_new(void) {
    return calloc(1, sizeof(Counter));
}

void counter_inc(Counter *c) {
    c->value++;
}

size_t counter_get(const Counter *c) {
    return c->value;
}

void counter_free(Counter *c) {
    free(c);
}
`}];function Dr(e){if(!e)return null;let t=e.lastIndexOf("/"),n=e.lastIndexOf("%2F"),r=t>=n?"/":"%2F",a=Math.max(t,n);return a<=0||/^[a-z]+:\/\/?$/i.test(e.slice(0,a+1))?null:{dir:e.slice(0,a),sep:r}}var Ur=new Map;async function Na(e,t){if(!e||!t)return null;let n=Dr(t);for(let r=0;r<5&&n;r++){let a=Ur.get(n.dir);if(a&&Date.now()-a.at<15e3){if(a.value)return a.value}else{let o=null;try{let c=e(n.dir+n.sep+".clang-format");await c.exists()&&(o=await c.readFile("utf-8"))}catch{}if(Ur.set(n.dir,{at:Date.now(),value:o}),o)return o}n=Dr(n.dir)}return null}async function Nt({ops:e,settings:t,fsFactory:n,selectionOnly:r}){let a=e.text(),o=it(t),c=`preset ${t.style}`;if(t.useProjectConfig){let b=await Na(n,e.fileUri());b&&b.trim()&&(o=b,c=".clang-format")}let d,p="clang-format";if(ze()){let b,T=e.selection();r&&T.from!==T.to&&(b={fromLine:e.lineOf(T.from),toLine:e.lineOf(Math.max(T.from,T.to-1))});try{d=Be(a,o,b)}catch(x){if(c===".clang-format")d=Be(a,it(t),b),c=`preset ${t.style} (.clang-format was rejected: ${String(x.message||x).split(`
`)[0]})`;else throw x}}else p="built-in re-indenter",d=ar(a,t);return{changed:e.replaceAll(d),engine:p,source:c}}var Fa={error:"[E]",warning:"[W]",info:"[i]"};function zr({ops:e,ui:t,settings:n,fsFactory:r,refreshLint:a,getEditorManager:o}){let c=()=>e.view()?!0:(t.toast("No active editor"),!1),d=h=>async(...u)=>{try{return await h(...u)}catch(f){t.toast(`C Toolkit: ${f&&f.message?f.message:f}`,4e3),console.error(f)}},p=h=>{let u=ve(e.text(),h);return u===void 0&&t.toast("Parser is not available (WASM failed to load)",3500),u},w=async h=>{if(!c())return;let u=await Nt({ops:e,settings:n,fsFactory:r,selectionOnly:h});t.toast(u.changed?`Formatted (${u.source})`:"Already formatted",1800)},b=async()=>{if(!c())return;let h=e.text(),u=at(h,n);if(!u.length){t.toast("No problems found");return}let f=u.map((I,P)=>[P,`${Fa[I.severity]||""} L${e.lineOf(I.from)}  ${I.message}`]),m=await t.select(`Problems (${u.length})`,f);if(m===void 0)return;let y=u[m];e.goto(y.from,{from:y.from,to:Math.max(y.to,y.from)})},T=async()=>{if(!c())return;let h=xt(e.text(),{std:n.std}),u=new Set,f=[];for(let y of h)y.code==="missing-include"&&y.fix&&!u.has(y.fix.insert)&&(u.add(y.fix.insert),f.push(y.fix));if(!f.length){t.toast("No missing #includes found");return}let m=f[0].from;e.change([{from:m,to:m,insert:f.map(y=>y.insert).join("")}]),t.toast(`Added ${f.length} #include${f.length===1?"":"s"}`)},x=async()=>{if(!c())return;let h=p(m=>dr(m));if(!h)return;if(!h.length){t.toast("No symbols found");return}let u=h.map((m,y)=>[y,`${m.kind.padEnd(9," ")} ${m.detail.length>70?m.detail.slice(0,67)+"...":m.detail}   :${m.row+1}`]),f=await t.select(`Symbols (${h.length})`,u);f!==void 0&&e.goto(h[f].from)},z=async()=>{if(!c())return;let h=e.cursor(),u=p(f=>{let m=rn(f,h);if(!m)return null;let y=pe(f),I=ge(y,m.name,h);return I?{from:I.identFrom,name:m.name,kind:I.kind,atDef:h>=I.identFrom&&h<=I.identTo}:{name:m.name,missing:!0}});if(u!==void 0){if(!u||u.missing){let f=u&&ce.get(u.name);t.toast(f?`'${u.name}' is in <${f.headers[0]}>`:u?`No definition of '${u.name}' in this file`:"Place the cursor on an identifier",2500);return}e.goto(u.from)}},B=async()=>{if(!c())return;let h=e.cursor(),u=p(m=>{let y=rn(m,h);if(!y)return null;let I=pe(m),P=ge(I,y.name,h);if(!P)return{name:y.name,unresolved:!0};let W=_r(m,y.name).filter(H=>H.type!=="field_identifier"||P.kind==="field").filter(H=>{let Y=ge(I,y.name,H.from);return Y&&Y.identFrom===P.identFrom});return{name:y.name,kind:P.kind,hits:W,global:P.global}});if(u===void 0)return;if(!u){t.toast("Place the cursor on an identifier to rename");return}if(u.unresolved){t.toast(`'${u.name}' is not declared in this file (library symbol or macro from another file)`,3500);return}let f=await t.prompt(`Rename ${u.kind} '${u.name}' (${u.hits.length} occurrence${u.hits.length===1?"":"s"})`,u.name);if(!(f===void 0||f===u.name)){if(!/^[A-Za-z_]\w*$/.test(f)){t.toast("Not a valid C identifier",3e3);return}e.change(u.hits.map(m=>({from:m.from,to:m.to,insert:f}))),u.global&&t.toast("Renamed in this file only. Check other files that use it.",3500)}},N=async()=>{if(!c())return;let h=e.wordAtCursor();if(h||(h=await t.prompt("Look up symbol","")),!h)return;let u=ln(e.text(),h,e.cursor());if(!u){t.toast(`No documentation for '${h}'`,2500);return}await t.alert(h,[u.sig,u.doc,u.header].filter(Boolean).join(`

`))},k=async()=>{if(!c())return;let h=e.wordAtCursor(),u,f=h&&ce.get(h);if(f)u=f.headers[0];else if(u=await t.select("Add #include",ke.map(H=>[H,`<${H}>`])),u===void 0)return;let m=e.text();if(new RegExp(`#\\s*include\\s*<${u.replace(/[.*+?^${}()|[\]\\/]/g,"\\$&")}>`).test(m)){t.toast(`<${u}> is already included`);return}let y=0,I=/^[ \t]*#[ \t]*include[^\n]*\n/gm,P,W=-1;for(;P=I.exec(m);)W=P.index+P[0].length;if(W>=0)y=W;else{let H=/^(?:\s*(?:\/\*[\s\S]*?\*\/|\/\/[^\n]*)\s*)*/.exec(m);y=H?H[0].length:0}e.change([{from:y,to:y,insert:`#include <${u}>
`}]),t.toast(`Added #include <${u}>`)},A=async()=>{if(!c())return;let h=(e.fileName()||"header.h").replace(/[^A-Za-z0-9]/g,"_").toUpperCase(),u=h.endsWith("_H")?h:h+"_H",f=e.text();if(/^\s*#\s*(ifndef|pragma\s+once)/m.test(f)){t.toast("This file already has an include guard");return}e.change([{from:0,to:0,insert:`#ifndef ${u}
#define ${u}

`},{from:f.length,to:f.length,insert:`${f.endsWith(`
`)?"":`
`}
#endif /* ${u} */
`}])},M=async()=>{if(!c())return;let h=p(f=>mr(f,e.cursor()));if(h===void 0)return;if(!h){t.toast("Place the cursor inside a function");return}let u=["/**",` * @brief ${h.name}`," *"];for(let f of h.params)u.push(` * @param ${f}`);h.returnsVoid||u.push(" * @return"),u.push(" */"),e.change([{from:h.from,to:h.from,insert:u.join(`
`)+`
`}])},L=async()=>{if(!c())return;let h=await t.select("Insert snippet",st.map((u,f)=>[f,`${u.label.padEnd(10," ")} ${u.detail}`]));h!==void 0&&e.insertSnippet(st[h].body)},O=async()=>{if(!c())return;let h=await t.select("Insert code sample",un.map((m,y)=>[y,`${m.group}: ${m.title}`]));if(h===void 0)return;let u=un[h].code;if(ze())try{u=Be(u,it(n))}catch{}!(e.text().trim()==="")&&!await t.confirm("Insert sample","The file is not empty. Insert the sample at the cursor?")||e.insert(u)},se=async()=>{if(!c())return;let h=e.fileName()||"main.c",u=h.replace(/\.[^.]+$/,""),f=e.text(),m=[];/#\s*include\s*<math\.h>/.test(f)&&m.push("-lm"),/#\s*include\s*<pthread\.h>/.test(f)&&m.push("-pthread");let I=`gcc -std=${n.std==="c23"?"c2x":n.std} -Wall -Wextra -Wpedantic -g ${h} -o ${u}${m.length?" "+m.join(" "):""}`,P=await t.copy(I);await t.alert(P?"Compile command copied":"Compile command",`${I}

Run in Termux (pkg install clang) from the file's folder, then ./${u}`)},X=h=>h?"on":"off";return[["format","C: Format document",()=>w(!1)],["format-selection","C: Format selection",()=>w(!0)],["problems","C: Show problems",b],["add-includes","C: Add all missing #includes",T],["symbols","C: Go to symbol (outline)",x],["definition","C: Go to definition",z],["rename","C: Rename symbol",B],["docs","C: Show documentation for symbol",N],["include","C: Add #include",k],["guard","C: Insert include guard",A],["doxygen","C: Insert Doxygen comment for function",M],["snippet","C: Insert snippet",L],["sample","C: Insert code sample",O],["compile","C: Copy gcc compile command",se],["toggle-lint","C: Toggle linting",async()=>{n.lintEnabled=!n.lintEnabled,cn(n),a(),t.toast(`Linting ${X(n.lintEnabled)}`)}],["settings","C: Settings",async()=>{for(;;){let h=n,u=[["style",`Format style: ${h.style}`],["indent",`Indent width: ${h.indentWidth}`],["tabs",`Indent with tabs: ${X(h.useTab)}`],["col",`Column limit: ${h.columnLimit||"none"}`],["custom",`Custom clang-format style${h.style==="Custom"?" (active)":""}`],["project",`Use project .clang-format: ${X(h.useProjectConfig)}`],["lint",`Linting: ${X(h.lintEnabled)}`],["semantic",`Semantic checks: ${X(h.semanticLint)}`],["unused",`Unused variable hints: ${X(h.unusedHints)}`],["info",`Info-level hints: ${X(h.infoHints)}`],["gutter",`Lint gutter markers: ${X(h.lintGutter)} (applies after restart)`],["std",`C standard: ${h.std}`],["completion",`Completion: ${X(h.completion)}`],["hover",`Hover documentation: ${X(h.hoverDocs)}`]],f=await t.select("C Toolkit settings",u);if(f===void 0)break;switch(f){case"style":{let m=await t.select("Format style",sr.map(y=>[y,y]));m!==void 0&&(h.style=m);break}case"indent":{let m=await t.select("Indent width",[2,3,4,8].map(y=>[y,String(y)]));m!==void 0&&(h.indentWidth=Number(m));break}case"tabs":h.useTab=!h.useTab;break;case"col":{let m=await t.select("Column limit",[[0,"No limit"],[80,"80"],[100,"100"],[120,"120"]]);m!==void 0&&(h.columnLimit=Number(m));break}case"custom":{let m=await t.prompt("clang-format style: a preset name, {Key: value, ...} or .clang-format contents",h.custom||"{BasedOnStyle: LLVM, IndentWidth: 4}","textarea");if(m!==void 0)if(ze())try{Be(`int a;
`,m),h.custom=m,h.style="Custom",t.toast("Custom style saved")}catch(y){t.toast("Rejected: "+String(y.message||y).split(`
`)[0],4500)}else h.custom=m,h.style="Custom";break}case"project":h.useProjectConfig=!h.useProjectConfig;break;case"lint":h.lintEnabled=!h.lintEnabled;break;case"semantic":h.semanticLint=!h.semanticLint;break;case"unused":h.unusedHints=!h.unusedHints;break;case"info":h.infoHints=!h.infoHints;break;case"gutter":h.lintGutter=!h.lintGutter;break;case"std":{let m=await t.select("C standard",["c99","c11","c17","c23"].map(y=>[y,y]));m!==void 0&&(h.std=m);break}case"completion":h.completion=!h.completion;break;case"hover":h.hoverDocs=!h.hoverDocs;break;default:}cn(h),a()}}],["status","C: Toolkit status",async()=>{let h=[`Parser (tree-sitter): ${Oe()?"ready":"NOT loaded - using lexical fallback"}`,`Formatter (clang-format WASM): ${ze()?"ready":"NOT loaded - using built-in re-indenter"}`,`Editor: ${e.isCM()?"CodeMirror":e.view()?"legacy (Ace)":"none"}`,`Style: ${n.style}${n.useProjectConfig?" (+ project .clang-format)":""}`];await t.alert("C Toolkit status",h.join(`
`))}]].map(([h,u,f])=>({name:`c-toolkit:${h}`,description:u,exec:d(f)}))}var Br="c_toolkit";function Ca(){return{...Gt,token(e,t){let n=Gt.token(e,t);if(n==="variable"||n===null){let r=ce.get(e.current());if(r)return r.kind==="macro"?"atom":"builtin"}return n}}}var dn=class{constructor(){this.alive=!1,this.baseUrl="",this.registeredCommands=[],this.timer=null,this.unsubs=[],this.attachedViews=new WeakSet}require(t){return window.acode.require(t)}async readAsset(t){let n=`${this.baseUrl}assets/${t}`,r;try{let o=await this.require("fs")(n).readFile();if(o&&o.byteLength)return o}catch(a){r=a}try{let a=await fetch(n);if(a.ok)return await a.arrayBuffer();r=new Error(`HTTP ${a.status}`)}catch(a){r=a}throw new Error(`Cannot load ${t}: ${r&&r.message}`)}async init(t){this.alive=!0,this.baseUrl=t.endsWith("/")?t:t+"/";let n=window.acode;this.settings=Or(),this.ui=$r(n),this.em=this.require("editorManager"),this.cm=cr(a=>n.require(a)),this.ops=Rr(()=>this.em,this.cm),this.fsFactory=(()=>{try{return this.require("fs")}catch{return null}})();let r={getSettings:()=>this.settings,isAlive:()=>this.alive};this.built=Ar(this.cm,r),this.registerCommands(),this.registerFormatter(),this.registerLanguage(),this.watchEditor(),this.loadEngines()}async loadEngines(){let t=o=>this.readAsset(o),n=await Promise.allSettled([Jn(t),ir(t)]),r=["Parser","Formatter"],a=n.map((o,c)=>o.status==="rejected"?`${r[c]}: ${o.reason&&o.reason.message}`:null).filter(Boolean);a.length&&(console.error("[C Toolkit] engine load failed",a),this.ui.toast(`C Toolkit: ${a[0]} (using fallback)`,5e3)),this.refreshLint()}registerCommands(){let t=null;try{t=this.require("commands")}catch{}if(!t||!t.addCommand)return;let n=zr({ops:this.ops,ui:this.ui,settings:this.settings,fsFactory:this.fsFactory,refreshLint:()=>this.refreshLint(),getEditorManager:()=>this.em});for(let r of n)try{t.addCommand(r),this.registeredCommands.push(r.name)}catch(a){console.warn("[C Toolkit] addCommand",r.name,a)}this.commands=t}registerFormatter(){let t=window.acode;t.registerFormatter&&t.registerFormatter(Ke.id,["c","h"],async()=>{try{(await Nt({ops:this.ops,settings:this.settings,fsFactory:this.fsFactory,selectionOnly:!1})).engine!=="clang-format"&&this.ui.toast("clang-format unavailable: used the built-in re-indenter",3e3)}catch(n){this.ui.toast(`Format failed: ${String(n&&n.message?n.message:n).split(`
`)[0]}`,4e3)}},"C (clang-format)")}registerLanguage(){let t=null;try{t=this.require("editorLanguages")}catch{}let n=this.cm.get("StreamLanguage");if(!(!t||!t.register||!n))try{t.register(Br,["c","h"],"C (Toolkit)",async()=>[n.define(Ca()),...this.built.extensions]),this.langRegistered=t}catch(r){console.warn("[C Toolkit] language registration failed",r)}}attach(){if(this.alive)try{let t=this.ops.view();if(!t||!this.ops.isCM()||!this.ops.isCFile())return;let n=this.built.marker,r=this.cm.get("StateEffect"),a=this.cm.get("Compartment");if(!r||n&&t.state.field(n,!1)||!n&&this.attachedViews.has(t.state))return;let o=a?(this.compartment=this.compartment||new a).of(this.built.extensions):this.built.extensions;t.dispatch({effects:r.appendConfig.of(o)}),this.attachedViews.add(t.state)}catch(t){this.attachWarned||(this.attachWarned=!0,console.warn("[C Toolkit] attach failed",t))}}watchEditor(){let t=this.em,n=()=>setTimeout(()=>this.attach(),50);for(let r of["switch-file","file-loaded","init-open-file","new-file","rename-file"])try{t&&t.on&&(t.on(r,n),this.unsubs.push(()=>t.off&&t.off(r,n)))}catch{}this.timer=setInterval(()=>this.attach(),2500),n()}refreshLint(){try{let t=this.ops.view(),n=this.cm.get("forceLinting");t&&n&&this.ops.isCM()&&n(t)}catch{}}async destroy(){this.alive=!1,clearInterval(this.timer);for(let t of this.unsubs)try{t()}catch{}this.unsubs=[];for(let t of this.registeredCommands)try{this.commands.removeCommand(t)}catch{}this.registeredCommands=[];try{window.acode.unregisterFormatter&&window.acode.unregisterFormatter(Ke.id)}catch{}try{if(this.langRegistered){let t=this.langRegistered;(t.unregister||t.remove||(()=>{})).call(t,Br)}}catch{}try{let t=this.ops&&this.ops.view();t&&this.compartment&&this.ops.isCM()&&t.dispatch({effects:this.compartment.reconfigure([])})}catch{}Oe()&&er()}};if(window.acode){let e=new dn;window.acode.setPluginInit(Ke.id,async t=>{await e.init(t)}),window.acode.setPluginUnmount(Ke.id,()=>e.destroy())}})();
